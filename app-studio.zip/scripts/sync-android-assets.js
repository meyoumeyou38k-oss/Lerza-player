import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const distDir = path.join(rootDir, 'dist');
const targetAssetsDir = path.join(rootDir, 'app', 'src', 'main', 'assets');

function copyRecursiveSync(src, dest) {
  const exists = fs.existsSync(src);
  const stats = exists && fs.statSync(src);
  const isDirectory = exists && stats.isDirectory();
  if (isDirectory) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    fs.readdirSync(src).forEach((childItemName) => {
      copyRecursiveSync(path.join(src, childItemName), path.join(dest, childItemName));
    });
  } else if (exists) {
    fs.copyFileSync(src, dest);
  }
}

if (fs.existsSync(distDir)) {
  console.log('[sync-android-assets] Syncing dist/ into Android assets directory...');
  if (!fs.existsSync(targetAssetsDir)) {
    fs.mkdirSync(targetAssetsDir, { recursive: true });
  }

  // Remove old JS and CSS bundles in targetAssetsDir/assets to prevent stale bundle accumulation
  const subAssetsDir = path.join(targetAssetsDir, 'assets');
  if (fs.existsSync(subAssetsDir)) {
    fs.rmSync(subAssetsDir, { recursive: true, force: true });
  }

  copyRecursiveSync(distDir, targetAssetsDir);
  console.log('[sync-android-assets] Successfully synced latest web build to app/src/main/assets!');
} else {
  console.warn('[sync-android-assets] dist directory does not exist, skipping asset sync.');
}
