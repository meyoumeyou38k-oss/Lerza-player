/**
 * Real Web Audio API & MediaSession service for Lerza Player.
 * Connects Equalizer BiquadFilter nodes, MediaSession lock screen notifications,
 * and audio effects.
 */

class AudioEngineService {
  private audioCtx: AudioContext | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private filters: BiquadFilterNode[] = [];
  private bassFilter: BiquadFilterNode | null = null;
  private volumeGainNode: GainNode | null = null;
  private compressorNode: DynamicsCompressorNode | null = null;
  private limiterNode: WaveShaperNode | null = null;
  private currentMediaElement: HTMLMediaElement | null = null;
  private isInitialized = false;
  private currentVolumeMultiplier = 1.0; // 1.0 = 100%, 1.5 = 150%, 2.0 = 200%, 3.0 = 300%

  // Frequencies for the 5-band equalizer
  private readonly frequencies = [60, 230, 910, 3600, 14000];

  private connectedElements = new WeakSet<HTMLMediaElement>();

  /**
   * Generates a soft-saturation transfer curve that prevents digital square-wave clipping
   * and speaker breakup when volume is amplified up to 300%.
   */
  private makeSoftLimitCurve(samples = 2048): Float32Array {
    const curve = new Float32Array(samples);
    for (let i = 0; i < samples; ++i) {
      const x = (i * 2) / samples - 1;
      // Soft saturation curve: clean linear near 0, smooth hyperbolic compression at higher amplitudes
      curve[i] = Math.tanh(x * 1.15) * 0.96;
    }
    return curve;
  }

  public async resume(): Promise<void> {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      try {
        await this.audioCtx.resume();
      } catch (e) {
        console.warn('AudioContext resume warning:', e);
      }
    }
  }

  public init(mediaElement: HTMLMediaElement) {
    if (!mediaElement) return;
    this.currentMediaElement = mediaElement;

    try {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!this.audioCtx) {
        this.audioCtx = new AudioCtxClass();
      }

      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume().catch(() => {});
      }

      if (this.connectedElements.has(mediaElement)) {
        return;
      }

      // Connect source node safely
      try {
        this.sourceNode = this.audioCtx.createMediaElementSource(mediaElement);
        this.connectedElements.add(mediaElement);
      } catch {
        return;
      }

      // Build 5-band filter chain
      this.filters = this.frequencies.map((freq, index) => {
        const filter = this.audioCtx!.createBiquadFilter();
        if (index === 0) {
          filter.type = 'lowshelf';
        } else if (index === this.frequencies.length - 1) {
          filter.type = 'highshelf';
        } else {
          filter.type = 'peaking';
          filter.Q.value = 1.0;
        }
        filter.frequency.value = freq;
        filter.gain.value = 0;
        return filter;
      });

      // Bass boost filter
      this.bassFilter = this.audioCtx.createBiquadFilter();
      this.bassFilter.type = 'lowshelf';
      this.bassFilter.frequency.value = 100;
      this.bassFilter.gain.value = 0;

      // Volume booster GainNode (Allows 100% to 300% amplification: 1.0, 1.5, 2.0, 3.0)
      this.volumeGainNode = this.audioCtx.createGain();
      this.volumeGainNode.gain.value = this.currentVolumeMultiplier;

      // Studio-grade Dynamics Compressor (prevents sudden harsh peaks and clipping)
      this.compressorNode = this.audioCtx.createDynamicsCompressor();
      this.compressorNode.threshold.setValueAtTime(-12, this.audioCtx.currentTime);
      this.compressorNode.knee.setValueAtTime(20, this.audioCtx.currentTime);
      this.compressorNode.ratio.setValueAtTime(12, this.audioCtx.currentTime);
      this.compressorNode.attack.setValueAtTime(0.003, this.audioCtx.currentTime);
      this.compressorNode.release.setValueAtTime(0.20, this.audioCtx.currentTime);

      // Soft-knee limiter wave shaper (mathematically limits output without square-wave crackle)
      this.limiterNode = this.audioCtx.createWaveShaper();
      this.limiterNode.curve = this.makeSoftLimitCurve() as any;
      this.limiterNode.oversample = '2x';

      // Chain: Source -> Filter0 -> Filter1 ... -> Bass -> VolumeBoost Gain -> Compressor -> Limiter -> Destination
      let lastNode: AudioNode = this.sourceNode;
      this.filters.forEach(filter => {
        lastNode.connect(filter);
        lastNode = filter;
      });

      lastNode.connect(this.bassFilter);
      this.bassFilter.connect(this.volumeGainNode);
      this.volumeGainNode.connect(this.compressorNode);
      this.compressorNode.connect(this.limiterNode);
      this.limiterNode.connect(this.audioCtx.destination);

      this.isInitialized = true;
    } catch (err) {
      console.warn('AudioEngine Web Audio setup warning (fallback to native audio):', err);
    }
  }

  public setVolumeMultiplier(multiplier: number) {
    this.currentVolumeMultiplier = multiplier;
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }

    if (this.audioCtx) {
      const now = this.audioCtx.currentTime;

      // Dynamically adapt compressor & gain curves to ensure loud, rich, undistorted sound
      if (this.volumeGainNode) {
        try {
          this.volumeGainNode.gain.setValueAtTime(multiplier, now);
        } catch {
          this.volumeGainNode.gain.value = multiplier;
        }
      }

      if (this.compressorNode) {
        try {
          if (multiplier <= 1.0) {
            // Standard transparent playback
            this.compressorNode.threshold.setValueAtTime(-8, now);
            this.compressorNode.ratio.setValueAtTime(6, now);
          } else if (multiplier <= 1.5) {
            // Moderate boost - smooth leveling
            this.compressorNode.threshold.setValueAtTime(-14, now);
            this.compressorNode.ratio.setValueAtTime(10, now);
          } else if (multiplier <= 2.0) {
            // 200% boost - firm peak protection, clean vocal enhancement
            this.compressorNode.threshold.setValueAtTime(-18, now);
            this.compressorNode.ratio.setValueAtTime(14, now);
          } else {
            // 300% boost - high definition limiting, maximum safe loudness without speaker tear
            this.compressorNode.threshold.setValueAtTime(-22, now);
            this.compressorNode.ratio.setValueAtTime(18, now);
          }
        } catch {
          // Fallback if automation error
        }
      }
    }
  }

  public getVolumeMultiplier(): number {
    return this.currentVolumeMultiplier;
  }

  public setBandGain(bandIndex: number, gainDb: number) {
    if (this.filters[bandIndex]) {
      this.filters[bandIndex].gain.value = gainDb;
    }
  }

  public setAllBands(gains: number[]) {
    gains.forEach((gain, idx) => {
      this.setBandGain(idx, gain);
    });
  }

  public setBassBoost(levelPercent: number) {
    if (this.bassFilter) {
      this.bassFilter.gain.value = (levelPercent / 100) * 12;
    }
  }

  public setPlaybackState(state: 'none' | 'paused' | 'playing') {
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.playbackState = state;
      } catch (e) {
        console.warn('MediaSession playbackState error:', e);
      }
    }
  }

  public updatePositionState(params: { duration: number; position: number; playbackRate?: number }) {
    if ('mediaSession' in navigator && 'setPositionState' in navigator.mediaSession) {
      try {
        const safeDuration = Math.max(1, params.duration || 1);
        const safePos = Math.max(0, Math.min(params.position || 0, safeDuration));
        navigator.mediaSession.setPositionState({
          duration: safeDuration,
          playbackRate: params.playbackRate || 1.0,
          position: safePos
        });
      } catch (e) {
        // Ignored if not yet supported
      }
    }
  }

  public updateMediaSession(params: {
    title: string;
    artist: string;
    album: string;
    artworkUrl: string;
    isPlaying?: boolean;
    onPlay: () => void;
    onPause: () => void;
    onNext: () => void;
    onPrev: () => void;
    onSeek: (seconds: number) => void;
  }) {
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: params.title || 'Lerza Track',
          artist: params.artist || 'Lerza Player',
          album: params.album || 'Lerza Music',
          artwork: [
            { src: params.artworkUrl || '/app-icon.png', sizes: '96x96', type: 'image/png' },
            { src: params.artworkUrl || '/app-icon.png', sizes: '192x192', type: 'image/png' },
            { src: params.artworkUrl || '/app-icon.png', sizes: '512x512', type: 'image/png' }
          ]
        });

        navigator.mediaSession.setActionHandler('play', params.onPlay);
        navigator.mediaSession.setActionHandler('pause', params.onPause);
        navigator.mediaSession.setActionHandler('nexttrack', params.onNext);
        navigator.mediaSession.setActionHandler('previoustrack', params.onPrev);

        navigator.mediaSession.setActionHandler('seekto', (details) => {
          if (details.seekTime !== undefined) {
            params.onSeek(details.seekTime);
          }
        });

        navigator.mediaSession.setActionHandler('seekbackward', (details) => {
          const skipTime = details.seekOffset || 10;
          if (this.currentMediaElement) {
            params.onSeek(Math.max(0, this.currentMediaElement.currentTime - skipTime));
          }
        });

        navigator.mediaSession.setActionHandler('seekforward', (details) => {
          const skipTime = details.seekOffset || 10;
          if (this.currentMediaElement) {
            params.onSeek(this.currentMediaElement.currentTime + skipTime);
          }
        });

        if (params.isPlaying !== undefined) {
          navigator.mediaSession.playbackState = params.isPlaying ? 'playing' : 'paused';
        }
      } catch (err) {
        console.warn('MediaSession configuration notice:', err);
      }
    }
  }
}

export const AudioEngine = new AudioEngineService();
