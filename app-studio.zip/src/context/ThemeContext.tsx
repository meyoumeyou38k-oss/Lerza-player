import React, { createContext, useContext, useEffect } from 'react';
import { ThemeMode } from '../types';
import { ThemeConfig, getThemeConfig } from '../utils/theme';

interface ThemeContextType {
  theme: ThemeMode;
  config: ThemeConfig;
  setTheme: (theme: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: 'light',
  config: getThemeConfig('light'),
  setTheme: () => {}
});

export const ThemeProvider: React.FC<{
  theme: ThemeMode;
  onThemeChange: (theme: ThemeMode) => void;
  children: React.ReactNode;
}> = ({ theme, onThemeChange, children }) => {
  const config = getThemeConfig(theme);

  useEffect(() => {
    // Enforce app theme independence from system / OS-level theme
    const root = document.documentElement;
    if (config.isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    root.setAttribute('data-theme', theme);
    root.style.colorScheme = config.isDark ? 'dark' : 'light';

    // Update meta theme-color
    let meta = document.getElementById('meta-theme-color') as HTMLMetaElement | null;
    if (!meta) {
      meta = document.querySelector('meta[name="theme-color"]');
    }
    if (meta) {
      meta.setAttribute('content', config.isDark ? '#090a10' : '#fcfbf9');
    }

    // Apply exact background and text color to body to prevent white/black flash or OS overrides
    document.body.style.backgroundColor = config.isDark ? '#090a10' : '#fcfbf9';
    document.body.style.color = config.isDark ? '#f3f4f6' : '#0f172a';
  }, [theme, config.isDark]);

  return (
    <ThemeContext.Provider value={{ theme, config, setTheme: onThemeChange }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
