import { ThemeMode } from '../types';

export interface ThemeConfig {
  id: ThemeMode;
  name: string;
  nameUrdu: string;
  isDark: boolean;
  
  // Outer Container
  appBg: string;
  appText: string;
  
  // Headers & Sticky bars
  headerBg: string;
  headerBorder: string;
  
  // Cards & Surfaces
  cardBg: string;
  cardHover: string;
  cardBorder: string;
  cardActive: string;
  
  // Text Hierarchies
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  
  // Accent & Buttons
  accentColor: string;
  accentBg: string;
  accentText: string;
  accentBorder: string;
  
  // Inputs & Controls
  inputBg: string;
  inputBorder: string;
  inputText: string;
  
  // Modals & Popups
  modalBg: string;
  modalBorder: string;
  
  // Mini player
  miniPlayerBg: string;
  miniPlayerBorder: string;
  
  // Full player
  fullPlayerBg: string;
}

export const THEMES: Record<ThemeMode, ThemeConfig> = {
  dark: {
    id: 'dark',
    name: 'Pure Black (AMOLED)',
    nameUrdu: 'مکمل بلیک (Amoled)',
    isDark: true,
    appBg: 'bg-black',
    appText: 'text-white',
    headerBg: 'bg-black/95 border-b border-white/10',
    headerBorder: 'border-white/10',
    cardBg: 'bg-neutral-900/70',
    cardHover: 'hover:bg-neutral-900',
    cardBorder: 'border-white/10',
    cardActive: 'bg-gradient-to-r from-cyan-950/70 to-neutral-900/90 border-cyan-500/40 shadow-cyan-500/10',
    textPrimary: 'text-white',
    textSecondary: 'text-neutral-300',
    textMuted: 'text-neutral-400',
    accentColor: '#06b6d4',
    accentBg: 'bg-cyan-500 hover:bg-cyan-400 text-neutral-950',
    accentText: 'text-cyan-400',
    accentBorder: 'border-cyan-500/40',
    inputBg: 'bg-neutral-900/90',
    inputBorder: 'border-white/10',
    inputText: 'text-white placeholder-neutral-500',
    modalBg: 'bg-[#0e1018]',
    modalBorder: 'border-white/10',
    miniPlayerBg: 'bg-[#12141e]/95 border-cyan-500/30 text-white',
    miniPlayerBorder: 'border-cyan-500/30',
    fullPlayerBg: 'bg-[#090a11] text-white',
  },
  light: {
    id: 'light',
    name: 'Pure White (مکمل سفید)',
    nameUrdu: 'مکمل سفید (Pure White)',
    isDark: false,
    appBg: 'bg-[#f8fafc]',
    appText: 'text-slate-900',
    headerBg: 'bg-white/95 border-b border-slate-200 shadow-xs',
    headerBorder: 'border-slate-200',
    cardBg: 'bg-white',
    cardHover: 'hover:bg-slate-100/90',
    cardBorder: 'border-slate-200 shadow-xs',
    cardActive: 'bg-sky-50 border-sky-400 shadow-sky-100',
    textPrimary: 'text-slate-900',
    textSecondary: 'text-slate-600',
    textMuted: 'text-slate-500',
    accentColor: '#0284c7',
    accentBg: 'bg-sky-600 hover:bg-sky-500 text-white',
    accentText: 'text-sky-600',
    accentBorder: 'border-sky-300',
    inputBg: 'bg-slate-100',
    inputBorder: 'border-slate-300',
    inputText: 'text-slate-900 placeholder-slate-400',
    modalBg: 'bg-white',
    modalBorder: 'border-slate-200',
    miniPlayerBg: 'bg-white/95 border-slate-300 text-slate-900 shadow-xl',
    miniPlayerBorder: 'border-slate-300',
    fullPlayerBg: 'bg-[#f8fafc] text-slate-900',
  },
  pink: {
    id: 'pink',
    name: 'Soft Rose (ہلکا گلابی)',
    nameUrdu: 'ہلکا گلابی (Soft Rose)',
    isDark: false,
    appBg: 'bg-[#fff1f2]',
    appText: 'text-stone-900',
    headerBg: 'bg-rose-50/95 border-b border-rose-200 shadow-xs',
    headerBorder: 'border-rose-200',
    cardBg: 'bg-white',
    cardHover: 'hover:bg-rose-50/80',
    cardBorder: 'border-rose-200/80 shadow-xs',
    cardActive: 'bg-rose-100/70 border-rose-400 shadow-rose-100',
    textPrimary: 'text-stone-900',
    textSecondary: 'text-rose-950/80',
    textMuted: 'text-rose-700/70',
    accentColor: '#e11d48',
    accentBg: 'bg-rose-500 hover:bg-rose-400 text-white',
    accentText: 'text-rose-600',
    accentBorder: 'border-rose-300',
    inputBg: 'bg-rose-50',
    inputBorder: 'border-rose-200',
    inputText: 'text-stone-900 placeholder-rose-400',
    modalBg: 'bg-[#fff5f6]',
    modalBorder: 'border-rose-200',
    miniPlayerBg: 'bg-white/95 border-rose-300 text-stone-900 shadow-xl',
    miniPlayerBorder: 'border-rose-300',
    fullPlayerBg: 'bg-[#fff1f2] text-stone-900',
  },
  green: {
    id: 'green',
    name: 'Mint Sage (ہلکا سبز)',
    nameUrdu: 'ہلکا سبز (Mint Green)',
    isDark: false,
    appBg: 'bg-[#f0fdf4]',
    appText: 'text-stone-900',
    headerBg: 'bg-emerald-50/95 border-b border-emerald-200 shadow-xs',
    headerBorder: 'border-emerald-200',
    cardBg: 'bg-white',
    cardHover: 'hover:bg-emerald-50/80',
    cardBorder: 'border-emerald-200/80 shadow-xs',
    cardActive: 'bg-emerald-100/70 border-emerald-400 shadow-emerald-100',
    textPrimary: 'text-stone-900',
    textSecondary: 'text-emerald-950/80',
    textMuted: 'text-emerald-700/70',
    accentColor: '#059669',
    accentBg: 'bg-emerald-600 hover:bg-emerald-500 text-white',
    accentText: 'text-emerald-600',
    accentBorder: 'border-emerald-300',
    inputBg: 'bg-emerald-50',
    inputBorder: 'border-emerald-200',
    inputText: 'text-stone-900 placeholder-emerald-400',
    modalBg: 'bg-[#f4fbf6]',
    modalBorder: 'border-emerald-200',
    miniPlayerBg: 'bg-white/95 border-emerald-300 text-stone-900 shadow-xl',
    miniPlayerBorder: 'border-emerald-300',
    fullPlayerBg: 'bg-[#f0fdf4] text-stone-900',
  },
  purple: {
    id: 'purple',
    name: 'Soft Lavender (ہلکا جامنی)',
    nameUrdu: 'ہلکا جامنی (Lavender)',
    isDark: false,
    appBg: 'bg-[#faf5ff]',
    appText: 'text-stone-900',
    headerBg: 'bg-purple-50/95 border-b border-purple-200 shadow-xs',
    headerBorder: 'border-purple-200',
    cardBg: 'bg-white',
    cardHover: 'hover:bg-purple-50/80',
    cardBorder: 'border-purple-200/80 shadow-xs',
    cardActive: 'bg-purple-100/70 border-purple-400 shadow-purple-100',
    textPrimary: 'text-stone-900',
    textSecondary: 'text-purple-950/80',
    textMuted: 'text-purple-700/70',
    accentColor: '#9333ea',
    accentBg: 'bg-purple-600 hover:bg-purple-500 text-white',
    accentText: 'text-purple-600',
    accentBorder: 'border-purple-300',
    inputBg: 'bg-purple-50',
    inputBorder: 'border-purple-200',
    inputText: 'text-stone-900 placeholder-purple-400',
    modalBg: 'bg-[#faf6ff]',
    modalBorder: 'border-purple-200',
    miniPlayerBg: 'bg-white/95 border-purple-300 text-stone-900 shadow-xl',
    miniPlayerBorder: 'border-purple-300',
    fullPlayerBg: 'bg-[#faf5ff] text-stone-900',
  },
  sky: {
    id: 'sky',
    name: 'Sky Pastel (ہلکا آسمانی)',
    nameUrdu: 'ہلکا آسمانی (Sky Blue)',
    isDark: false,
    appBg: 'bg-[#f0f9ff]',
    appText: 'text-stone-900',
    headerBg: 'bg-sky-50/95 border-b border-sky-200 shadow-xs',
    headerBorder: 'border-sky-200',
    cardBg: 'bg-white',
    cardHover: 'hover:bg-sky-50/80',
    cardBorder: 'border-sky-200/80 shadow-xs',
    cardActive: 'bg-sky-100/70 border-sky-400 shadow-sky-100',
    textPrimary: 'text-stone-900',
    textSecondary: 'text-sky-950/80',
    textMuted: 'text-sky-700/70',
    accentColor: '#0284c7',
    accentBg: 'bg-sky-600 hover:bg-sky-500 text-white',
    accentText: 'text-sky-600',
    accentBorder: 'border-sky-300',
    inputBg: 'bg-sky-50',
    inputBorder: 'border-sky-200',
    inputText: 'text-stone-900 placeholder-sky-400',
    modalBg: 'bg-[#f0f8ff]',
    modalBorder: 'border-sky-200',
    miniPlayerBg: 'bg-white/95 border-sky-300 text-stone-900 shadow-xl',
    miniPlayerBorder: 'border-sky-300',
    fullPlayerBg: 'bg-[#f0f9ff] text-stone-900',
  },
  amber: {
    id: 'amber',
    name: 'Warm Peach (لائٹ پیچ)',
    nameUrdu: 'لائٹ پیچ (Warm Peach)',
    isDark: false,
    appBg: 'bg-[#fffbeb]',
    appText: 'text-stone-900',
    headerBg: 'bg-amber-50/95 border-b border-amber-200 shadow-xs',
    headerBorder: 'border-amber-200',
    cardBg: 'bg-white',
    cardHover: 'hover:bg-amber-50/80',
    cardBorder: 'border-amber-200/80 shadow-xs',
    cardActive: 'bg-amber-100/70 border-amber-400 shadow-amber-100',
    textPrimary: 'text-stone-900',
    textSecondary: 'text-amber-950/80',
    textMuted: 'text-amber-800/70',
    accentColor: '#d97706',
    accentBg: 'bg-amber-500 hover:bg-amber-400 text-stone-950',
    accentText: 'text-amber-600',
    accentBorder: 'border-amber-300',
    inputBg: 'bg-amber-50',
    inputBorder: 'border-amber-200',
    inputText: 'text-stone-900 placeholder-amber-400',
    modalBg: 'bg-[#fefce8]',
    modalBorder: 'border-amber-200',
    miniPlayerBg: 'bg-white/95 border-amber-300 text-stone-900 shadow-xl',
    miniPlayerBorder: 'border-amber-300',
    fullPlayerBg: 'bg-[#fffbeb] text-stone-900',
  }
};

export const getThemeConfig = (mode: ThemeMode = 'dark'): ThemeConfig => {
  return THEMES[mode] || THEMES.dark;
};
