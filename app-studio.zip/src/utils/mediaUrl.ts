import { MediaTrack } from '../types';

/**
 * Universal media source resolver for Lerza Player.
 * Resolves valid web-playable URLs for local Android MediaStore files,
 * web streams, blob URLs, and handles fallback gracefully.
 */
export function getPlayableMediaUrl(track: MediaTrack | null | undefined, preferVideo = false): string {
  if (!track) return '';

  const t = track as any;

  const isValidUrl = (url: any): string | null => {
    if (!url || typeof url !== 'string') return null;
    const trimmed = url.trim();
    if (!trimmed) return null;
    // Disallow raw Linux/Android local filesystem paths directly in browser src
    if (trimmed.startsWith('/storage/') || trimmed.startsWith('/sdcard/') || trimmed.startsWith('/data/')) {
      return null;
    }
    return trimmed;
  };

  // 1. Synthetic Android Bridge URLs for MediaStore items (always 100% playable via WebView AssetLoader)
  if (track.id) {
    if (preferVideo && track.id.startsWith('android-video-')) {
      const vidId = track.id.replace('android-video-', '');
      return `https://appassets.androidplatform.net/local-video/${vidId}`;
    }
    if (!preferVideo && track.id.startsWith('android-media-')) {
      const audId = track.id.replace('android-media-', '');
      return `https://appassets.androidplatform.net/local-audio/${audId}`;
    }
  }

  // 2. Direct playable URLs
  if (preferVideo) {
    const vUrl = isValidUrl(track.videoUrl);
    if (vUrl) return vUrl;
  }

  const aUrl = isValidUrl(track.audioUrl);
  if (aUrl) return aUrl;

  const vUrlFallback = isValidUrl(track.videoUrl);
  if (vUrlFallback) return vUrlFallback;

  const uri = isValidUrl(t.uri) || isValidUrl(t.dataUrl) || isValidUrl(t.contentUri);
  if (uri) return uri;

  // 3. If track has synthetic Android ID, fallback to it
  if (track.id) {
    if (track.id.startsWith('android-video-')) {
      const vidId = track.id.replace('android-video-', '');
      return `https://appassets.androidplatform.net/local-video/${vidId}`;
    }
    if (track.id.startsWith('android-media-')) {
      const audId = track.id.replace('android-media-', '');
      return `https://appassets.androidplatform.net/local-audio/${audId}`;
    }
  }

  // 4. Raw file paths routed through Android WebView asset domain
  const rawPath = t.filePath || t.path || '';
  if (typeof rawPath === 'string' && rawPath.trim().length > 0) {
    const clean = rawPath.trim();
    if (clean.startsWith('/storage/') || clean.startsWith('/sdcard/')) {
      return `https://appassets.androidplatform.net${clean.startsWith('/') ? '' : '/'}${clean}`;
    }
    return clean;
  }

  return '';
}

/**
 * Normalizes a MediaTrack object so its audioUrl and videoUrl are guaranteed
 * to be web-playable URLs, repairing any stale tracks stored from previous runs.
 */
export function normalizeTrack(raw: Partial<MediaTrack> & Record<string, any>): MediaTrack {
  const id = String(raw.id || `track-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`);
  const isAndroidVideo = id.startsWith('android-video-');
  const isAndroidAudio = id.startsWith('android-media-');

  let audioUrl = raw.audioUrl || '';
  let videoUrl = raw.videoUrl || '';

  if (isAndroidVideo) {
    const vidId = id.replace('android-video-', '');
    videoUrl = `https://appassets.androidplatform.net/local-video/${vidId}`;
    audioUrl = `https://appassets.androidplatform.net/local-video/${vidId}`;
  } else if (isAndroidAudio) {
    const audId = id.replace('android-media-', '');
    audioUrl = `https://appassets.androidplatform.net/local-audio/${audId}`;
  } else {
    // If audioUrl or videoUrl was stored as raw /storage/ path, convert to playable bridge URL
    if (audioUrl.startsWith('/storage/') || audioUrl.startsWith('/sdcard/')) {
      audioUrl = `https://appassets.androidplatform.net${audioUrl}`;
    }
    if (videoUrl && (videoUrl.startsWith('/storage/') || videoUrl.startsWith('/sdcard/'))) {
      videoUrl = `https://appassets.androidplatform.net${videoUrl}`;
    }
  }

  const isVid = Boolean(
    isAndroidVideo ||
    raw.isVideoOnly ||
    raw.hasMV ||
    (videoUrl && videoUrl.trim().length > 0) ||
    /\.(mp4|mkv|webm|mov|3gp|avi|flv|m4v|ts|wmv)(\?.*)?$/i.test(videoUrl || audioUrl || raw.filePath || '')
  );

  return {
    id,
    title: raw.title && raw.title.trim() ? raw.title : (isVid ? 'Video Track' : 'Audio Track'),
    artist: raw.artist && raw.artist.trim() && raw.artist !== '<unknown>' ? raw.artist : (isVid ? 'Local Videos' : 'Device Storage'),
    album: raw.album && raw.album.trim() && raw.album !== '<unknown>' ? raw.album : (isVid ? 'Videos' : 'Local Music'),
    duration: Math.max(0, Number(raw.duration) || 0),
    audioUrl,
    videoUrl: isVid ? (videoUrl || audioUrl) : undefined,
    artworkUrl: raw.artworkUrl || (isAndroidVideo ? `https://appassets.androidplatform.net/local-video-thumb/${id.replace('android-video-', '')}` : (isAndroidAudio ? `https://appassets.androidplatform.net/local-audio-art/${id.replace('android-media-', '')}` : undefined)),
    hasMV: isVid,
    isVideoOnly: isVid,
    genre: raw.genre || (isVid ? 'Local Video' : 'Local Music'),
    folder: raw.folder || (isVid ? 'Device Storage / Videos' : 'Device Storage / Music'),
    fileFormat: raw.fileFormat || (isVid ? 'MP4' : 'MP3'),
    fileSize: raw.fileSize,
    dateAdded: Number(raw.dateAdded) || Date.now(),
    playCount: Number(raw.playCount) || 0,
    isFavorite: Boolean(raw.isFavorite),
    lyrics: Array.isArray(raw.lyrics) ? raw.lyrics : undefined
  };
}
