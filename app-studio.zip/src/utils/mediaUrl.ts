import { MediaTrack } from '../types';

/**
 * Extracts a pure numeric ID from an ID string, content URI, or media path.
 * Android MediaStore items have numeric IDs (e.g. 100000123) which map directly to
 * WebViewAssetLoader path handlers (/local-audio/{id} and /local-video/{id}).
 */
export function extractMediaNumericId(val: any): string | null {
  if (!val) return null;
  const str = String(val).trim();
  if (/^\d+$/.test(str)) return str;
  const matchPrefixed = str.match(/android-(?:media|video|audio)-(\d+)/i);
  if (matchPrefixed) return matchPrefixed[1];
  const matchContent = str.match(/content:\/\/media\/external\/(?:audio|video)\/media\/(\d+)/i);
  if (matchContent) return matchContent[1];
  const matchTrailing = str.match(/\/(\d+)(?:\.[a-zA-Z0-9]+)?$/);
  if (matchTrailing && !str.includes('track-') && !str.includes('imported-')) return matchTrailing[1];
  return null;
}

/**
 * Universal media source resolver for Lerza Player.
 * Resolves valid web-playable URLs for local Android MediaStore files,
 * web streams, blob URLs, and handles fallback gracefully.
 */
export function getPlayableMediaUrl(track: MediaTrack | null | undefined, preferVideo = false): string {
  if (!track) return '';

  const candidates = getMediaCandidateUrls(track, preferVideo);
  return candidates[0] || '';
}

/**
 * Returns an ordered array of playable candidate URLs for a given track.
 * Used for automatic seamless playback fallback if one URL format errors out.
 */
export function getMediaCandidateUrls(track: MediaTrack | null | undefined, preferVideo = false): string[] {
  if (!track) return [];

  const t = track as any;
  const candidates: string[] = [];

  const cleanUrl = (url: any): string | null => {
    if (!url || typeof url !== 'string') return null;
    let trimmed = url.trim();
    if (!trimmed) return null;
    // Strip file:// prefix if present
    if (trimmed.startsWith('file://')) {
      trimmed = trimmed.replace(/^file:\/\//i, '');
    }
    // Reject direct filesystem paths for direct browser src (these require bridge routing)
    if (trimmed.startsWith('/storage/') || trimmed.startsWith('/sdcard/') || trimmed.startsWith('/data/')) {
      return null;
    }
    // Reject raw content:// schemes directly
    if (trimmed.startsWith('content://')) {
      return null;
    }
    return trimmed;
  };

  const audId = extractMediaNumericId(track.id) || 
                 extractMediaNumericId(t.contentUri) || 
                 extractMediaNumericId(t.uri) || 
                 extractMediaNumericId(t.filePath) ||
                 extractMediaNumericId(t.audioUrl);

  const vidId = extractMediaNumericId(track.id) || 
                 extractMediaNumericId(t.contentUri) || 
                 extractMediaNumericId(t.uri) || 
                 extractMediaNumericId(t.filePath) ||
                 extractMediaNumericId(t.videoUrl);

  if (preferVideo) {
    if (vidId) {
      candidates.push(`https://appassets.androidplatform.net/local-video/${vidId}`);
    }
    const cleanVUrl = cleanUrl(track.videoUrl);
    if (cleanVUrl && !candidates.includes(cleanVUrl)) candidates.push(cleanVUrl);
  }

  // 1. Android AssetLoader URL by numeric ID (100% playable via Android WebView AssetLoader)
  if (audId) {
    const assetAudioUrl = `https://appassets.androidplatform.net/local-audio/${audId}`;
    if (!candidates.includes(assetAudioUrl)) candidates.push(assetAudioUrl);
  }

  // 2. Direct playable URLs (http, https, blob, data)
  const cleanAUrl = cleanUrl(track.audioUrl);
  if (cleanAUrl && !candidates.includes(cleanAUrl)) candidates.push(cleanAUrl);

  const cleanVFallback = cleanUrl(track.videoUrl);
  if (cleanVFallback && !candidates.includes(cleanVFallback)) candidates.push(cleanVFallback);

  const cleanDirectUri = cleanUrl(t.uri) || cleanUrl(t.dataUrl);
  if (cleanDirectUri && !candidates.includes(cleanDirectUri)) candidates.push(cleanDirectUri);

  // 3. Fallback video asset loader URL if audio is not found
  if (vidId) {
    const assetVideoUrl = `https://appassets.androidplatform.net/local-video/${vidId}`;
    if (!candidates.includes(assetVideoUrl)) candidates.push(assetVideoUrl);
  }

  // 4. Raw file paths routed through Android WebView asset domain
  const rawPath = t.filePath || t.path || t.data || '';
  if (typeof rawPath === 'string' && rawPath.trim().length > 0) {
    let clean = rawPath.trim().replace(/^file:\/\//i, '');
    if (clean.startsWith('/storage/') || clean.startsWith('/sdcard/') || clean.startsWith('/data/')) {
      const assetPathUrl = `https://appassets.androidplatform.net${clean.startsWith('/') ? '' : '/'}${clean}`;
      if (!candidates.includes(assetPathUrl)) candidates.push(assetPathUrl);
    } else if (!candidates.includes(clean)) {
      candidates.push(clean);
    }
  }

  return candidates;
}

/**
 * Normalizes a MediaTrack object so its audioUrl, videoUrl, and duration are guaranteed
 * to be accurate and web-playable, repairing any unit errors (e.g. milliseconds to seconds)
 * and stale tracks from previous runs.
 */
export function normalizeTrack(raw: Partial<MediaTrack> & Record<string, any>): MediaTrack {
  const rawId = String(raw.id || '').trim();
  const numericId = extractMediaNumericId(rawId) || 
                    extractMediaNumericId(raw.contentUri) || 
                    extractMediaNumericId(raw.uri) || 
                    extractMediaNumericId(raw.filePath) ||
                    extractMediaNumericId(raw.path);

  const isExplicitVideo = Boolean(
    raw.isVideoOnly ||
    raw.hasMV ||
    rawId.startsWith('android-video-') ||
    /\.(mp4|mkv|webm|mov|3gp|avi|flv|m4v|ts|wmv)(\?.*)?$/i.test(raw.videoUrl || raw.audioUrl || raw.filePath || raw.path || '')
  );

  let id = rawId;
  if (!id) {
    if (numericId) {
      id = isExplicitVideo ? `android-video-${numericId}` : `android-media-${numericId}`;
    } else {
      id = `track-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    }
  } else if (/^\d+$/.test(id)) {
    // Pure numeric ID from Android MediaStore - standardize with proper prefix
    id = isExplicitVideo ? `android-video-${id}` : `android-media-${id}`;
  }

  // Ensure duration is strictly in SECONDS:
  // Android MediaStore duration column is in milliseconds (e.g. 180,000 for 3 mins).
  // If duration > 10,000 (10s in ms) or integer > 1000, convert ms to seconds.
  let duration = Number(raw.duration) || 0;
  if (duration > 10000) {
    duration = Math.round(duration / 1000);
  } else if (duration > 1000 && Number.isInteger(duration)) {
    duration = Math.round(duration / 1000);
  }
  duration = Math.max(0, duration);

  let audioUrl = raw.audioUrl || '';
  let videoUrl = raw.videoUrl || '';
  const rawFilePath = raw.filePath || raw.path || raw.data || '';

  if (numericId) {
    if (isExplicitVideo) {
      videoUrl = `https://appassets.androidplatform.net/local-video/${numericId}`;
      audioUrl = videoUrl;
    } else {
      audioUrl = `https://appassets.androidplatform.net/local-audio/${numericId}`;
    }
  } else {
    // If audioUrl or videoUrl was empty or stored as raw /storage/ path, resolve bridge URL
    if (!audioUrl && rawFilePath) {
      if (rawFilePath.startsWith('/storage/') || rawFilePath.startsWith('/sdcard/') || rawFilePath.startsWith('file://')) {
        const clean = rawFilePath.replace(/^file:\/\//i, '');
        audioUrl = `https://appassets.androidplatform.net${clean.startsWith('/') ? '' : '/'}${clean}`;
      } else {
        audioUrl = rawFilePath;
      }
    } else if (audioUrl.startsWith('/storage/') || audioUrl.startsWith('/sdcard/') || audioUrl.startsWith('file://')) {
      const clean = audioUrl.replace(/^file:\/\//i, '');
      audioUrl = `https://appassets.androidplatform.net${clean.startsWith('/') ? '' : '/'}${clean}`;
    }

    if (videoUrl && (videoUrl.startsWith('/storage/') || videoUrl.startsWith('/sdcard/') || videoUrl.startsWith('file://'))) {
      const clean = videoUrl.replace(/^file:\/\//i, '');
      videoUrl = `https://appassets.androidplatform.net${clean.startsWith('/') ? '' : '/'}${clean}`;
    }
  }

  const isVid = Boolean(
    isExplicitVideo ||
    (videoUrl && videoUrl.trim().length > 0)
  );

  let artworkUrl = raw.artworkUrl || raw.thumbnailUrl || raw.thumbUrl;
  if (!artworkUrl && numericId) {
    artworkUrl = isVid 
      ? `https://appassets.androidplatform.net/local-video-thumb/${numericId}`
      : `https://appassets.androidplatform.net/local-audio-art/${numericId}`;
  }

  // Date added normalization (MediaStore seconds vs ms)
  let dateAdded = Number(raw.dateAdded) || Date.now();
  if (dateAdded > 0 && dateAdded < 10000000000) {
    // Convert seconds to milliseconds
    dateAdded = dateAdded * 1000;
  }

  return {
    id,
    title: raw.title && raw.title.trim() && raw.title !== 'Unknown' ? raw.title : (isVid ? 'Video Track' : 'Audio Track'),
    artist: raw.artist && raw.artist.trim() && raw.artist !== '<unknown>' && raw.artist !== 'Unknown' ? raw.artist : (isVid ? 'Local Videos' : 'Device Storage'),
    album: raw.album && raw.album.trim() && raw.album !== '<unknown>' && raw.album !== 'Unknown' ? raw.album : (isVid ? 'Videos' : 'Local Music'),
    duration,
    audioUrl,
    videoUrl: isVid ? (videoUrl || audioUrl) : undefined,
    artworkUrl,
    hasMV: isVid,
    isVideoOnly: isVid,
    genre: raw.genre || (isVid ? 'Local Video' : 'Local Music'),
    folder: raw.folder || (isVid ? 'Device Storage / Videos' : 'Device Storage / Music'),
    fileFormat: raw.fileFormat || (isVid ? 'MP4' : 'MP3'),
    fileSize: raw.fileSize,
    dateAdded,
    playCount: Number(raw.playCount) || 0,
    isFavorite: Boolean(raw.isFavorite),
    lyrics: Array.isArray(raw.lyrics) ? raw.lyrics : undefined
  };
}
