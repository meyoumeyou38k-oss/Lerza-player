import { MediaTrack } from '../types';

/**
 * Extracts a pure numeric ID from an ID string or Android MediaStore content URI.
 * Only returns true MediaStore numeric IDs (e.g. from content://media/external/audio/media/12345).
 * Does NOT treat timestamp numbers in filenames (e.g. VID_20230501_142311.mp4 or Snapchat-1234567.mp4) as IDs.
 */
export function extractMediaNumericId(val: any): string | null {
  if (!val) return null;
  const str = String(val).trim();
  
  // Pure digits only
  if (/^\d{3,}$/.test(str) && !str.includes('/') && !str.includes('.')) return str;
  
  // Prefixed with android-media-, android-video-, or android-audio-
  const matchPrefixed = str.match(/^android-(?:media|video|audio)-(\d+)$/i);
  if (matchPrefixed) return matchPrefixed[1];
  
  // Android MediaStore content URIs
  const matchContent = str.match(/content:\/\/media\/external\/(?:audio|video)\/media\/(\d+)/i);
  if (matchContent) return matchContent[1];

  const matchGeneralContent = str.match(/content:\/\/[a-zA-Z0-9._-]+\/(?:audio|video|media)\/(\d+)/i);
  if (matchGeneralContent) return matchGeneralContent[1];

  return null;
}

/**
 * Universal media source resolver for Lerza Player.
 * Resolves valid web-playable URLs for local Android MediaStore files,
 * web streams, blob URLs, and handles fallback gracefully.
 */
export function getPlayableMediaUrl(track: MediaTrack | null | undefined, preferVideo = false): string {
  if (!track) return '';

  const candidates = getMediaCandidateUrls(track, preferVideo);
  return candidates[0] || '';
}

/**
 * Returns an ordered array of playable candidate URLs for a given track.
 * Used for automatic seamless playback fallback if one URL format errors out.
 */
export function getMediaCandidateUrls(track: MediaTrack | null | undefined, preferVideo = false): string[] {
  if (!track) return [];

  const t = track as any;
  const candidates: string[] = [];

  const addCandidate = (url: string | null | undefined) => {
    if (!url || typeof url !== 'string') return;
    const trimmed = url.trim();
    if (!trimmed) return;
    if (!candidates.includes(trimmed)) {
      candidates.push(trimmed);
    }
  };

  const rawPath = String(t.filePath || t.path || t.data || '').trim();
  const cleanPath = rawPath.replace(/^file:\/\//i, '');
  const isLocalDevicePath = cleanPath.startsWith('/storage/') || cleanPath.startsWith('/sdcard/') || cleanPath.startsWith('/data/');

  const audId = extractMediaNumericId(track.id) || 
                extractMediaNumericId(t.contentUri) || 
                extractMediaNumericId(t.uri);

  const vidId = extractMediaNumericId(track.id) || 
                extractMediaNumericId(t.contentUri) || 
                extractMediaNumericId(t.uri);

  if (preferVideo) {
    // 1. If valid MediaStore Video ID exists
    if (vidId) {
      addCandidate(`https://appassets.androidplatform.net/local-video/${vidId}`);
    }

    // 2. If it's a local device file path (e.g. /DCIM/Camera/VID_*.mp4, Snapchat, or /Download/...)
    if (isLocalDevicePath) {
      addCandidate(`https://appassets.androidplatform.net${cleanPath.startsWith('/') ? '' : '/'}${cleanPath}`);
      addCandidate(`https://appassets.androidplatform.net/local-file/${encodeURIComponent(cleanPath)}`);
      addCandidate(`https://appassets.androidplatform.net/local-video/${encodeURIComponent(cleanPath)}`);
    }

    // 3. Direct videoUrl if valid web URL
    if (track.videoUrl && !track.videoUrl.startsWith('content://') && !track.videoUrl.startsWith('file://')) {
      addCandidate(track.videoUrl);
    }

    // 4. Fallback to audioUrl if video has matching audio or format
    if (track.audioUrl && !track.audioUrl.startsWith('content://') && !track.audioUrl.startsWith('file://')) {
      addCandidate(track.audioUrl);
    }

    // 5. Clean path fallback
    if (cleanPath && !cleanPath.startsWith('content://')) {
      addCandidate(cleanPath);
    }
  } else {
    // Audio playback mode (M4A, MP3, AAC, FLAC, WAV, OGG, etc.)

    // 1. If valid MediaStore Audio ID exists
    if (audId) {
      addCandidate(`https://appassets.androidplatform.net/local-audio/${audId}`);
    }

    // 2. Local device path for M4A, downloaded songs, recordings
    if (isLocalDevicePath) {
      addCandidate(`https://appassets.androidplatform.net${cleanPath.startsWith('/') ? '' : '/'}${cleanPath}`);
      addCandidate(`https://appassets.androidplatform.net/local-file/${encodeURIComponent(cleanPath)}`);
      addCandidate(`https://appassets.androidplatform.net/local-audio/${encodeURIComponent(cleanPath)}`);
    }

    // 3. Direct audioUrl
    if (track.audioUrl && !track.audioUrl.startsWith('content://') && !track.audioUrl.startsWith('file://')) {
      addCandidate(track.audioUrl);
    }

    // 4. If M4A (which is MP4 container) or video fallback
    if (vidId) {
      addCandidate(`https://appassets.androidplatform.net/local-video/${vidId}`);
    }

    if (track.videoUrl && !track.videoUrl.startsWith('content://') && !track.videoUrl.startsWith('file://')) {
      addCandidate(track.videoUrl);
    }

    // 5. Direct clean path
    if (cleanPath && !cleanPath.startsWith('content://')) {
      addCandidate(cleanPath);
    }
  }

  return candidates;
}

/**
 * Normalizes a MediaTrack object so its audioUrl, videoUrl, and duration are guaranteed
 * to be accurate and web-playable, repairing any unit errors (e.g. milliseconds to seconds)
 * and properly handling M4A audio files, Snapchat videos, and Camera recordings.
 */
export function normalizeTrack(raw: Partial<MediaTrack> & Record<string, any>): MediaTrack {
  const rawId = String(raw.id || '').trim();
  const rawFilePath = String(raw.filePath || raw.path || raw.data || '').trim();
  const cleanPath = rawFilePath.replace(/^file:\/\//i, '');
  const urlToCheck = (raw.videoUrl || raw.audioUrl || cleanPath || raw.uri || '').toLowerCase();
  const formatUpper = String(raw.fileFormat || '').toUpperCase();

  const isExplicitAudio = Boolean(
    formatUpper === 'M4A' || formatUpper === 'AAC' || formatUpper === 'MP3' ||
    formatUpper === 'FLAC' || formatUpper === 'OGG' || formatUpper === 'WAV' ||
    formatUpper === 'OPUS' ||
    /\.(m4a|aac|mp3|flac|ogg|wav|opus)(\?.*)?$/i.test(urlToCheck)
  );

  const isExplicitVideo = Boolean(
    !isExplicitAudio && (
      raw.isVideoOnly ||
      rawId.startsWith('android-video-') ||
      ['MP4', 'MKV', 'WEBM', 'MOV', '3GP', 'AVI', 'FLV', 'M4V', 'TS', 'WMV'].includes(formatUpper) ||
      /\.(mp4|mkv|webm|mov|3gp|avi|flv|m4v|ts|wmv)(\?.*)?$/i.test(urlToCheck)
    )
  );

  const numericId = extractMediaNumericId(rawId) || 
                    extractMediaNumericId(raw.contentUri) || 
                    extractMediaNumericId(raw.uri);

  let id = rawId;
  if (!id) {
    if (numericId) {
      id = isExplicitVideo ? `android-video-${numericId}` : `android-media-${numericId}`;
    } else {
      id = `track-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    }
  } else if (/^\d+$/.test(id)) {
    id = isExplicitVideo ? `android-video-${id}` : `android-media-${id}`;
  }

  // Duration in seconds
  let duration = Number(raw.duration) || 0;
  if (duration > 10000) {
    duration = Math.round(duration / 1000);
  } else if (duration > 1000 && Number.isInteger(duration)) {
    duration = Math.round(duration / 1000);
  }
  duration = Math.max(0, duration);

  let audioUrl = raw.audioUrl || '';
  let videoUrl = raw.videoUrl || '';

  if (numericId) {
    if (isExplicitVideo) {
      videoUrl = `https://appassets.androidplatform.net/local-video/${numericId}`;
      audioUrl = videoUrl;
    } else {
      audioUrl = `https://appassets.androidplatform.net/local-audio/${numericId}`;
    }
  } else {
    // Direct device paths (Camera recordings, Snapchat videos, M4A songs, Downloads)
    if (cleanPath.startsWith('/storage/') || cleanPath.startsWith('/sdcard/') || cleanPath.startsWith('/data/')) {
      const assetUrl = `https://appassets.androidplatform.net${cleanPath.startsWith('/') ? '' : '/'}${cleanPath}`;
      if (isExplicitVideo) {
        if (!videoUrl) videoUrl = assetUrl;
        if (!audioUrl) audioUrl = assetUrl;
      } else {
        if (!audioUrl) audioUrl = assetUrl;
      }
    }
  }

  // Final fallback to clean path if still empty
  if (!audioUrl && cleanPath) audioUrl = cleanPath;
  if (isExplicitVideo && !videoUrl && (cleanPath || audioUrl)) {
    videoUrl = cleanPath || audioUrl;
  }

  const isVid = isExplicitVideo;

  let artworkUrl = raw.artworkUrl || raw.thumbnailUrl || raw.thumbUrl;
  if (!artworkUrl && numericId) {
    artworkUrl = isVid 
      ? `https://appassets.androidplatform.net/local-video-thumb/${numericId}`
      : `https://appassets.androidplatform.net/local-audio-art/${numericId}`;
  }

  // Date added normalization
  let dateAdded = Number(raw.dateAdded) || Date.now();
  if (dateAdded > 0 && dateAdded < 10000000000) {
    dateAdded = dateAdded * 1000;
  }

  // Detect file format accurately
  let detectedFormat = raw.fileFormat;
  if (!detectedFormat) {
    const extMatch = urlToCheck.match(/\.([a-z0-9]{3,4})(?:\?.*)?$/i);
    if (extMatch) {
      detectedFormat = extMatch[1].toUpperCase();
    } else {
      detectedFormat = isVid ? 'MP4' : 'MP3';
    }
  }

  return {
    id,
    title: raw.title && raw.title.trim() && raw.title !== 'Unknown' ? raw.title : (isVid ? 'Video Track' : 'Audio Track'),
    artist: raw.artist && raw.artist.trim() && raw.artist !== '<unknown>' && raw.artist !== 'Unknown' ? raw.artist : (isVid ? 'Local Videos' : 'Device Storage'),
    album: raw.album && raw.album.trim() && raw.album !== '<unknown>' && raw.album !== 'Unknown' ? raw.album : (isVid ? 'Videos' : 'Local Music'),
    duration,
    audioUrl,
    videoUrl: isVid ? (videoUrl || audioUrl) : (raw.hasMV ? videoUrl : undefined),
    artworkUrl,
    hasMV: Boolean(raw.hasMV || (isVid && raw.hasMV)),
    isVideoOnly: isVid,
    genre: raw.genre || (isVid ? 'Local Video' : 'Local Music'),
    folder: raw.folder || (isVid ? 'Device Storage / Videos' : 'Device Storage / Music'),
    fileFormat: detectedFormat,
    fileSize: raw.fileSize,
    dateAdded,
    playCount: Number(raw.playCount) || 0,
    isFavorite: Boolean(raw.isFavorite),
    lyrics: Array.isArray(raw.lyrics) ? raw.lyrics : undefined
  };
}
