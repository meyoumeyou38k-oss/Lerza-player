/**
 * Embedded ID3 & Audio Album Art Extractor for Lerza Player
 * Extracts embedded APIC / PIC cover art from audio files directly in the browser
 * or generates high-res vinyl artwork with genre color gradients.
 */

export async function extractEmbeddedAlbumArt(file: File): Promise<string | null> {
  try {
    // Read the first 512KB where ID3v2 tags reside
    const slice = file.slice(0, Math.min(file.size, 512 * 1024));
    const buffer = await slice.arrayBuffer();
    const bytes = new Uint8Array(buffer);

    // Check for ID3v2 header: 'I', 'D', '3'
    if (bytes[0] === 0x49 && bytes[1] === 0x44 && bytes[2] === 0x33) {
      const majorVersion = bytes[3];
      // ID3 tag size (syncsafe int at bytes 6..9)
      const tagSize = ((bytes[6] & 0x7f) << 21) |
                      ((bytes[7] & 0x7f) << 14) |
                      ((bytes[8] & 0x7f) << 7) |
                      (bytes[9] & 0x7f);

      const maxSearch = Math.min(bytes.length, tagSize + 10);
      let offset = 10; // After 10-byte ID3 header

      // ID3v2.2 uses 3-char frame IDs and 3-byte sizes
      if (majorVersion === 2) {
        while (offset < maxSearch - 6) {
          const frameId = String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2]);
          const frameSize = (bytes[offset + 3] << 16) | (bytes[offset + 4] << 8) | bytes[offset + 5];
          if (frameSize <= 0 || offset + 6 + frameSize > bytes.length) {
            offset++;
            continue;
          }
          if (frameId === 'PIC') {
            const dataOffset = offset + 6;
            // PIC format: 1 byte encoding, 3 byte format (JPG/PNG), 1 byte pic type, description null-terminated
            const format = String.fromCharCode(bytes[dataOffset + 1], bytes[dataOffset + 2], bytes[dataOffset + 3]).toLowerCase();
            const mime = format.includes('png') ? 'image/png' : 'image/jpeg';
            let descEnd = dataOffset + 5;
            while (descEnd < dataOffset + frameSize && bytes[descEnd] !== 0) descEnd++;
            const imgStart = descEnd + 1;
            const imgLen = (dataOffset + frameSize) - imgStart;
            if (imgLen > 64) {
              const blob = new Blob([bytes.slice(imgStart, imgStart + imgLen)], { type: mime });
              return URL.createObjectURL(blob);
            }
          }
          offset += 6 + frameSize;
        }
      } else {
        // ID3v2.3 and ID3v2.4
        while (offset < maxSearch - 10) {
          const frameId = String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2], bytes[offset + 3]);
          let frameSize = 0;
          if (majorVersion === 4) {
            frameSize = ((bytes[offset + 4] & 0x7f) << 21) |
                        ((bytes[offset + 5] & 0x7f) << 14) |
                        ((bytes[offset + 6] & 0x7f) << 7) |
                        (bytes[offset + 7] & 0x7f);
          } else {
            frameSize = (bytes[offset + 4] << 24) |
                        (bytes[offset + 5] << 16) |
                        (bytes[offset + 6] << 8) |
                        bytes[offset + 7];
          }

          if (frameSize <= 0 || offset + 10 + frameSize > bytes.length) {
            offset++;
            continue;
          }

          if (frameId === 'APIC') {
            const frameDataOffset = offset + 10;
            let mimeEnd = frameDataOffset + 1;
            while (mimeEnd < frameDataOffset + frameSize && bytes[mimeEnd] !== 0) {
              mimeEnd++;
            }
            const mimeType = new TextDecoder('ascii').decode(bytes.slice(frameDataOffset + 1, mimeEnd)) || 'image/jpeg';
            
            let descEnd = mimeEnd + 2; // skip mime null byte and picture type byte
            while (descEnd < frameDataOffset + frameSize && bytes[descEnd] !== 0) {
              descEnd++;
            }
            const imgStart = descEnd + 1;
            const imgLength = (frameDataOffset + frameSize) - imgStart;

            if (imgLength > 64) {
              const imgBytes = bytes.slice(imgStart, imgStart + imgLength);
              const blob = new Blob([imgBytes], { type: mimeType.trim() });
              return URL.createObjectURL(blob);
            }
          }

          offset += 10 + frameSize;
        }
      }
    }

    // Direct search for embedded JPEG or PNG magic header in the first 512KB
    for (let i = 0; i < bytes.length - 128; i++) {
      // JPEG SOI marker: FF D8 FF E0/E1/E2
      if (bytes[i] === 0xFF && bytes[i + 1] === 0xD8 && bytes[i + 2] === 0xFF) {
        // Find JPEG EOI marker: FF D9
        for (let j = i + 100; j < Math.min(bytes.length, i + 350000); j++) {
          if (bytes[j] === 0xFF && bytes[j + 1] === 0xD9) {
            const imgSlice = bytes.slice(i, j + 2);
            if (imgSlice.length > 512) {
              const blob = new Blob([imgSlice], { type: 'image/jpeg' });
              return URL.createObjectURL(blob);
            }
            break;
          }
        }
      }
      // PNG magic header: 89 50 4E 47 0D 0A 1A 0A
      if (bytes[i] === 0x89 && bytes[i + 1] === 0x50 && bytes[i + 2] === 0x4E && bytes[i + 3] === 0x47) {
        // Look for IEND chunk: 49 45 4E 44 AE 42 60 82
        for (let j = i + 100; j < Math.min(bytes.length, i + 350000); j++) {
          if (bytes[j] === 0x49 && bytes[j + 1] === 0x45 && bytes[j + 2] === 0x4E && bytes[j + 3] === 0x44) {
            const imgSlice = bytes.slice(i, j + 8);
            if (imgSlice.length > 512) {
              const blob = new Blob([imgSlice], { type: 'image/png' });
              return URL.createObjectURL(blob);
            }
            break;
          }
        }
      }
    }
  } catch (err) {
    console.warn('ID3 APIC artwork extraction warning:', err);
  }

  return null;
}

/**
 * Generates an ultra-crisp SVG vinyl disc album cover data URL
 * customized to the song title, artist, and genre.
 */
export function generateVinylAlbumArt(title: string, artist: string): string {
  const cleanTitle = (title || 'Track').substring(0, 18);
  const cleanArtist = (artist || 'Artist').substring(0, 18);
  
  // Deterministic color palette based on title
  const colors = [
    ['#06b6d4', '#3b82f6', '#1e1b4b'],
    ['#8b5cf6', '#ec4899', '#31103f'],
    ['#10b981', '#06b6d4', '#064e3b'],
    ['#f59e0b', '#ef4444', '#451a03'],
    ['#6366f1', '#a855f7', '#1e1b4b']
  ];
  const charCodeSum = (title + artist).split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const selectedColors = colors[charCodeSum % colors.length];

  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" width="500" height="500">
    <defs>
      <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${selectedColors[0]}" />
        <stop offset="50%" stop-color="${selectedColors[1]}" />
        <stop offset="100%" stop-color="${selectedColors[2]}" />
      </linearGradient>
      <radialGradient id="vinylGleam" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.25" />
        <stop offset="40%" stop-color="#ffffff" stop-opacity="0.05" />
        <stop offset="100%" stop-color="#000000" stop-opacity="0.4" />
      </radialGradient>
    </defs>
    <rect width="500" height="500" rx="40" fill="url(#bgGrad)" />
    <!-- Vinyl Disc Graphic -->
    <circle cx="250" cy="250" r="190" fill="#121318" stroke="rgba(255,255,255,0.15)" stroke-width="3" />
    <circle cx="250" cy="250" r="170" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="1.5" />
    <circle cx="250" cy="250" r="145" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="1.5" />
    <circle cx="250" cy="250" r="120" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="1.5" />
    <circle cx="250" cy="250" r="95" fill="url(#vinylGleam)" />
    
    <!-- Center Label -->
    <circle cx="250" cy="250" r="75" fill="${selectedColors[0]}" />
    <circle cx="250" cy="250" r="16" fill="#090a10" stroke="rgba(255,255,255,0.4)" stroke-width="2" />
    
    <!-- Typography -->
    <text x="250" y="440" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="28" font-weight="bold" fill="#ffffff" text-anchor="middle" letter-spacing="1">
      ${cleanTitle.replace(/[&<>"']/g, '')}
    </text>
    <text x="250" y="475" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="20" fill="rgba(255,255,255,0.8)" text-anchor="middle">
      ${cleanArtist.replace(/[&<>"']/g, '')}
    </text>
  </svg>
  `.trim();

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
