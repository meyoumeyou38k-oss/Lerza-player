import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  MediaTrack, 
  Playlist, 
  CategoryTab, 
  RepeatMode, 
  PlayerDisplayMode, 
  AppSettings,
  VaultConfig,
  VaultLockType
} from './types';
import { 
  INITIAL_TRACKS, 
  INITIAL_PLAYLISTS, 
  EQUALIZER_PRESETS 
} from './data/sampleMedia';
import { AudioEngine } from './services/AudioEngine';

import { Header } from './components/Header';
import { CategoryChips } from './components/CategoryChips';
import { AdBanner } from './components/AdBanner';
import { SongsList } from './components/SongsList';
import { VideosList } from './components/VideosList';
import { PlaylistsView } from './components/PlaylistsView';
import { FoldersAlbumsArtistsView } from './components/FoldersAlbumsArtistsView';
import { MiniPlayer } from './components/MiniPlayer';
import { FullScreenPlayer } from './components/FullScreenPlayer';
import { LyricsModal } from './components/LyricsModal';
import { EqualizerModal } from './components/EqualizerModal';
import { QueueDrawer } from './components/QueueDrawer';
import { SettingsModal } from './components/SettingsModal';
import { AddToPlaylistModal } from './components/AddToPlaylistModal';
import { AdInterstitialModal } from './components/AdInterstitialModal';
import { PermissionModal } from './components/PermissionModal';
import { UpdateModal, UpdateInfo } from './components/UpdateModal';
import { VaultModal } from './components/VaultModal';
import { LockDialog } from './components/LockDialog';
import { ThemeProvider } from './context/ThemeContext';
import { getThemeConfig } from './utils/theme';
import { 
  extractEmbeddedAlbumArt, 
  extractVideoThumbnailFromFile, 
  generateVinylAlbumArt 
} from './utils/artworkExtractor';
import { getPlayableMediaUrl, getMediaCandidateUrls, normalizeTrack } from './utils/mediaUrl';

export default function App() {
  // --- Persistent & Core States ---
  const [tracks, setTracks] = useState<MediaTrack[]>(() => {
    const saved = localStorage.getItem('lerza_tracks') || localStorage.getItem('fz_tracks');
    if (saved) {
      try {
        const parsed: MediaTrack[] = JSON.parse(saved);
        const demoIds = ['track-1', 'track-2', 'track-3', 'track-4', 'track-5', 'video-1', 'video-2'];
        const filtered = parsed.filter(t => !demoIds.includes(t.id));
        return filtered.map((t) => normalizeTrack(t));
      } catch {
        return INITIAL_TRACKS;
      }
    }
    return INITIAL_TRACKS;
  });

  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    const saved = localStorage.getItem('lerza_playlists') || localStorage.getItem('fz_playlists');
    return saved ? JSON.parse(saved) : INITIAL_PLAYLISTS;
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('lerza_settings') || localStorage.getItem('fz_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.warn('Settings parse warning:', e);
      }
    }
    return {
      theme: 'light',
      isAdsRemoved: false,
      resumePlayback: true,
      audioCrossfade: 0,
      sleepTimerMinutes: null,
      playbackSpeed: 1.0,
      bassBoostLevel: 30,
      virtualizerEnabled: false,
      filterWhatsAppAndRecordings: true,
      minAudioDurationFilter: 15,
      language: 'en'
    };
  });

  // --- Private Vault Persistent State ---
  const [vaultConfig, setVaultConfig] = useState<VaultConfig>(() => {
    const saved = localStorage.getItem('lerza_vault_config');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.warn('Vault config parse warning:', e);
      }
    }
    return {
      lockType: 'pin',
      lockSecret: '',
      hasSetup: false
    };
  });

  const [hiddenTrackIds, setHiddenTrackIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('lerza_vault_hidden_ids');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.warn('Hidden ids parse warning:', e);
      }
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem('lerza_vault_config', JSON.stringify(vaultConfig));
    } catch (e) {}
  }, [vaultConfig]);

  useEffect(() => {
    try {
      localStorage.setItem('lerza_vault_hidden_ids', JSON.stringify(hiddenTrackIds));
    } catch (e) {}
  }, [hiddenTrackIds]);

  // Vault Modals & Unlock workflow state
  const [isVaultModalOpen, setIsVaultModalOpen] = useState(false);
  const [isLockDialogOpen, setIsLockDialogOpen] = useState(false);
  const [lockDialogMode, setLockDialogMode] = useState<'setup' | 'unlock'>('unlock');
  const [lockDialogPendingAction, setLockDialogPendingAction] = useState<(() => void) | null>(null);

  const [activeTab, setActiveTab] = useState<CategoryTab>('songs');
  const [tabHistory, setTabHistory] = useState<CategoryTab[]>(['songs']);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(true);

  // --- Playback State ---
  const [currentTrack, setCurrentTrack] = useState<MediaTrack | null>(() => {
    try {
      const saved = localStorage.getItem('lerza_last_played_track');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.id) return normalizeTrack(parsed);
      }
    } catch (e) {}
    return tracks[0] || null;
  });
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('lerza_last_played_time');
      if (saved) {
        const val = parseFloat(saved);
        if (Number.isFinite(val) && val > 0) return val;
      }
    } catch (e) {}
    return 0;
  });
  const [duration, setDuration] = useState(tracks[0]?.duration || 0);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('all');
  const [isShuffle, setIsShuffle] = useState(false);
  const [shuffleHistory, setShuffleHistory] = useState<number[]>([]);
  const [displayMode, setDisplayMode] = useState<PlayerDisplayMode>(() => {
    try {
      const saved = localStorage.getItem('lerza_last_played_track');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed?.isVideoOnly) return 'video';
      }
    } catch (e) {}
    return 'audio';
  });
  
  // --- Queue State ---
  const [queue, setQueue] = useState<MediaTrack[]>(() => {
    try {
      const saved = localStorage.getItem('lerza_last_played_track');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.id) {
          return [parsed, ...tracks.filter(t => t.id !== parsed.id)];
        }
      }
    } catch (e) {}
    return tracks;
  });
  const [queueIndex, setQueueIndex] = useState(0);

  // --- Modals & Views ---
  const [isFullScreenOpen, setIsFullScreenOpen] = useState(false);
  const [isLyricsOpen, setIsLyricsOpen] = useState(false);
  const [isEqualizerOpen, setIsEqualizerOpen] = useState(false);
  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPermissionModalOpen, setIsPermissionModalOpen] = useState(false);
  const [trackForPlaylistModal, setTrackForPlaylistModal] = useState<MediaTrack | null>(null);

  // --- Equalizer State ---
  const [eqBands, setEqBands] = useState<number[]>([0, 0, 0, 0, 0]);
  const [activeEqPreset, setActiveEqPreset] = useState<string>('flat');
  const [volumeMultiplier, setVolumeMultiplier] = useState<number>(1.0);

  // --- Interstitial Ad State ---
  const [isInterstitialOpen, setIsInterstitialOpen] = useState(false);
  const [hasShownSessionInterstitial, setHasShownSessionInterstitial] = useState(false);

  // --- App Version ---
  const APP_VERSION = '1.0.0';
  const APP_BUILD = 100;
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [updateInfo, setUpdateInfo] = useState<UpdateInfo | null>(null);
  const [, setIsCheckingUpdate] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hiddenImportInputRef = useRef<HTMLInputElement>(null);
  const isSwitchingTrackRef = useRef(false);

  const isNewerVersion = (latest: string, current: string): boolean => {
    if (!latest || !current) return false;
    const v1 = latest.replace(/^v/i, '').split('.').map(p => parseInt(p, 10) || 0);
    const v2 = current.replace(/^v/i, '').split('.').map(p => parseInt(p, 10) || 0);
    const maxLen = Math.max(v1.length, v2.length);
    for (let i = 0; i < maxLen; i++) {
      const n1 = v1[i] || 0;
      const n2 = v2[i] || 0;
      if (n1 > n2) return true;
      if (n1 < n2) return false;
    }
    return false;
  };

  const checkForUpdates = async (isManual = false) => {
    try {
      setIsCheckingUpdate(true);
      const cacheBuster = Date.now();
      let data: UpdateInfo | null = null;

      // 0. If running inside Android APK with native AndroidBridge, use native network fetch first (bypasses WebView CORS/cache limits)
      if ((window as any).AndroidBridge?.fetchRemoteUpdateJson) {
        try {
          const nativeData = await new Promise<UpdateInfo | null>((resolve) => {
            const timer = setTimeout(() => {
              (window as any).onAndroidUpdateJsonReceived = null;
              (window as any).onAndroidUpdateJsonFailed = null;
              resolve(null);
            }, 6000);

            (window as any).onAndroidUpdateJsonReceived = (jsonStr: string) => {
              clearTimeout(timer);
              (window as any).onAndroidUpdateJsonReceived = null;
              (window as any).onAndroidUpdateJsonFailed = null;
              try {
                const parsed = JSON.parse(jsonStr);
                resolve(parsed);
              } catch (e) {
                resolve(null);
              }
            };

            (window as any).onAndroidUpdateJsonFailed = () => {
              clearTimeout(timer);
              (window as any).onAndroidUpdateJsonReceived = null;
              (window as any).onAndroidUpdateJsonFailed = null;
              resolve(null);
            };

            try {
              (window as any).AndroidBridge.fetchRemoteUpdateJson(`https://lerzaplayer.vercel.app/update-check.json?t=${cacheBuster}`);
            } catch (err) {
              clearTimeout(timer);
              resolve(null);
            }
          });

          if (nativeData) {
            data = nativeData;
          }
        } catch (e) {
          console.info('Native bridge fetch note:', e);
        }
      }

      // 1. Attempt to fetch directly from official live website endpoint
      if (!data) {
        try {
          const remoteRes = await fetch(`https://lerzaplayer.vercel.app/update-check.json?t=${cacheBuster}`, {
            cache: 'no-store',
            mode: 'cors',
            headers: { 'Accept': 'application/json' }
          });
          if (remoteRes.ok) {
            data = await remoteRes.json();
          }
        } catch (err) {
          console.info('Live endpoint check note:', err);
        }
      }

      // 2. Fallback to local / cached manifest if live is unreachable
      if (!data) {
        try {
          const localRes = await fetch(`/update-check.json?t=${cacheBuster}`, {
            cache: 'no-store',
            headers: { 'Accept': 'application/json' }
          });
          if (localRes.ok) {
            data = await localRes.json();
          }
        } catch (e) {}
      }

      if (!data) throw new Error('Update manifest not reachable');

      // Check if remote versionCode > APP_BUILD OR latestVersion string is higher than APP_VERSION
      const hasNewerBuild = typeof data.versionCode === 'number' && data.versionCode > APP_BUILD;
      const hasNewerSemver = Boolean(data.latestVersion && isNewerVersion(data.latestVersion, APP_VERSION));

      if (hasNewerBuild || hasNewerSemver) {
        setUpdateInfo(data);
        setIsUpdateModalOpen(true);
      } else if (isManual) {
        alert(`آپ کے پاس Lerza Player کا تازہ ترین ورژن (v${APP_VERSION}) پہلے سے موجود ہے!`);
      }
    } catch (err) {
      console.warn('Update check notice:', err);
      if (isManual) {
        alert('اپڈیٹ چیک کرنے کے دوران انٹرنیٹ کنکشن سے رابطہ نہ ہو سکا۔ برائے مہربانی اپنا انٹرنیٹ کنکشن چیک کر کے دوبارہ کوشش کریں۔');
      }
    } finally {
      setIsCheckingUpdate(false);
    }
  };

  const handleScanAndImport = () => {
    if ((window as any).AndroidBridge?.scanLocalAudio) {
      try {
        (window as any).AndroidBridge.scanLocalAudio();
        if ((window as any).AndroidBridge.scanLocalVideos) {
          (window as any).AndroidBridge.scanLocalVideos();
        }
      } catch (e) {
        console.warn('Native scan trigger notice:', e);
      }
    }
    hiddenImportInputRef.current?.click();
  };

  const handleImportedLocalFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const imported: MediaTrack[] = [];
    for (let idx = 0; idx < files.length; idx++) {
      const file = files[idx];
      const url = URL.createObjectURL(file);
      const isVid = file.type.startsWith('video');
      const title = file.name.replace(/\.[^/.]+$/, '');
      let artworkUrl: string | undefined = undefined;

      if (isVid) {
        const thumb = await extractVideoThumbnailFromFile(file);
        artworkUrl = thumb || undefined;
      } else {
        const art = await extractEmbeddedAlbumArt(file);
        artworkUrl = art || generateVinylAlbumArt(title, 'Device Storage');
      }

      imported.push({
        id: `imported-${Date.now()}-${idx}`,
        title,
        artist: 'Device Storage',
        album: isVid ? 'Imported Videos' : 'Imported Music',
        duration: 0,
        audioUrl: isVid ? undefined : url,
        videoUrl: isVid ? url : undefined,
        artworkUrl,
        hasMV: isVid,
        isVideoOnly: isVid,
        genre: isVid ? 'Video' : 'Audio',
        dateAdded: Date.now(),
        playCount: 0,
        folder: 'Imported',
        isFavorite: false,
        fileFormat: isVid ? 'MP4' : 'MP3'
      });
    }
    setTracks(prev => [...imported, ...prev]);
    setQueue(prev => [...imported, ...prev]);
    if (e.target) e.target.value = '';
  };

  const sanitizeTracksForStorage = (list: MediaTrack[]): MediaTrack[] => {
    return list.map(t => ({
      id: String(t.id),
      title: String(t.title || ''),
      artist: String(t.artist || ''),
      album: String(t.album || ''),
      duration: Number(t.duration) || 0,
      artworkUrl: String(t.artworkUrl || ''),
      audioUrl: String(t.audioUrl || ''),
      videoUrl: t.videoUrl ? String(t.videoUrl) : undefined,
      hasMV: Boolean(t.hasMV),
      lyrics: Array.isArray(t.lyrics) ? t.lyrics : undefined,
      genre: String(t.genre || ''),
      dateAdded: Number(t.dateAdded) || Date.now(),
      playCount: Number(t.playCount) || 0,
      folder: String(t.folder || ''),
      isFavorite: Boolean(t.isFavorite),
      fileSize: t.fileSize ? String(t.fileSize) : undefined,
      fileFormat: t.fileFormat,
      isVideoOnly: Boolean(t.isVideoOnly)
    }));
  };

  const safeStringify = (data: unknown): string => {
    const seen = new WeakSet();
    return JSON.stringify(data, (key, value) => {
      if (typeof value === 'object' && value !== null) {
        if (typeof Node !== 'undefined' && value instanceof Node) return undefined;
        if (typeof window !== 'undefined' && (value === window || value === document)) return undefined;
        if (seen.has(value)) return undefined;
        seen.add(value);
      }
      return value;
    });
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const customOrFavorites = tracks.filter(t => t.isFavorite || t.id.startsWith('local-') || !t.id.startsWith('android-media-'));
        const toSave = customOrFavorites.length > 0 ? customOrFavorites.slice(0, 60) : tracks.slice(0, 40);
        const sanitized = sanitizeTracksForStorage(toSave);
        localStorage.setItem('lerza_tracks', safeStringify(sanitized));
      } catch (e) {
        console.warn('Tracks storage warning handled gracefully:', e);
      }
    }, 1200);

    return () => clearTimeout(timer);
  }, [tracks]);

  useEffect(() => {
    try {
      localStorage.setItem('lerza_playlists', safeStringify(playlists));
    } catch (e) {}
  }, [playlists]);

  useEffect(() => {
    try {
      localStorage.setItem('lerza_settings', safeStringify(settings));
    } catch (e) {}
  }, [settings]);

  // Persist last played track for automatic resumption in mini player
  useEffect(() => {
    if (currentTrack) {
      try {
        localStorage.setItem('lerza_last_played_track', safeStringify(currentTrack));
      } catch (e) {}
    }
  }, [currentTrack]);

  // Debounced persistence of current playback position
  useEffect(() => {
    if (currentTime > 0) {
      try {
        localStorage.setItem('lerza_last_played_time', String(currentTime));
      } catch (e) {}
    }
  }, [currentTime]);

  useEffect(() => {
    if (typeof navigator !== 'undefined' && 'onLine' in navigator) {
      setIsOnline(navigator.onLine);
    }
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // --- Header Smooth Scroll Animation State ---
  const HEADER_COLLAPSE_HEIGHT = 60; // Total height of the upper LERZA PLAYER header
  const [headerTranslateY, setHeaderTranslateY] = useState(0); // 0 = fully visible, 60 = header tucked away, tabs pinned to top: 0
  const lastScrollTopRef = useRef(0);
  const [exitToastVisible, setExitToastVisible] = useState(false);
  const lastBackPressTimeRef = useRef(0);

  const handleTabChange = (newTab: CategoryTab) => {
    if (newTab !== activeTab) {
      setActiveTab(newTab);
      setHeaderTranslateY(0);
      setTabHistory(prev => [...prev.filter(t => t !== newTab), newTab]);
    }
  };

  const handleChangeVolumeMultiplier = (mult: number) => {
    setVolumeMultiplier(mult);
    AudioEngine.setVolumeMultiplier(mult);
  };

  // Comprehensive hierarchical back button handler
  const handleAppBackPress = (): boolean => {
    // 1. Highest Priority: Informational, update, and permission dialogs
    if (isUpdateModalOpen) {
      setIsUpdateModalOpen(false);
      return true;
    }
    if (isInterstitialOpen) {
      setIsInterstitialOpen(false);
      return true;
    }
    if (isPermissionModalOpen) {
      setIsPermissionModalOpen(false);
      return true;
    }
    if (isLockDialogOpen) {
      setIsLockDialogOpen(false);
      setLockDialogPendingAction(null);
      return true;
    }
    if (isVaultModalOpen) {
      setIsVaultModalOpen(false);
      return true;
    }
    if (trackForPlaylistModal) {
      setTrackForPlaylistModal(null);
      return true;
    }

    // 2. Main Overlays and Drawers
    if (isSettingsOpen) {
      setIsSettingsOpen(false);
      return true;
    }
    if (isEqualizerOpen) {
      setIsEqualizerOpen(false);
      return true;
    }
    if (isLyricsOpen) {
      setIsLyricsOpen(false);
      return true;
    }
    if (isQueueOpen) {
      setIsQueueOpen(false);
      return true;
    }

    // 3. Fullscreen Player: minimize smoothly to bottom MiniPlayer without interrupting audio
    if (isFullScreenOpen) {
      try {
        if (document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        }
      } catch (_) {}
      if ((window as any).AndroidBridge?.toggleFullscreen) {
        try { (window as any).AndroidBridge.toggleFullscreen(false); } catch (_) {}
      }
      if ((window as any).AndroidBridge?.setScreenOrientation) {
        try { (window as any).AndroidBridge.setScreenOrientation('portrait'); } catch (_) {}
      }
      try {
        if (window.screen && (window.screen as any).orientation?.unlock) {
          (window.screen as any).orientation.unlock();
        }
      } catch (_) {}
      setIsFullScreenOpen(false);
      return true;
    }

    // 4. Search Mode: cancel search and return to home page
    if (isSearchOpen || searchQuery.trim().length > 0) {
      setIsSearchOpen(false);
      setSearchQuery('');
      if (activeTab !== 'videos') {
        setActiveTab('videos');
        setTabHistory(['videos']);
      }
      return true;
    }

    // 5. Active subview collapse (e.g. open playlist detail, favorite playlist, folder/album detail)
    const customEvent = new CustomEvent('subview-back-press', { cancelable: true });
    const subviewHandled = !window.dispatchEvent(customEvent);
    if (subviewHandled) {
      return true;
    }

    // 6. Tab History Stack: return through previously visited tabs
    if (tabHistory.length > 1) {
      const nextHistory = [...tabHistory];
      nextHistory.pop(); // Pop current tab
      const previousTab = nextHistory[nextHistory.length - 1] || 'songs';
      setTabHistory(nextHistory);
      setActiveTab(previousTab);
      return true;
    }

    // 7. If not on songs (Home), return to songs tab
    if (activeTab !== 'songs') {
      setActiveTab('songs');
      setTabHistory(['songs']);
      return true;
    }

    // 8. Root level (Home screen = 'songs' tab, no modals/dialogs open)
    // Double-tap exit logic for PWA / Mobile Web browser
    const now = Date.now();
    if (now - lastBackPressTimeRef.current < 2000) {
      return false; // Allow native minimize or exit
    } else {
      lastBackPressTimeRef.current = now;
      setExitToastVisible(true);
      setTimeout(() => setExitToastVisible(false), 2000);
      return false;
    }
  };

  // Expose back button handler for AndroidBridge / WebView call:
  useEffect(() => {
    (window as any).handleAppBackPress = handleAppBackPress;
  });

  // Intercept browser and mobile back gestures via popstate
  useEffect(() => {
    const handlePopState = () => {
      const handled = handleAppBackPress();
      if (handled) {
        window.history.pushState({ appNav: true }, '');
      }
    };
    window.history.pushState({ appNav: true }, '');
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [
    isUpdateModalOpen,
    isInterstitialOpen,
    isPermissionModalOpen,
    isLockDialogOpen,
    isVaultModalOpen,
    trackForPlaylistModal,
    isSettingsOpen,
    isEqualizerOpen,
    isLyricsOpen,
    isQueueOpen,
    isFullScreenOpen,
    isSearchOpen,
    searchQuery,
    tabHistory,
    activeTab
  ]);

  // Android MediaStore Automatic Scan Listeners (Both Audio & Video)
  useEffect(() => {
    (window as any).onAndroidLocalTracksScanned = (scannedTracks: MediaTrack[]) => {
      if (Array.isArray(scannedTracks) && scannedTracks.length > 0) {
        const normalized = scannedTracks.map((raw, idx) => {
          const t = raw as any;
          const rawId = t.id || `android-media-${Date.now()}-${idx}`;
          return normalizeTrack({
            ...t,
            id: rawId,
            duration: Number(t.duration) || 0,
            filePath: t.filePath || t.path || t.data,
            audioUrl: t.audioUrl || t.url || t.uri || t.contentUri
          });
        });
        setTracks(prev => {
          const existingIds = new Set(prev.map(t => t.id));
          const existingSignatures = new Set(prev.map(t => (t as any).filePath || `${t.title}_${t.artist}`));
          const newItems = normalized.filter(t => 
            !existingIds.has(t.id) && 
            !existingSignatures.has((t as any).filePath || `${t.title}_${t.artist}`)
          );
          if (newItems.length === 0) return prev;
          return [...newItems, ...prev];
        });
      }
    };

    const handleScannedVideos = (scannedVideos: MediaTrack[]) => {
      if (Array.isArray(scannedVideos) && scannedVideos.length > 0) {
        const normalized: MediaTrack[] = scannedVideos.map((raw, idx) => {
          const v = raw as any;
          const id = v.id || `android-video-${Date.now()}-${idx}`;
          const vidId = id.startsWith('android-video-') ? id.replace('android-video-', '') : id;
          const pathOrUri = v.videoUrl || v.audioUrl || (id.startsWith('android-video-') ? `https://appassets.androidplatform.net/local-video/${vidId}` : (v.filePath || v.path || ''));
          const namePart = (v.title && v.title !== 'Unknown') ? v.title : (pathOrUri ? pathOrUri.split('/').pop().replace(/\.[^/.]+$/, '') : `Video ${idx + 1}`);
          const folderPart = v.folder || (pathOrUri ? (pathOrUri.split('/').slice(-2, -1)[0] || 'Videos') : 'Videos');
          const ext = (pathOrUri.split('.').pop() || 'MP4').toUpperCase();

          return normalizeTrack({
            id,
            title: namePart,
            artist: v.artist && v.artist !== 'Unknown' ? v.artist : 'Local Video',
            album: v.album && v.album !== 'Unknown' ? v.album : folderPart,
            duration: Number(v.duration) || 0,
            videoUrl: pathOrUri.startsWith('/storage/') || pathOrUri.startsWith('/sdcard/') ? `https://appassets.androidplatform.net/local-video/${vidId}` : pathOrUri,
            audioUrl: pathOrUri.startsWith('/storage/') || pathOrUri.startsWith('/sdcard/') ? `https://appassets.androidplatform.net/local-video/${vidId}` : pathOrUri,
            artworkUrl: v.artworkUrl || v.thumbnailUrl || v.thumbUrl || `https://appassets.androidplatform.net/local-video-thumb/${vidId}`,
            hasMV: true,
            isVideoOnly: true,
            genre: 'Video',
            folder: folderPart,
            fileFormat: v.fileFormat || ext,
            dateAdded: Number(v.dateAdded) || Date.now(),
            playCount: Number(v.playCount) || 0,
            isFavorite: Boolean(v.isFavorite)
          });
        });

        setTracks(prev => {
          const existingIds = new Set(prev.map(t => t.id));
          const existingUrls = new Set(prev.map(t => t.videoUrl || (t as any).filePath || t.id));
          const newItems = normalized.filter(t => 
            !existingIds.has(t.id) && 
            !existingUrls.has(t.videoUrl || (t as any).filePath || t.id)
          );
          if (newItems.length === 0) return prev;
          return [...newItems, ...prev];
        });
      }
    };

    (window as any).onAndroidLocalVideosScanned = handleScannedVideos;
    (window as any).onLocalVideosScanned = handleScannedVideos;
    (window as any).onVideosScanned = handleScannedVideos;
    (window as any).onReceiveVideos = handleScannedVideos;
    (window as any).onDeviceVideosScanned = handleScannedVideos;

    // Auto-scan local files on app startup
    if ((window as any).AndroidBridge?.scanLocalAudio) {
      try {
        (window as any).AndroidBridge.scanLocalAudio();
        if ((window as any).AndroidBridge?.scanLocalVideos) {
          (window as any).AndroidBridge.scanLocalVideos();
        }
        if ((window as any).AndroidBridge?.scanVideos) {
          (window as any).AndroidBridge.scanVideos();
        }
        if ((window as any).AndroidBridge?.scanAllVideos) {
          (window as any).AndroidBridge.scanAllVideos();
        }
      } catch (e) {
        console.warn('Initial native scan trigger error:', e);
      }
    }

    const scanTimer = setTimeout(() => {
      if ((window as any).AndroidBridge?.scanLocalAudio) {
        try {
          (window as any).AndroidBridge.scanLocalAudio();
          (window as any).AndroidBridge.scanLocalVideos?.();
          (window as any).AndroidBridge.scanVideos?.();
          (window as any).AndroidBridge.scanAllVideos?.();
        } catch (e) {}
      }
    }, 1200);

    return () => clearTimeout(scanTimer);
  }, []);

  // Automatic check for updates on app startup (queries https://lerzaplayer.vercel.app)
  useEffect(() => {
    const updateTimer = setTimeout(() => {
      checkForUpdates(false);
    }, 2000);
    return () => clearTimeout(updateTimer);
  }, []);

  // Background Media Notification & Lock Screen Synchronization with Artwork
  useEffect(() => {
    if (!currentTrack) return;

    AudioEngine.updateMediaSession({
      title: currentTrack.title,
      artist: currentTrack.artist,
      album: currentTrack.album,
      artworkUrl: currentTrack.artworkUrl || '/app-icon.png',
      isPlaying,
      onPlay: handlePlay,
      onPause: handlePause,
      onNext: () => handleNext(false),
      onPrev: handlePrev,
      onSeek: handleSeek
    });

    AudioEngine.updatePositionState({
      duration: duration || currentTrack.duration,
      position: currentTime,
      playbackRate: settings.playbackSpeed || 1.0
    });

    if ((window as any).AndroidBridge?.updateNotificationWithArt) {
      try {
        (window as any).AndroidBridge.updateNotificationWithArt(
          currentTrack.title,
          currentTrack.artist,
          currentTrack.album,
          isPlaying,
          currentTrack.artworkUrl || '',
          currentTrack.id
        );
      } catch (e) {}
    } else if ((window as any).AndroidBridge?.updateNotification) {
      try {
        (window as any).AndroidBridge.updateNotification(
          currentTrack.title,
          currentTrack.artist,
          currentTrack.album,
          isPlaying
        );
      } catch (e) {}
    }
  }, [currentTrack, isPlaying, duration, currentTime, settings.playbackSpeed]);

  // Lark Player-Style Dynamic Finger-Tracking Sticky Header & Tab Bar Logic
  const handleMainScroll = (e: React.UIEvent<HTMLElement>) => {
    const currentScrollY = e.currentTarget.scrollTop;
    const delta = currentScrollY - lastScrollTopRef.current;

    // Keep header visible while search input is active
    if (isSearchOpen) {
      setHeaderTranslateY(0);
      lastScrollTopRef.current = currentScrollY;
      return;
    }

    if (currentScrollY <= 0) {
      // Reached top of list: header is fully shown
      setHeaderTranslateY(0);
    } else if (delta > 0) {
      // User scrolling down through list (finger moving UP):
      // Header and tabs move up smoothly together until tabs stick to top: 0
      setHeaderTranslateY(prev => Math.min(HEADER_COLLAPSE_HEIGHT, Math.max(0, prev + delta)));
    } else if (delta < 0) {
      // User scrolling up towards top (finger pulling DOWN):
      // Header smoothly returns into view
      setHeaderTranslateY(prev => Math.max(0, prev + delta));
    }

    lastScrollTopRef.current = currentScrollY;
  };

  const isVideoFile = (t: MediaTrack | null | undefined): boolean => {
    if (!t) return false;
    if (t.isVideoOnly || t.hasMV) return true;
    if (t.videoUrl && t.videoUrl.trim().length > 0) return true;
    const format = (t.fileFormat || '').toUpperCase();
    if (['MP4', 'MKV', 'WEBM', 'MOV', '3GP', 'AVI', 'FLV', 'M4V', 'TS', 'WMV'].includes(format)) return true;
    const url = (t.videoUrl || (t as any).filePath || (t as any).uri || (t as any).contentUri || (t as any).path || t.audioUrl || '').toLowerCase();
    if (/\.(mp4|mkv|webm|mov|3gp|avi|flv|m4v|ts|wmv)(\?.*)?$/i.test(url)) return true;
    if (t.genre && t.genre.toLowerCase() === 'video') return true;
    return false;
  };

  const handlePlay = () => {
    if (!currentTrack) return;
    AudioEngine.resume();

    if (displayMode === 'video') {
      const vUrl = getPlayableMediaUrl(currentTrack, true);
      if (videoRef.current) {
        if (vUrl && videoRef.current.src !== vUrl) {
          videoRef.current.src = vUrl;
        }
        if (currentTime > 0 && Math.abs(videoRef.current.currentTime - currentTime) > 1) {
          try { videoRef.current.currentTime = currentTime; } catch (e) {}
        }
        videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {
          // Fallback to audio element if video playback encounters an error
          if (audioRef.current && vUrl) {
            audioRef.current.src = vUrl;
            audioRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
          } else {
            setIsPlaying(false);
          }
        });
      } else if (audioRef.current) {
        if (vUrl && audioRef.current.src !== vUrl) {
          audioRef.current.src = vUrl;
        }
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
      }
    } else {
      const aUrl = getPlayableMediaUrl(currentTrack, false);
      if (audioRef.current) {
        try {
          AudioEngine.init(audioRef.current);
          AudioEngine.resume();
          AudioEngine.setVolumeMultiplier(volumeMultiplier);
        } catch (_) {}

        if (aUrl && audioRef.current.src !== aUrl) {
          audioRef.current.src = aUrl;
        }
        if (currentTime > 0 && Math.abs(audioRef.current.currentTime - currentTime) > 1) {
          try { audioRef.current.currentTime = currentTime; } catch (e) {}
        }
        audioRef.current.play().then(() => setIsPlaying(true)).catch((err) => {
          console.warn('Audio play error:', err);
          setIsPlaying(false);
        });
      }
    }
  };

  const handlePause = () => {
    if (audioRef.current) {
      try { audioRef.current.pause(); } catch (_) {}
    }
    if (videoRef.current) {
      try { videoRef.current.pause(); } catch (_) {}
    }
    setIsPlaying(false);
  };

  const handleTogglePlay = () => {
    if (isPlaying) handlePause();
    else handlePlay();
  };

  const playTrack = (track: MediaTrack, newMode?: PlayerDisplayMode, autoOpenFullScreen = true, customQueue?: MediaTrack[]) => {
    const normalized = normalizeTrack(track);
    setCurrentTrack(normalized);
    setCurrentTime(0);
    // Instantly reset duration to the track's known duration to prevent timeline desync
    setDuration(normalized.duration > 0 ? normalized.duration : 0);

    const isVid = isVideoFile(normalized);
    const mode = isVid ? 'video' : (newMode === 'video' ? 'video' : 'audio');
    setDisplayMode(mode);

    if (autoOpenFullScreen) {
      setIsFullScreenOpen(true);
    }

    // Determine the active list/queue
    const activeList = (customQueue && customQueue.length > 0)
      ? customQueue 
      : (mode === 'video' ? (videosOnly.length > 0 ? videosOnly : [normalized]) : (songsOnly.length > 0 ? songsOnly : [normalized]));

    const trackIndex = activeList.findIndex(t => t.id === normalized.id);
    if (trackIndex !== -1) {
      setQueue(activeList);
      setQueueIndex(trackIndex);
    } else {
      const merged = [normalized, ...activeList.filter(t => t.id !== normalized.id)];
      setQueue(merged);
      setQueueIndex(0);
    }

    setTracks(prev => prev.map(t => t.id === normalized.id ? { ...t, playCount: (t.playCount || 0) + 1 } : t));

    // Synchronous AudioEngine resume inside user interaction
    AudioEngine.resume();
    isSwitchingTrackRef.current = true;
    setIsPlaying(true);

    const candidates = getMediaCandidateUrls(normalized, mode === 'video');
    const playableMediaSrc = candidates[0] || getPlayableMediaUrl(normalized, mode === 'video');

    if (mode === 'video') {
      if (audioRef.current) {
        try {
          audioRef.current.pause();
          audioRef.current.removeAttribute('src');
          audioRef.current.load();
        } catch (_) {}
      }
      if (videoRef.current && playableMediaSrc) {
        if (videoRef.current.src !== playableMediaSrc) {
          videoRef.current.src = playableMediaSrc;
          videoRef.current.load();
        }
        videoRef.current.currentTime = 0;
        videoRef.current.play().then(() => {
          isSwitchingTrackRef.current = false;
          setIsPlaying(true);
        }).catch((e) => {
          console.warn("Video play exception, checking fallback candidate:", e);
          if (candidates.length > 1 && videoRef.current) {
            videoRef.current.src = candidates[1];
            videoRef.current.play().then(() => {
              isSwitchingTrackRef.current = false;
              setIsPlaying(true);
            }).catch(() => {
              isSwitchingTrackRef.current = false;
              setIsPlaying(false);
            });
          } else {
            isSwitchingTrackRef.current = false;
            setIsPlaying(false);
          }
        });
      }
      if ((window as any).AndroidBridge?.playVideo) {
        try {
          (window as any).AndroidBridge.playVideo(playableMediaSrc, normalized.title);
        } catch (_) {}
      }
    } else {
      // Audio mode
      if (videoRef.current) {
        try { videoRef.current.pause(); } catch (_) {}
      }
      if (audioRef.current) {
        try {
          AudioEngine.init(audioRef.current);
          AudioEngine.resume();
          AudioEngine.setVolumeMultiplier(volumeMultiplier);
        } catch (_) {}

        // Multi-candidate playback retry to ensure local songs and streams play reliably
        const playWithCandidates = (index: number) => {
          if (!audioRef.current || index >= candidates.length) {
            const fallback = normalized.videoUrl;
            if (fallback && audioRef.current && audioRef.current.src !== fallback) {
              audioRef.current.src = fallback;
              audioRef.current.play().then(() => {
                isSwitchingTrackRef.current = false;
                setIsPlaying(true);
              }).catch(() => {
                isSwitchingTrackRef.current = false;
                setIsPlaying(false);
              });
            } else {
              isSwitchingTrackRef.current = false;
              setIsPlaying(false);
            }
            return;
          }

          const candidateSrc = candidates[index];
          if (!candidateSrc) {
            playWithCandidates(index + 1);
            return;
          }

          if (audioRef.current.src !== candidateSrc) {
            audioRef.current.src = candidateSrc;
            audioRef.current.load();
          }
          audioRef.current.currentTime = 0;
          audioRef.current.play().then(() => {
            isSwitchingTrackRef.current = false;
            setIsPlaying(true);
          }).catch((err) => {
            console.warn(`Audio playback attempt failed for candidate [${index}]: ${candidateSrc}`, err);
            playWithCandidates(index + 1);
          });
        };

        playWithCandidates(0);
      }
    }
  };

  const handleNext = (isAutomatic = false) => {
    const activeQueue = queue.length > 0 ? queue : (displayMode === 'video' ? videosOnly : songsOnly);
    if (activeQueue.length === 0) return;

    // When Repeat Mode is 'one' and track ended on its own, loop the exact same track repeatedly!
    if (repeatMode === 'one' && isAutomatic) {
      handleSeek(0);
      if (displayMode === 'video' && videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      } else if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
      return;
    }

    if (isShuffle) {
      let nextIdx = queueIndex;
      if (activeQueue.length > 1) {
        const availableIndices = activeQueue.map((_, i) => i).filter(i => i !== queueIndex);
        nextIdx = availableIndices[Math.floor(Math.random() * availableIndices.length)];
      }
      setShuffleHistory(prev => [...prev.slice(-30), queueIndex]);
      setQueueIndex(nextIdx);
      const targetTrack = activeQueue[nextIdx];
      const targetMode = isVideoFile(targetTrack) ? 'video' : 'audio';
      playTrack(targetTrack, targetMode, isFullScreenOpen, activeQueue);
      return;
    }

    // Strict sequential playback: exactly the next song in the active playlist/list
    const nextIdx = queueIndex + 1;
    if (nextIdx >= activeQueue.length) {
      if (repeatMode === 'off' && isAutomatic) {
        handlePause();
        return;
      }
      // Wrap cleanly to the first song of the list
      setQueueIndex(0);
      const targetTrack = activeQueue[0];
      const targetMode = isVideoFile(targetTrack) ? 'video' : 'audio';
      playTrack(targetTrack, targetMode, isFullScreenOpen, activeQueue);
    } else {
      setQueueIndex(nextIdx);
      const targetTrack = activeQueue[nextIdx];
      const targetMode = isVideoFile(targetTrack) ? 'video' : 'audio';
      playTrack(targetTrack, targetMode, isFullScreenOpen, activeQueue);
    }
  };

  const handlePrev = () => {
    const activeQueue = queue.length > 0 ? queue : (displayMode === 'video' ? videosOnly : songsOnly);
    if (activeQueue.length === 0) return;

    if (isShuffle && shuffleHistory.length > 0) {
      const historyCopy = [...shuffleHistory];
      const prevIdx = historyCopy.pop()!;
      setShuffleHistory(historyCopy);
      if (activeQueue[prevIdx]) {
        setQueueIndex(prevIdx);
        const targetTrack = activeQueue[prevIdx];
        const targetMode = isVideoFile(targetTrack) ? 'video' : 'audio';
        playTrack(targetTrack, targetMode, isFullScreenOpen, activeQueue);
        return;
      }
    }

    // Strict sequential playback: exactly the previous song in the playlist/list
    const prevIdx = queueIndex - 1;
    if (prevIdx < 0) {
      // Wrap to the last song of the list
      const targetIdx = activeQueue.length - 1;
      setQueueIndex(targetIdx);
      const targetTrack = activeQueue[targetIdx];
      const targetMode = isVideoFile(targetTrack) ? 'video' : 'audio';
      playTrack(targetTrack, targetMode, isFullScreenOpen, activeQueue);
    } else {
      setQueueIndex(prevIdx);
      const targetTrack = activeQueue[prevIdx];
      const targetMode = isVideoFile(targetTrack) ? 'video' : 'audio';
      playTrack(targetTrack, targetMode, isFullScreenOpen, activeQueue);
    }
  };

  const handleToggleShuffle = () => {
    setIsShuffle(prev => {
      const next = !prev;
      if (next) {
        setShuffleHistory([queueIndex]);
      } else {
        setShuffleHistory([]);
      }
      return next;
    });
  };

  const handleCycleRepeat = () => {
    // Cycles: 'off' -> 'one' (Repeat current song) -> 'all' (Repeat all) -> 'off'
    setRepeatMode(prev => {
      if (prev === 'off') return 'one';
      if (prev === 'one') return 'all';
      return 'off';
    });
  };

  const handleSeek = (seconds: number) => {
    if (!Number.isFinite(seconds) || seconds < 0) return;
    const maxDur = duration > 0 ? duration : (currentTrack?.duration || 0);
    const targetSeconds = Math.max(0, maxDur > 0 ? Math.min(maxDur, seconds) : seconds);
    
    setCurrentTime(targetSeconds);

    if (displayMode === 'video' && videoRef.current && currentTrack?.videoUrl) {
      try {
        videoRef.current.currentTime = targetSeconds;
      } catch (e) {}
    }
    if (audioRef.current && (currentTrack?.audioUrl || currentTrack?.videoUrl)) {
      try {
        audioRef.current.currentTime = targetSeconds;
      } catch (e) {}
    }

    // Immediately synchronize lock screen & notification seekbar
    if ((window as any).AndroidBridge?.updateSeekPosition) {
      try {
        (window as any).AndroidBridge.updateSeekPosition(
          Math.floor(targetSeconds),
          Math.floor(maxDur || targetSeconds)
        );
      } catch (e) {}
    }
  };

  useEffect(() => {
    (window as any).handleNotificationAction = (action: string, arg?: number) => {
      if (action === 'play') handlePlay();
      else if (action === 'pause') handlePause();
      else if (action === 'playPause') handleTogglePlay();
      else if (action === 'next') handleNext(false);
      else if (action === 'prev') handlePrev();
      else if (action === 'seek' && typeof arg === 'number') handleSeek(arg);
    };
  }, [isPlaying, queueIndex, queue, isShuffle, repeatMode, duration, displayMode]);

  const handleToggleDisplayMode = () => {
    if (!currentTrack || !currentTrack.hasMV) return;
    const newMode: PlayerDisplayMode = displayMode === 'audio' ? 'video' : 'audio';
    const savedTime = currentTime;
    const wasPlaying = isPlaying;

    setDisplayMode(newMode);

    setTimeout(() => {
      if (newMode === 'video' && videoRef.current) {
        if (audioRef.current) audioRef.current.pause();
        videoRef.current.currentTime = savedTime;
        if (wasPlaying) videoRef.current.play();
      } else if (newMode === 'audio' && audioRef.current) {
        if (videoRef.current) videoRef.current.pause();
        audioRef.current.currentTime = savedTime;
        if (wasPlaying) audioRef.current.play();
      }
    }, 50);
  };

  const handleToggleFavorite = (trackId: string) => {
    setTracks(prev => prev.map(t => t.id === trackId ? { ...t, isFavorite: !t.isFavorite } : t));
    if (currentTrack?.id === trackId) {
      setCurrentTrack(prev => prev ? { ...prev, isFavorite: !prev.isFavorite } : null);
    }
  };

  const handleAddToQueue = (track: MediaTrack) => {
    setQueue(prev => [...prev, track]);
  };

  const handlePlayNext = (track: MediaTrack) => {
    const newQ = [...queue];
    newQ.splice(queueIndex + 1, 0, track);
    setQueue(newQ);
  };

  const handleRemoveFromQueue = (index: number) => {
    setQueue(prev => prev.filter((_, i) => i !== index));
  };

  const handleDeleteTrack = (trackId: string) => {
    if (currentTrack?.id === trackId) {
      handlePause();
      const remaining = tracks.filter(t => t.id !== trackId);
      setCurrentTrack(remaining.length > 0 ? remaining[0] : null);
    }

    setTracks(prev => prev.filter(t => t.id !== trackId));
    setQueue(prev => prev.filter(t => t.id !== trackId));
  };

  const handleDeleteMultipleTracks = (trackIds: string[]) => {
    const idSet = new Set(trackIds);
    if (currentTrack && idSet.has(currentTrack.id)) {
      handlePause();
      const remaining = tracks.filter(t => !idSet.has(t.id));
      setCurrentTrack(remaining.length > 0 ? remaining[0] : null);
    }

    setTracks(prev => prev.filter(t => !idSet.has(t.id)));
    setQueue(prev => prev.filter(t => !idSet.has(t.id)));
  };

  const handleClearDemoTracks = () => {
    const userOnly = tracks.filter(t => !t.id.startsWith('sample-'));
    setTracks(userOnly);
    setQueue(userOnly);
    if (currentTrack && currentTrack.id.startsWith('sample-')) {
      handlePause();
      setCurrentTrack(userOnly.length > 0 ? userOnly[0] : null);
    }
  };

  const handleCreatePlaylist = (title: string, description: string) => {
    const newPl: Playlist = {
      id: `pl-${Date.now()}`,
      title,
      description,
      trackIds: [],
      createdAt: Date.now()
    };
    setPlaylists(prev => [newPl, ...prev]);
  };

  const handleDeletePlaylist = (playlistId: string) => {
    setPlaylists(prev => prev.filter(p => p.id !== playlistId));
  };

  const handlePlayPlaylist = (playlist: Playlist, shuffle = false) => {
    const pTracks = tracks.filter(t => !hiddenTrackIds.includes(t.id) && playlist.trackIds.includes(t.id));
    if (pTracks.length === 0) return;
    setQueue(pTracks);
    setIsShuffle(shuffle);
    const startIdx = shuffle ? Math.floor(Math.random() * pTracks.length) : 0;
    setQueueIndex(startIdx);
    playTrack(pTracks[startIdx]);
  };

  const handleOpenVault = () => {
    if (!vaultConfig.hasSetup) {
      setLockDialogMode('setup');
      setLockDialogPendingAction(() => () => {
        setIsVaultModalOpen(true);
      });
      setIsLockDialogOpen(true);
    } else {
      setLockDialogMode('unlock');
      setLockDialogPendingAction(() => () => {
        setIsVaultModalOpen(true);
      });
      setIsLockDialogOpen(true);
    }
  };

  const handleHideTracks = (trackIdsToHide: string[]) => {
    if (!trackIdsToHide || trackIdsToHide.length === 0) return;

    const performHide = () => {
      setHiddenTrackIds(prev => {
        const next = new Set([...prev, ...trackIdsToHide]);
        return Array.from(next);
      });
      if (currentTrack && trackIdsToHide.includes(currentTrack.id)) {
        handleNext();
      }
    };

    if (!vaultConfig.hasSetup) {
      setLockDialogMode('setup');
      setLockDialogPendingAction(() => () => {
        performHide();
      });
      setIsLockDialogOpen(true);
    } else {
      performHide();
    }
  };

  const handleLockSuccess = (secret: string, lockType: VaultLockType) => {
    if (lockDialogMode === 'setup') {
      const newConfig: VaultConfig = {
        lockType,
        lockSecret: secret,
        hasSetup: true
      };
      setVaultConfig(newConfig);
      setIsLockDialogOpen(false);
      if (lockDialogPendingAction) {
        lockDialogPendingAction();
        setLockDialogPendingAction(null);
      }
    } else {
      setIsLockDialogOpen(false);
      if (lockDialogPendingAction) {
        lockDialogPendingAction();
        setLockDialogPendingAction(null);
      }
    }
  };

  const handleUnhideTrack = (trackId: string) => {
    setHiddenTrackIds(prev => prev.filter(id => id !== trackId));
  };

  const handleUnhideAll = () => {
    setHiddenTrackIds([]);
  };

  const handleAddTrackToPlaylist = (playlistId: string, trackId: string) => {
    setPlaylists(prev => prev.map(p => {
      if (p.id === playlistId && !p.trackIds.includes(trackId)) {
        return { ...p, trackIds: [...p.trackIds, trackId] };
      }
      return p;
    }));
  };

  const handleBandGainChange = (idx: number, gain: number) => {
    const updated = [...eqBands];
    updated[idx] = gain;
    setEqBands(updated);
    AudioEngine.setBandGain(idx, gain);
    setActiveEqPreset('custom');
  };

  const handleSelectEqPreset = (presetName: string) => {
    const gains = EQUALIZER_PRESETS[presetName] || [0, 0, 0, 0, 0];
    setEqBands(gains);
    AudioEngine.setAllBands(gains);
    setActiveEqPreset(presetName);
  };

  const handleBassBoostChange = (level: number) => {
    setSettings(prev => ({ ...prev, bassBoostLevel: level }));
    AudioEngine.setBassBoost(level);
  };

  const handleOpenSettings = () => {
    if (!settings.isAdsRemoved && isOnline && !hasShownSessionInterstitial && !isPlaying) {
      setIsInterstitialOpen(true);
      setHasShownSessionInterstitial(true);
    }
    setIsSettingsOpen(true);
  };

  const isWhatsAppOrCallRecording = (t: MediaTrack): boolean => {
    const str = `${t.title} ${t.folder} ${t.artist} ${t.album}`.toLowerCase();
    const isWA = str.includes('whatsapp') || str.includes('ptt-') || /^aud-\d{8}-wa/i.test(t.title);
    const isCall = str.includes('call_rec') || str.includes('call record') || str.includes('voice recorder');
    return isWA || isCall;
  };

  const hiddenIdSet = new Set(hiddenTrackIds);
  const visibleTracks = tracks.filter(t => !hiddenIdSet.has(t.id));
  const hiddenTracksList = tracks.filter(t => hiddenIdSet.has(t.id));

  const filteredTracks = useMemo(() => {
    const base = visibleTracks.filter(t => {
      if (settings.filterWhatsAppAndRecordings && isWhatsAppOrCallRecording(t)) {
        return false;
      }
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        t.title.toLowerCase().includes(q) ||
        t.artist.toLowerCase().includes(q) ||
        t.album.toLowerCase().includes(q) ||
        t.folder.toLowerCase().includes(q)
      );
    });

    if (!searchQuery.trim()) {
      return base;
    }

    const q = searchQuery.toLowerCase().trim();
    // Prioritize results that start with the query characters at the very top:
    return [...base].sort((a, b) => {
      const aTitle = a.title.toLowerCase();
      const bTitle = b.title.toLowerCase();
      const aStartsTitle = aTitle.startsWith(q);
      const bStartsTitle = bTitle.startsWith(q);

      if (aStartsTitle && !bStartsTitle) return -1;
      if (!aStartsTitle && bStartsTitle) return 1;

      const aArtist = a.artist.toLowerCase();
      const bArtist = b.artist.toLowerCase();
      const aStartsArtist = aArtist.startsWith(q);
      const bStartsArtist = bArtist.startsWith(q);

      if (aStartsArtist && !bStartsArtist) return -1;
      if (!aStartsArtist && bStartsArtist) return 1;

      // Check if any word starts with query
      const aWordStart = aTitle.split(/[\s\-_]+/).some(w => w.startsWith(q));
      const bWordStart = bTitle.split(/[\s\-_]+/).some(w => w.startsWith(q));
      if (aWordStart && !bWordStart) return -1;
      if (!aWordStart && bWordStart) return 1;

      // Earlier index in title wins
      const aIndex = aTitle.indexOf(q);
      const bIndex = bTitle.indexOf(q);
      if (aIndex !== -1 && bIndex !== -1 && aIndex !== bIndex) {
        return aIndex - bIndex;
      }

      return aTitle.localeCompare(bTitle);
    });
  }, [visibleTracks, settings.filterWhatsAppAndRecordings, searchQuery]);

  const songsOnly = filteredTracks.filter(t => !isVideoFile(t));
  const videosOnly = filteredTracks.filter(t => isVideoFile(t));

  const folderSet = new Set(filteredTracks.map(t => t.folder));
  const albumSet = new Set(filteredTracks.map(t => t.album));
  const artistSet = new Set(filteredTracks.map(t => t.artist));

  const currentThemeConfig = getThemeConfig(settings.theme);
  const activeWallpaper = settings.customWallpaper || (settings as any).customWallpaperUrl;

  return (
    <ThemeProvider
      theme={settings.theme}
      onThemeChange={(newTheme) => setSettings(prev => ({ ...prev, theme: newTheme }))}
    >
      <div className={`h-screen max-h-screen flex flex-col overflow-hidden relative selection:bg-cyan-500/30 transition-colors duration-300 ${currentThemeConfig.appBg} ${currentThemeConfig.appText}`}>
      {activeWallpaper && (
        <div 
          className="fixed inset-0 pointer-events-none z-0 bg-cover bg-center bg-no-repeat transition-all duration-500"
          style={{
            backgroundImage: `url(${activeWallpaper})`,
            opacity: settings.wallpaperOpacity ?? 0.35,
            filter: 'contrast(1.05) saturate(1.1)'
          }}
        />
      )}

      <audio
        ref={audioRef}
        crossOrigin="anonymous"
        src={(displayMode === 'video' || (currentTrack && isVideoFile(currentTrack))) ? undefined : (currentTrack ? getPlayableMediaUrl(currentTrack, false) : undefined)}
        preload="metadata"
        loop={repeatMode === 'one'}
        onPlay={() => {
          isSwitchingTrackRef.current = false;
          setIsPlaying(true);
        }}
        onPlaying={() => {
          isSwitchingTrackRef.current = false;
          setIsPlaying(true);
        }}
        onPause={() => {
          if (isSwitchingTrackRef.current) return;
          if (audioRef.current?.paused) {
            setIsPlaying(false);
          }
        }}
        onError={(e) => {
          console.warn('Audio tag playback error:', e);
          if (currentTrack) {
            const candidates = getMediaCandidateUrls(currentTrack, false);
            const currentSrc = audioRef.current?.src || '';
            const nextCandidate = candidates.find(c => c && !currentSrc.includes(c));
            if (nextCandidate && audioRef.current) {
              audioRef.current.src = nextCandidate;
              audioRef.current.play().catch(() => {});
            } else if (currentTrack.videoUrl && audioRef.current && audioRef.current.src !== currentTrack.videoUrl) {
              audioRef.current.src = currentTrack.videoUrl;
              audioRef.current.play().catch(() => {});
            }
          }
        }}
        onDurationChange={() => {
          if (audioRef.current) {
            const d = audioRef.current.duration;
            if (Number.isFinite(d) && d > 0) {
              setDuration(d);
              if (currentTrack && Math.abs((currentTrack.duration || 0) - d) > 1) {
                setCurrentTrack(prev => prev ? { ...prev, duration: d } : null);
                setTracks(prev => prev.map(t => t.id === currentTrack.id ? { ...t, duration: d } : t));
              }
            }
          }
        }}
        onLoadedMetadata={() => {
          if (audioRef.current) {
            const d = audioRef.current.duration;
            if (Number.isFinite(d) && d > 0) {
              setDuration(d);
              if (currentTrack && Math.abs((currentTrack.duration || 0) - d) > 1) {
                setCurrentTrack(prev => prev ? { ...prev, duration: d } : null);
                setTracks(prev => prev.map(t => t.id === currentTrack.id ? { ...t, duration: d } : t));
              }
            } else if (currentTrack && currentTrack.duration > 0) {
              setDuration(currentTrack.duration);
            }
          }
        }}
        onTimeUpdate={() => {
          if (audioRef.current && displayMode === 'audio') {
            const cur = audioRef.current.currentTime;
            const realDur = audioRef.current.duration;
            setCurrentTime(cur);
            if (Number.isFinite(realDur) && realDur > 0) {
              if (Math.abs(realDur - duration) > 0.5) {
                setDuration(realDur);
              }
            } else if (cur > duration) {
              // Ensure timeline never caps or lags behind the actual playing audio
              setDuration(cur);
            }
            if ((window as any).AndroidBridge?.updateSeekPosition) {
              try {
                const finalDur = (Number.isFinite(realDur) && realDur > 0) ? realDur : (duration || currentTrack?.duration || cur);
                (window as any).AndroidBridge.updateSeekPosition(
                  Math.floor(cur),
                  Math.floor(finalDur)
                );
              } catch (e) {}
            }
          }
        }}
        onEnded={() => {
          const finalTime = audioRef.current?.currentTime || duration;
          if (finalTime > 0) {
            setCurrentTime(finalTime);
            setDuration(finalTime);
          }
          handleNext(true);
        }}
      />

      <main 
        onScroll={handleMainScroll}
        className="flex-1 overflow-y-auto overscroll-contain min-h-0 relative z-10 pb-36"
      >
        {/* Unified Sticky Header & Category Tabs Container with Finger-Tracking Smooth Animation */}
        <div 
          className="sticky top-0 z-30 pointer-events-auto will-change-transform"
          style={{
            transform: `translate3d(0, -${headerTranslateY}px, 0)`,
            marginBottom: `-${headerTranslateY}px`,
            transition: 'transform 0.1s ease-out, margin-bottom 0.1s ease-out'
          }}
        >
          <div className="overflow-hidden bg-white text-slate-900 border-b border-slate-200/90 shadow-xs">
            <Header
              onOpenSettings={handleOpenSettings}
              onOpenEqualizer={() => setIsEqualizerOpen(true)}
              onSearchChange={setSearchQuery}
              searchQuery={searchQuery}
              isSearchOpen={isSearchOpen}
              onToggleSearch={(open) => setIsSearchOpen(open !== undefined ? open : !isSearchOpen)}
              onCloseSearchAndGoHome={() => {
                setActiveTab('videos');
                setTabHistory(['videos']);
              }}
              isOnline={isOnline}
              onToggleOnline={() => setIsOnline(!isOnline)}
              onFilesImported={(newTracks) => {
                setTracks(prev => [...newTracks, ...prev]);
                setQueue(prev => [...newTracks, ...prev]);
              }}
              totalTracksCount={tracks.length}
            />
          </div>

          <div className={`border-b ${currentThemeConfig.isDark ? 'border-white/5 bg-neutral-900/95' : 'border-black/5 bg-white/95'} backdrop-blur-xl shadow-xs`}>
            <CategoryChips
              activeTab={activeTab}
              onTabChange={handleTabChange}
              counts={{
                songs: songsOnly.length,
                videos: videosOnly.length,
                playlists: playlists.length,
                folders: folderSet.size,
                albums: albumSet.size,
                artists: artistSet.size
              }}
            />
          </div>
        </div>

        <AdBanner isOnline={isOnline} isAdsRemoved={settings.isAdsRemoved} />

        <div className="px-2 sm:px-4 py-2">
        {activeTab === 'songs' && (
          <SongsList
            songs={songsOnly}
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            onSelectTrack={(t, currentList) => {
              playTrack(t, 'audio', true, currentList || songsOnly);
            }}
            onTogglePlay={handleTogglePlay}
            onToggleFavorite={handleToggleFavorite}
            onAddToQueue={handleAddToQueue}
            onPlayNext={handlePlayNext}
            onAddToPlaylistClick={(t) => setTrackForPlaylistModal(t)}
            onDeleteTrack={handleDeleteTrack}
            onDeleteMultipleTracks={handleDeleteMultipleTracks}
            onHideTracks={handleHideTracks}
            isOnline={isOnline}
            isAdsRemoved={settings.isAdsRemoved}
          />
        )}

        {activeTab === 'videos' && (
          <VideosList
            videos={videosOnly}
            onSelectVideo={(v, currentList) => {
              playTrack(v, 'video', true, currentList || videosOnly);
            }}
            onToggleFavorite={handleToggleFavorite}
            onDeleteVideo={handleDeleteTrack}
            onDeleteMultipleVideos={handleDeleteMultipleTracks}
            onHideVideos={handleHideTracks}
            isOnline={isOnline}
            isAdsRemoved={settings.isAdsRemoved}
          />
        )}

        {activeTab === 'playlists' && (
          <PlaylistsView
            playlists={playlists}
            allTracks={visibleTracks}
            onCreatePlaylist={handleCreatePlaylist}
            onDeletePlaylist={handleDeletePlaylist}
            onPlayPlaylist={handlePlayPlaylist}
            onSelectTrack={(t, pTracks) => {
              playTrack(t, undefined, true, pTracks);
            }}
          />
        )}

        {(activeTab === 'folders' || activeTab === 'albums' || activeTab === 'artists') && (
          <FoldersAlbumsArtistsView
            type={activeTab}
            tracks={tracks}
            onSelectTrack={(t, groupTracks) => {
              playTrack(t, undefined, true, groupTracks);
            }}
          />
        )}
        </div>
      </main>

      <input 
        type="file" 
        ref={hiddenImportInputRef} 
        onChange={handleImportedLocalFiles} 
        multiple 
        accept="audio/*,video/*" 
        className="hidden" 
      />

      {/* Player Section: MiniPlayer at bottom, FullScreenPlayer when expanded */}
      <div className="relative">
        {currentTrack && !isFullScreenOpen && (
          <MiniPlayer
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            onTogglePlay={handleTogglePlay}
            onNext={handleNext}
            onPrev={handlePrev}
            onOpenFullPlayer={() => setIsFullScreenOpen(true)}
            onOpenQueue={() => setIsQueueOpen(true)}
            onSeek={handleSeek}
          />
        )}

        {isFullScreenOpen && currentTrack && (
          <FullScreenPlayer
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            repeatMode={repeatMode}
            isShuffle={isShuffle}
            displayMode={displayMode}
            playbackSpeed={settings.playbackSpeed}
            volumeMultiplier={volumeMultiplier}
            isOnline={isOnline}
            isAdsRemoved={settings.isAdsRemoved}
            sleepTimerMinutes={settings.sleepTimerMinutes}
            onSetSleepTimer={(mins) => setSettings(prev => ({ ...prev, sleepTimerMinutes: mins }))}
            onAddToPlaylistClick={() => setTrackForPlaylistModal(currentTrack)}
            onTogglePlay={handleTogglePlay}
            onSeek={handleSeek}
            onNext={() => handleNext(false)}
            onPrev={handlePrev}
            onToggleShuffle={handleToggleShuffle}
            onCycleRepeat={handleCycleRepeat}
            onToggleFavorite={handleToggleFavorite}
            onClose={() => setIsFullScreenOpen(false)}
            onOpenLyrics={() => setIsLyricsOpen(true)}
            onOpenEqualizer={() => setIsEqualizerOpen(true)}
            onOpenQueue={() => setIsQueueOpen(true)}
            onToggleDisplayMode={handleToggleDisplayMode}
            onChangeSpeed={(spd) => {
              setSettings(prev => ({ ...prev, playbackSpeed: spd }));
              if (audioRef.current) audioRef.current.playbackRate = spd;
              if (videoRef.current) videoRef.current.playbackRate = spd;
            }}
            onChangeVolumeMultiplier={(mult) => {
              setVolumeMultiplier(mult);
              AudioEngine.setVolumeMultiplier(mult);
            }}
            videoRef={videoRef}
            audioRef={audioRef}
            onPlayStateChange={(pl) => setIsPlaying(pl)}
            onTimeUpdate={(newCur, newDur) => {
              setCurrentTime(newCur);
              if (newDur && Number.isFinite(newDur) && newDur > 0 && Math.abs(newDur - duration) > 0.5) {
                setDuration(newDur);
              }
            }}
          />
        )}
      </div>

      {isLyricsOpen && currentTrack && (
        <LyricsModal
          title={currentTrack.title}
          artist={currentTrack.artist}
          lyrics={currentTrack.lyrics}
          currentTime={currentTime}
          onSeek={handleSeek}
          onClose={() => setIsLyricsOpen(false)}
        />
      )}

      {isEqualizerOpen && (
        <EqualizerModal
          bandGains={eqBands}
          bassBoost={settings.bassBoostLevel}
          virtualizer={settings.virtualizerEnabled}
          activePreset={activeEqPreset}
          onBandChange={handleBandGainChange}
          onBassBoostChange={handleBassBoostChange}
          onVirtualizerToggle={() => setSettings(prev => ({ ...prev, virtualizerEnabled: !prev.virtualizerEnabled }))}
          onSelectPreset={handleSelectEqPreset}
          onReset={() => handleSelectEqPreset('flat')}
          onClose={() => setIsEqualizerOpen(false)}
        />
      )}

      {isQueueOpen && (
        <QueueDrawer
          queue={queue}
          currentIndex={queueIndex}
          onSelectTrack={(idx) => {
            setQueueIndex(idx);
            playTrack(queue[idx]);
          }}
          onRemoveTrack={handleRemoveFromQueue}
          onClearQueue={() => setQueue([])}
          onClose={() => setIsQueueOpen(false)}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={(newVals) => setSettings(prev => ({ ...prev, ...newVals }))}
          onOpenEqualizer={() => {
            setIsSettingsOpen(false);
            setIsEqualizerOpen(true);
          }}
          onClearDemoTracks={handleClearDemoTracks}
          onClose={() => setIsSettingsOpen(false)}
          onScanAndImport={handleScanAndImport}
          currentVersion={APP_VERSION}
          currentBuild={APP_BUILD}
          onCheckForUpdates={() => checkForUpdates(true)}
          volumeMultiplier={volumeMultiplier}
          onChangeVolumeMultiplier={handleChangeVolumeMultiplier}
          hiddenTracksCount={hiddenTrackIds.length}
          onOpenVault={handleOpenVault}
          onOpenWebsite={() => {
            if (typeof window !== 'undefined') {
              window.open('https://lerzaplayer.vercel.app', '_blank');
            }
          }}
        />
      )}

      <VaultModal
        isOpen={isVaultModalOpen}
        onClose={() => setIsVaultModalOpen(false)}
        hiddenTracks={hiddenTracksList}
        onUnhideTrack={handleUnhideTrack}
        onUnhideAll={handleUnhideAll}
        onPlayTrack={(track) => {
          setIsVaultModalOpen(false);
          playTrack(track, track.isVideoOnly ? 'video' : 'audio', true, hiddenTracksList);
        }}
        onChangeLock={() => {
          setLockDialogMode('setup');
          setLockDialogPendingAction(null);
          setIsLockDialogOpen(true);
        }}
        vaultConfig={vaultConfig}
      />

      <LockDialog
        isOpen={isLockDialogOpen}
        mode={lockDialogMode}
        configuredLockType={vaultConfig.lockType}
        configuredSecret={vaultConfig.lockSecret}
        title={
          lockDialogMode === 'setup'
            ? 'Set Vault Security Lock'
            : 'Unlock Private Vault'
        }
        description={
          lockDialogMode === 'setup'
            ? 'Set a 4-digit PIN or Pattern to protect your hidden audio and video files.'
            : 'Enter your PIN or draw your pattern to access hidden files.'
        }
        onSuccess={handleLockSuccess}
        onClose={() => {
          setIsLockDialogOpen(false);
          setLockDialogPendingAction(null);
        }}
      />

      <UpdateModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
        updateInfo={updateInfo}
        currentVersion={APP_VERSION}
      />

      <AddToPlaylistModal
        track={trackForPlaylistModal}
        playlists={playlists}
        onAddTrackToPlaylist={handleAddTrackToPlaylist}
        onClose={() => setTrackForPlaylistModal(null)}
      />

      <AdInterstitialModal
        isOpen={isInterstitialOpen}
        onClose={() => setIsInterstitialOpen(false)}
      />

      <PermissionModal
        isOpen={isPermissionModalOpen}
        onGrantPermission={() => setIsPermissionModalOpen(false)}
        onDismiss={() => setIsPermissionModalOpen(false)}
      />

      {exitToastVisible && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-neutral-900/95 text-white text-xs font-bold px-4 py-2 rounded-full shadow-2xl border border-white/20 backdrop-blur-md animate-fadeIn pointer-events-none">
          Press back again to exit
        </div>
      )}
    </div>
    </ThemeProvider>
  );
}
