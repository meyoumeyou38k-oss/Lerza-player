import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Lock, KeyRound, Grid3X3, X, Check, AlertCircle, RefreshCw } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { VaultLockType } from '../types';

interface LockDialogProps {
  isOpen: boolean;
  mode: 'setup' | 'unlock';
  configuredLockType?: VaultLockType;
  configuredSecret?: string;
  title?: string;
  description?: string;
  onSuccess: (secret: string, lockType: VaultLockType) => void;
  onClose: () => void;
}

export const LockDialog: React.FC<LockDialogProps> = ({
  isOpen,
  mode,
  configuredLockType = 'pin',
  configuredSecret = '',
  title,
  description,
  onSuccess,
  onClose
}) => {
  const { config: themeConfig } = useTheme();

  // Setup state
  const [selectedType, setSelectedType] = useState<VaultLockType>(
    mode === 'setup' ? 'pin' : configuredLockType
  );
  const [setupStep, setSetupStep] = useState<'create' | 'confirm'>('create');
  const [tempSecret, setTempSecret] = useState<string>('');

  // PIN state
  const [pinDigits, setPinDigits] = useState<string>('');

  // Pattern state (sequence of dot indices 0..8)
  const [patternDots, setPatternDots] = useState<number[]>([]);
  const [isPatternDragging, setIsPatternDragging] = useState(false);
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);

  // Feedback error state
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState(false);

  const patternSvgRef = useRef<SVGSVGElement | null>(null);

  // Reset when dialog opens
  useEffect(() => {
    if (isOpen) {
      setSelectedType(mode === 'setup' ? 'pin' : configuredLockType);
      setSetupStep('create');
      setTempSecret('');
      setPinDigits('');
      setPatternDots([]);
      setErrorMessage(null);
      setIsShaking(false);
      setIsPatternDragging(false);
      setMousePos(null);
    }
  }, [isOpen, mode, configuredLockType]);

  const triggerError = (msg: string) => {
    setErrorMessage(msg);
    setIsShaking(true);
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try { navigator.vibrate([60, 50, 60]); } catch (_) {}
    }
    setTimeout(() => {
      setIsShaking(false);
      setPinDigits('');
      setPatternDots([]);
    }, 600);
  };

  // --- PIN Handlers ---
  const handleDigitPress = (digit: string) => {
    if (pinDigits.length >= 4) return;
    const next = pinDigits + digit;
    setPinDigits(next);
    setErrorMessage(null);

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try { navigator.vibrate(20); } catch (_) {}
    }

    if (next.length === 4) {
      handlePinComplete(next);
    }
  };

  const handleBackspace = () => {
    setPinDigits(prev => prev.slice(0, -1));
    setErrorMessage(null);
  };

  const handlePinComplete = (code: string) => {
    if (mode === 'setup') {
      if (setupStep === 'create') {
        setTempSecret(code);
        setPinDigits('');
        setSetupStep('confirm');
      } else {
        if (code === tempSecret) {
          onSuccess(code, 'pin');
        } else {
          triggerError('PIN does not match. Try again.');
          setSetupStep('create');
          setTempSecret('');
        }
      }
    } else {
      if (code === configuredSecret) {
        onSuccess(code, 'pin');
      } else {
        triggerError('Incorrect PIN. Please try again.');
      }
    }
  };

  // --- Pattern Handlers ---
  // Coordinates for 3x3 dots inside a 300x300 SVG viewbox
  const dotCoords = [
    { x: 50, y: 50 },  { x: 150, y: 50 },  { x: 250, y: 50 },
    { x: 50, y: 150 }, { x: 150, y: 150 }, { x: 250, y: 150 },
    { x: 50, y: 250 }, { x: 150, y: 250 }, { x: 250, y: 250 }
  ];

  const getSvgPoint = useCallback((clientX: number, clientY: number) => {
    if (!patternSvgRef.current) return null;
    const rect = patternSvgRef.current.getBoundingClientRect();
    const scaleX = 300 / rect.width;
    const scaleY = 300 / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  }, []);

  const checkDotIntersection = (pt: { x: number; y: number }) => {
    const HIT_RADIUS = 36;
    for (let i = 0; i < dotCoords.length; i++) {
      const dot = dotCoords[i];
      const dist = Math.hypot(dot.x - pt.x, dot.y - pt.y);
      if (dist < HIT_RADIUS) {
        return i;
      }
    }
    return null;
  };

  const startPattern = (clientX: number, clientY: number) => {
    const pt = getSvgPoint(clientX, clientY);
    if (!pt) return;
    setIsPatternDragging(true);
    setMousePos(pt);
    setErrorMessage(null);

    const hit = checkDotIntersection(pt);
    if (hit !== null) {
      setPatternDots([hit]);
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate(25); } catch (_) {}
      }
    } else {
      setPatternDots([]);
    }
  };

  const movePattern = (clientX: number, clientY: number) => {
    if (!isPatternDragging) return;
    const pt = getSvgPoint(clientX, clientY);
    if (!pt) return;
    setMousePos(pt);

    const hit = checkDotIntersection(pt);
    if (hit !== null && !patternDots.includes(hit)) {
      setPatternDots(prev => [...prev, hit]);
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate(20); } catch (_) {}
      }
    }
  };

  const endPattern = () => {
    if (!isPatternDragging) return;
    setIsPatternDragging(false);
    setMousePos(null);

    if (patternDots.length === 0) return;

    if (patternDots.length < 4) {
      triggerError('Connect at least 4 dots.');
      return;
    }

    const patternString = patternDots.join('-');

    if (mode === 'setup') {
      if (setupStep === 'create') {
        setTempSecret(patternString);
        setPatternDots([]);
        setSetupStep('confirm');
      } else {
        if (patternString === tempSecret) {
          onSuccess(patternString, 'pattern');
        } else {
          triggerError('Pattern does not match. Try again.');
          setSetupStep('create');
          setTempSecret('');
        }
      }
    } else {
      if (patternString === configuredSecret) {
        onSuccess(patternString, 'pattern');
      } else {
        triggerError('Incorrect pattern. Try again.');
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className={`w-full max-w-sm rounded-3xl ${themeConfig.modalBg} border ${themeConfig.modalBorder} shadow-2xl p-6 relative overflow-hidden transition-transform ${
          isShaking ? 'animate-shake' : ''
        }`}
      >
        {/* Header Close */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full hover:bg-neutral-500/10 text-neutral-400 hover:text-white transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Icon & Title */}
        <div className="text-center mb-5">
          <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-gradient-to-tr from-cyan-500 to-teal-400 p-0.5 flex items-center justify-center shadow-lg shadow-cyan-500/25">
            <div className="w-full h-full rounded-[14px] bg-neutral-950 flex items-center justify-center text-cyan-400">
              <Lock className="w-7 h-7" />
            </div>
          </div>

          <h3 className={`text-lg font-black tracking-tight ${themeConfig.textPrimary}`}>
            {title || (mode === 'setup' ? 'Set Private Vault Lock' : 'Unlock Private Vault')}
          </h3>
          <p className={`text-xs mt-1 px-4 ${themeConfig.textSecondary}`}>
            {description || (
              mode === 'setup'
                ? setupStep === 'create'
                  ? selectedType === 'pin' ? 'Create a 4-digit PIN code' : 'Draw your lock pattern'
                  : 'Confirm your PIN or pattern'
                : selectedType === 'pin' ? 'Enter your 4-digit PIN' : 'Draw your unlock pattern'
            )}
          </p>
        </div>

        {/* Type Toggle for Setup Mode */}
        {mode === 'setup' && setupStep === 'create' && (
          <div className="flex rounded-xl bg-neutral-900/60 p-1 mb-5 border border-white/5">
            <button
              onClick={() => {
                setSelectedType('pin');
                setPinDigits('');
                setPatternDots([]);
                setErrorMessage(null);
              }}
              className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                selectedType === 'pin'
                  ? 'bg-cyan-500 text-neutral-950 shadow-md'
                  : `${themeConfig.textSecondary} hover:text-white`
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>PIN Lock</span>
            </button>
            <button
              onClick={() => {
                setSelectedType('pattern');
                setPinDigits('');
                setPatternDots([]);
                setErrorMessage(null);
              }}
              className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                selectedType === 'pattern'
                  ? 'bg-cyan-500 text-neutral-950 shadow-md'
                  : `${themeConfig.textSecondary} hover:text-white`
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5" />
              <span>Pattern Lock</span>
            </button>
          </div>
        )}

        {/* Error message */}
        {errorMessage && (
          <div className="mb-4 py-2 px-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-medium flex items-center justify-center gap-1.5 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* --- PIN VIEW --- */}
        {selectedType === 'pin' && (
          <div className="space-y-6">
            {/* PIN Dots display */}
            <div className="flex items-center justify-center gap-4 py-2">
              {[0, 1, 2, 3].map(idx => {
                const filled = pinDigits.length > idx;
                return (
                  <div
                    key={idx}
                    className={`w-4 h-4 rounded-full transition-all duration-200 ${
                      filled
                        ? 'bg-cyan-400 scale-125 shadow-lg shadow-cyan-400/50'
                        : 'border-2 border-neutral-600 bg-transparent'
                    }`}
                  />
                );
              })}
            </div>

            {/* Numeric Keypad */}
            <div className="grid grid-cols-3 gap-3 max-w-[260px] mx-auto">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(d => (
                <button
                  key={d}
                  onClick={() => handleDigitPress(d)}
                  className="w-16 h-16 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 active:scale-95 border border-white/5 text-xl font-bold text-white shadow-sm flex items-center justify-center transition"
                >
                  {d}
                </button>
              ))}
              <div className="w-16 h-16" />
              <button
                onClick={() => handleDigitPress('0')}
                className="w-16 h-16 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 active:scale-95 border border-white/5 text-xl font-bold text-white shadow-sm flex items-center justify-center transition"
              >
                0
              </button>
              <button
                onClick={handleBackspace}
                className="w-16 h-16 rounded-2xl bg-neutral-900/40 hover:bg-neutral-800 active:scale-95 border border-white/5 text-sm font-semibold text-neutral-400 hover:text-white flex items-center justify-center transition"
                aria-label="Backspace"
              >
                Del
              </button>
            </div>
          </div>
        )}

        {/* --- PATTERN VIEW --- */}
        {selectedType === 'pattern' && (
          <div className="flex flex-col items-center">
            <div className="relative select-none touch-none w-[260px] h-[260px]">
              <svg
                ref={patternSvgRef}
                viewBox="0 0 300 300"
                className="w-full h-full cursor-crosshair select-none"
                onMouseDown={e => startPattern(e.clientX, e.clientY)}
                onMouseMove={e => movePattern(e.clientX, e.clientY)}
                onMouseUp={endPattern}
                onTouchStart={e => {
                  const t = e.touches[0];
                  startPattern(t.clientX, t.clientY);
                }}
                onTouchMove={e => {
                  const t = e.touches[0];
                  movePattern(t.clientX, t.clientY);
                }}
                onTouchEnd={endPattern}
              >
                {/* Drawn connected lines */}
                {patternDots.map((dotIdx, i) => {
                  if (i === 0) return null;
                  const prevDot = dotCoords[patternDots[i - 1]];
                  const currDot = dotCoords[dotIdx];
                  return (
                    <line
                      key={`line-${i}`}
                      x1={prevDot.x}
                      y1={prevDot.y}
                      x2={currDot.x}
                      y2={currDot.y}
                      stroke="#06b6d4"
                      strokeWidth="6"
                      strokeLinecap="round"
                    />
                  );
                })}

                {/* Floating active trailing line to mouse/finger */}
                {isPatternDragging && patternDots.length > 0 && mousePos && (
                  <line
                    x1={dotCoords[patternDots[patternDots.length - 1]].x}
                    y1={dotCoords[patternDots[patternDots.length - 1]].y}
                    x2={mousePos.x}
                    y2={mousePos.y}
                    stroke="#06b6d4"
                    strokeWidth="4"
                    strokeDasharray="4,4"
                    strokeLinecap="round"
                  />
                )}

                {/* 3x3 Dots */}
                {dotCoords.map((coord, idx) => {
                  const isSelected = patternDots.includes(idx);
                  return (
                    <g key={idx}>
                      {/* Outer touch highlight circle */}
                      <circle
                        cx={coord.x}
                        cy={coord.y}
                        r="28"
                        fill={isSelected ? 'rgba(6, 182, 212, 0.18)' : 'transparent'}
                        className="transition-colors"
                      />
                      {/* Main visible dot */}
                      <circle
                        cx={coord.x}
                        cy={coord.y}
                        r={isSelected ? '10' : '8'}
                        fill={isSelected ? '#22d3ee' : '#737373'}
                        stroke={isSelected ? '#0891b2' : 'transparent'}
                        strokeWidth="2"
                        className="transition-all duration-150"
                      />
                    </g>
                  );
                })}
              </svg>
            </div>

            <p className="text-[11px] text-neutral-400 mt-2">
              {patternDots.length === 0
                ? 'Touch and drag to connect dots'
                : `${patternDots.length} dots connected`}
            </p>
          </div>
        )}

        {/* Footer info */}
        {mode === 'setup' && setupStep === 'confirm' && (
          <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
            <span className="text-[11px] text-amber-400 font-medium">
              Please re-enter to confirm
            </span>
            <button
              onClick={() => {
                setSetupStep('create');
                setTempSecret('');
                setPinDigits('');
                setPatternDots([]);
                setErrorMessage(null);
              }}
              className="text-xs text-cyan-400 font-bold hover:underline flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
