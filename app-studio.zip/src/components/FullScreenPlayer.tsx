import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  MediaTrack, 
  RepeatMode, 
  PlayerDisplayMode 
} from '../types';
import { generateVinylAlbumArt } from '../utils/artworkExtractor';
import { 
  ChevronDown, 
  Heart, 
  Sliders, 
  Shuffle, 
  SkipBack, 
  Play, 
  Pause, 
  SkipForward, 
  Repeat, 
  Repeat1, 
  ListMusic, 
  FileText, 
  Video, 
  Music, 
  RotateCcw, 
  RotateCw, 
  Gauge, 
  Moon, 
  Volume2, 
  Maximize2, 
  Minimize2, 
  ExternalLink, 
  VolumeX, 
  Volume1, 
  Sparkles,
  MoreVertical,
  SlidersHorizontal,
  Timer,
  Info,
  ListPlus,
  Lock,
  Unlock,
  Smartphone,
  RefreshCw,
  X
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { getPlayableMediaUrl, getMediaCandidateUrls } from '../utils/mediaUrl';

interface FullScreenPlayerProps {
  currentTrack: MediaTrack;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  repeatMode: RepeatMode;
  isShuffle: boolean;
  displayMode: PlayerDisplayMode;
  playbackSpeed: number;
  volumeMultiplier: number;
  isOnline: boolean;
  isAdsRemoved: boolean;
  onTogglePlay: () => void;
  onSeek: (seconds: number) => void;
  onNext: () => void;
  onPrev: () => void;
  onToggleShuffle: () => void;
  onCycleRepeat: () => void;
  onToggleFavorite: (id: string) => void;
  onClose: () => void;
  onOpenLyrics: () => void;
  onOpenEqualizer: () => void;
  onOpenQueue: () => void;
  onToggleDisplayMode: () => void;
  onChangeSpeed: (speed: number) => void;
  onChangeVolumeMultiplier: (mult: number) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  audioRef?: React.RefObject<HTMLAudioElement | null>;
  onPlayStateChange?: (playing: boolean) => void;
  sleepTimerMinutes?: number | null;
  onSetSleepTimer?: (minutes: number | null) => void;
  onAddToPlaylistClick?: () => void;
  onTimeUpdate?: (currentTime: number, duration?: number) => void;
}

export const FullScreenPlayer: React.FC<FullScreenPlayerProps> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  repeatMode,
  isShuffle,
  displayMode,
  playbackSpeed,
  volumeMultiplier,
  isOnline,
  isAdsRemoved,
  onTogglePlay,
  onSeek,
  onNext,
  onPrev,
  onToggleShuffle,
  onCycleRepeat,
  onToggleFavorite,
  onClose,
  onOpenLyrics,
  onOpenEqualizer,
  onOpenQueue,
  onToggleDisplayMode,
  onChangeSpeed,
  onChangeVolumeMultiplier,
  videoRef,
  audioRef,
  onPlayStateChange,
  sleepTimerMinutes,
  onSetSleepTimer,
  onAddToPlaylistClick,
  onTimeUpdate
}) => {
  const { config: themeConfig } = useTheme();
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekValue, setSeekValue] = useState(currentTime);
  const seekValueRef = useRef<number>(currentTime);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showVolumeMenu, setShowVolumeMenu] = useState(false);
  const [showThreeDotMenu, setShowThreeDotMenu] = useState(false);
  const [isVideoFullscreen, setIsVideoFullscreen] = useState(false);
  const [isVideoLocked, setIsVideoLocked] = useState(false);
  const [videoOrientation, setVideoOrientation] = useState<'landscape' | 'portrait'>('landscape');
  const [videoFitMode, setVideoFitMode] = useState<'contain' | 'cover'>('contain');
  const [showVideoControls, setShowVideoControls] = useState(false); // Play without controls initially
  const [showLockToast, setShowLockToast] = useState(false);
  const [lockToastMessage, setLockToastMessage] = useState('Screen Locked');
  const [showVideoSpeedMenu, setShowVideoSpeedMenu] = useState(false);
  const [videoAspectRatio, setVideoAspectRatio] = useState<number | null>(null);
  const [aspectRatioLabel, setAspectRatioLabel] = useState<string>('Auto');
  const [isPortraitVideo, setIsPortraitVideo] = useState<boolean>(false);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Global unmount cleanup: ensure screen orientation and fullscreen are restored
  useEffect(() => {
    return () => {
      try {
        if (document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        }
      } catch (_) {}
      if ((window as any).AndroidBridge?.toggleFullscreen) {
        try { (window as any).AndroidBridge.toggleFullscreen(false); } catch (_) {}
      }
      if ((window as any).AndroidBridge?.setScreenOrientation) {
        try { (window as any).AndroidBridge.setScreenOrientation('portrait'); } catch (_) {}
      }
      try {
        if (window.screen && (window.screen as any).orientation?.unlock) {
          (window.screen as any).orientation.unlock();
        }
      } catch (_) {}
    };
  }, []);

  const resetControlsTimeout = () => {
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    if (isPlaying && !isVideoLocked) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowVideoControls(false);
      }, 3500);
    }
  };

  useEffect(() => {
    if (isVideoFullscreen && isPlaying && !isVideoLocked && showVideoControls) {
      resetControlsTimeout();
    }
    return () => {
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    };
  }, [isVideoFullscreen, isPlaying, isVideoLocked, showVideoControls]);

  const applyVideoOrientationAndAspect = (w: number, h: number) => {
    if (w <= 0 || h <= 0) return;
    const ratio = w / h;
    setVideoAspectRatio(ratio);

    // 16:9 (widescreen/landscape) vs 9:16 or 3:4 (portrait/vertical)
    // If ratio < 1.2: 9:16 (~0.56) or 3:4 (~0.75) -> keep in Portrait mode!
    // If ratio >= 1.2: 16:9 (~1.78) -> rotate to Landscape mode!
    const isPortrait = ratio < 1.2;
    setIsPortraitVideo(isPortrait);

    let label = `${w}×${h}`;
    if (Math.abs(ratio - 16 / 9) < 0.18) {
      label = '16:9';
    } else if (Math.abs(ratio - 9 / 16) < 0.18) {
      label = '9:16';
    } else if (Math.abs(ratio - 3 / 4) < 0.18) {
      label = '3:4';
    } else if (Math.abs(ratio - 4 / 3) < 0.18) {
      label = '4:3';
    } else if (ratio >= 1.2) {
      label = '16:9';
    } else {
      label = 'Portrait';
    }
    setAspectRatioLabel(label);

    // Rule:
    // 16:9 (widescreen / landscape) -> Auto rotate to Landscape/Horizontal
    // 9:16 or 3:4 portrait -> Keep in Portrait! Do NOT rotate!
    const targetOrientation: 'landscape' | 'portrait' = isPortrait ? 'portrait' : 'landscape';
    setVideoOrientation(targetOrientation);

    if ((window as any).AndroidBridge?.setScreenOrientation) {
      try {
        (window as any).AndroidBridge.setScreenOrientation(targetOrientation);
      } catch (err) {}
    }
    try {
      if (window.screen && (window.screen as any).orientation?.lock) {
        (window.screen as any).orientation.lock(targetOrientation).catch(() => {});
      }
    } catch (_) {}
  };

  // --- Advanced Gesture Controls ---
  const touchStartPos = useRef<{ x: number; y: number; time: number } | null>(null);
  const lastTapRef = useRef<{ time: number; x: number } | null>(null);
  const [gestureFeedback, setGestureFeedback] = useState<{ text: string; icon: 'rewind' | 'forward' | 'play' | 'pause' } | null>(null);
  const feedbackTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [dragOffsetY, setDragOffsetY] = useState(0);
  const timelineTrackRef = useRef<HTMLDivElement | null>(null);

  const showGestureFeedback = (text: string, icon: 'rewind' | 'forward' | 'play' | 'pause') => {
    if (feedbackTimeoutRef.current) clearTimeout(feedbackTimeoutRef.current);
    setGestureFeedback({ text, icon });
    feedbackTimeoutRef.current = setTimeout(() => {
      setGestureFeedback(null);
    }, 850);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    const touch = e.touches[0];
    const windowHeight = window.innerHeight;

    if (
      isSeeking || 
      touch.clientY > windowHeight * 0.60 || 
      target.closest('.seekbar-container') || 
      target.closest('.control-deck-area') ||
      target.tagName === 'INPUT' ||
      target.tagName === 'BUTTON'
    ) {
      touchStartPos.current = null;
      return;
    }

    touchStartPos.current = { x: touch.clientX, y: touch.clientY, time: Date.now() };
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    if (!touchStartPos.current || isSeeking || target.closest('.seekbar-container') || target.tagName === 'INPUT') {
      return;
    }

    const currentX = e.touches[0].clientX;
    const currentY = e.touches[0].clientY;
    const deltaX = currentX - touchStartPos.current.x;
    const deltaY = currentY - touchStartPos.current.y;

    // Strictly vertical pull-down to collapse full-screen player:
    // COMPLETELY IGNORES and DISABLES all horizontal gestures (left-to-right & right-to-left)
    if (deltaY > 0 && Math.abs(deltaY) > Math.abs(deltaX) * 1.5) {
      setDragOffsetY(deltaY);
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    if (isSeeking || target.closest('.seekbar-container') || target.tagName === 'INPUT') {
      touchStartPos.current = null;
      return;
    }

    if (dragOffsetY > 110) {
      onClose();
    }

    // Horizontal gestures remain completely off
    setDragOffsetY(0);
    touchStartPos.current = null;
  };

  const isVideoMode = displayMode === 'video' || currentTrack.isVideoOnly;

  // Real-time synchronization with active HTML media elements to ensure Play/Pause UI state is 100% accurate
  const [actualMediaPlaying, setActualMediaPlaying] = useState<boolean>(isPlaying);

  useEffect(() => {
    setActualMediaPlaying(isPlaying);
  }, [isPlaying]);

  useEffect(() => {
    const el = isVideoMode ? videoRef?.current : audioRef?.current;
    if (!el) return;

    const onPlay = () => {
      setActualMediaPlaying(true);
      if (onPlayStateChange) onPlayStateChange(true);
    };
    const onPause = () => {
      setActualMediaPlaying(false);
      if (onPlayStateChange) onPlayStateChange(false);
    };
    const onPlaying = () => {
      setActualMediaPlaying(true);
      if (onPlayStateChange) onPlayStateChange(true);
    };

    el.addEventListener('play', onPlay);
    el.addEventListener('playing', onPlaying);
    el.addEventListener('pause', onPause);

    if (!el.paused && !el.ended) {
      setActualMediaPlaying(true);
    }

    return () => {
      el.removeEventListener('play', onPlay);
      el.removeEventListener('playing', onPlaying);
      el.removeEventListener('pause', onPause);
    };
  }, [isVideoMode, audioRef, videoRef, currentTrack.id]);

  const isMediaActuallyPlaying = isPlaying || actualMediaPlaying || (
    isVideoMode
      ? Boolean(videoRef?.current && !videoRef.current.paused && !videoRef.current.ended)
      : Boolean(audioRef?.current && !audioRef.current.paused && !audioRef.current.ended)
  );

  const handleStageTap = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    e.stopPropagation();
    onTogglePlay();
    showGestureFeedback(!isMediaActuallyPlaying ? 'Playing' : 'Paused', !isMediaActuallyPlaying ? 'play' : 'pause');
  };

  useEffect(() => {
    if (!isSeeking) {
      setSeekValue(currentTime);
      seekValueRef.current = currentTime;
    }
  }, [currentTime, isSeeking]);

  // Ensure effectiveDuration never finishes prematurely or clips active currentTime
  const effectiveDuration = Math.max(
    (Number.isFinite(duration) && duration > 0) ? duration : 0,
    (currentTrack && Number.isFinite(currentTrack.duration) && currentTrack.duration > 0) ? currentTrack.duration : 0,
    currentTime > 0 ? currentTime : 0,
    1
  );

  const formatTime = (sec: number) => {
    if (isNaN(sec) || sec < 0) return '0:00';
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleSeekChange = (val: number) => {
    if (!Number.isFinite(val)) return;
    const clamped = Math.max(0, Math.min(effectiveDuration, val));
    setSeekValue(clamped);
    seekValueRef.current = clamped;
  };

  const handleSeekCommit = (val?: number) => {
    setIsSeeking(false);
    const target = val !== undefined && Number.isFinite(val) ? val : seekValueRef.current;
    const clamped = Math.max(0, Math.min(effectiveDuration, target));
    setSeekValue(clamped);
    seekValueRef.current = clamped;
    onSeek(clamped);
  };

  const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
  const volumeOptions = [
    { label: '100%', val: 1.0, badge: 'Normal' },
    { label: '150%', val: 1.5, badge: 'Boost' },
    { label: '200%', val: 2.0, badge: 'Super' },
    { label: '300%', val: 3.0, badge: 'Max' }
  ];

  const triggerLockToast = (msg: string) => {
    setLockToastMessage(msg);
    setShowLockToast(true);
    setTimeout(() => setShowLockToast(false), 2200);
  };

  const handleToggleRotate = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const next = videoOrientation === 'landscape' ? 'portrait' : 'landscape';
    setVideoOrientation(next);
    if ((window as any).AndroidBridge?.setScreenOrientation) {
      try {
        (window as any).AndroidBridge.setScreenOrientation(next);
      } catch (err) {}
    }
    triggerLockToast(next === 'landscape' ? 'Landscape (Horizontal)' : 'Portrait (Vertical)');
  };

  const handleExitVideoFullscreen = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    toggleVideoFullscreen(true);
    if (currentTrack.isVideoOnly || displayMode === 'video') {
      onClose();
    }
  };

  const toggleVideoFullscreen = (forceClose?: boolean) => {
    const shouldExit = forceClose !== undefined ? forceClose : isVideoFullscreen;
    const videoContainer = document.getElementById('video-stage-container');

    if (shouldExit) {
      setIsVideoFullscreen(false);
      setIsVideoLocked(false);
      setShowVideoControls(true);
      setShowVideoSpeedMenu(false);
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
      try {
        if (document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        }
      } catch (err) {}
      if ((window as any).AndroidBridge?.toggleFullscreen) {
        try { (window as any).AndroidBridge.toggleFullscreen(false); } catch (err) {}
      }
      if ((window as any).AndroidBridge?.setScreenOrientation) {
        try { (window as any).AndroidBridge.setScreenOrientation('portrait'); } catch (err) {}
      }
    } else {
      setIsVideoFullscreen(true);
      setIsVideoLocked(false);
      setShowVideoControls(true);
      resetControlsTimeout();

      // Check current video aspect ratio and auto-orient
      if (videoRef.current && videoRef.current.videoWidth && videoRef.current.videoHeight) {
        applyVideoOrientationAndAspect(videoRef.current.videoWidth, videoRef.current.videoHeight);
      }

      try {
        if (videoContainer && videoContainer.requestFullscreen) {
          videoContainer.requestFullscreen().catch(() => {});
        }
      } catch (err) {}
      if ((window as any).AndroidBridge?.toggleFullscreen) {
        try { (window as any).AndroidBridge.toggleFullscreen(true); } catch (err) {}
      }
    }
  };

  useEffect(() => {
    if (displayMode === 'video' || currentTrack.isVideoOnly) {
      setIsVideoFullscreen(true);
      resetControlsTimeout();
      if ((window as any).AndroidBridge?.toggleFullscreen) {
        try { (window as any).AndroidBridge.toggleFullscreen(true); } catch (err) {}
      }
      if (videoRef.current && videoRef.current.videoWidth && videoRef.current.videoHeight) {
        applyVideoOrientationAndAspect(videoRef.current.videoWidth, videoRef.current.videoHeight);
      }
      // Ensure video element plays when track loads or changes
      if (videoRef.current) {
        if (isPlaying) {
          videoRef.current.play().catch((e) => {
            console.warn('Video auto-play handled:', e);
          });
        }
      }
    }
  }, [displayMode, currentTrack.id, isPlaying]);

  // Sync play/pause state dynamically
  useEffect(() => {
    if ((displayMode === 'video' || currentTrack.isVideoOnly) && videoRef.current) {
      if (isPlaying && videoRef.current.paused) {
        videoRef.current.play().catch(() => {});
      } else if (!isPlaying && !videoRef.current.paused) {
        videoRef.current.pause();
      }
    }
  }, [isPlaying, displayMode, currentTrack.isVideoOnly]);

  const [videoSrcIndex, setVideoSrcIndex] = useState(0);
  const videoCandidates = useMemo(() => getMediaCandidateUrls(currentTrack, true), [currentTrack]);
  const effectiveVideoUrl = videoCandidates[videoSrcIndex] || getPlayableMediaUrl(currentTrack, true);

  useEffect(() => {
    setVideoSrcIndex(0);
    setShowVideoControls(false); // Initially play without controls per user request
  }, [currentTrack.id]);

  const lastVideoTapTime = useRef<number>(0);
  const lastVideoTapX = useRef<number>(0);
  const singleTapTimer = useRef<NodeJS.Timeout | null>(null);

  const handleVideoStageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isVideoLocked) {
      triggerLockToast('Screen Locked • Tap Lock icon to Unlock');
      return;
    }

    const now = Date.now();
    const clickX = e.clientX;
    const windowWidth = window.innerWidth;
    const isDoubleTap = now - lastVideoTapTime.current < 320 && Math.abs(clickX - lastVideoTapX.current) < 90;

    if (isDoubleTap) {
      if (singleTapTimer.current) {
        clearTimeout(singleTapTimer.current);
        singleTapTimer.current = null;
      }
      lastVideoTapTime.current = 0;

      if (clickX < windowWidth * 0.4) {
        // Double tap left: rewind 10s
        onSeek(Math.max(0, currentTime - 10));
        showGestureFeedback('-10s', 'rewind');
      } else if (clickX > windowWidth * 0.6) {
        // Double tap right: forward 10s
        onSeek(Math.min(effectiveDuration, currentTime + 10));
        showGestureFeedback('+10s', 'forward');
      } else {
        // Double tap center: toggle play/pause
        onTogglePlay();
        showGestureFeedback(!isMediaActuallyPlaying ? 'Playing' : 'Paused', !isMediaActuallyPlaying ? 'play' : 'pause');
      }
      return;
    }

    lastVideoTapTime.current = now;
    lastVideoTapX.current = clickX;

    if (singleTapTimer.current) clearTimeout(singleTapTimer.current);
    singleTapTimer.current = setTimeout(() => {
      setShowVideoControls(prev => {
        const next = !prev;
        if (next) resetControlsTimeout();
        else if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
        return next;
      });
      singleTapTimer.current = null;
    }, 240);
  };

  if (isVideoMode) {
    return (
      <div 
        id="video-stage-container"
        className="fixed inset-0 z-[100] w-screen h-screen bg-black overflow-hidden select-none flex items-center justify-center cursor-pointer"
        onClick={handleVideoStageClick}
      >
        <video
          key={currentTrack.id}
          ref={videoRef as any}
          src={effectiveVideoUrl}
          autoPlay={isPlaying}
          playsInline
          preload="auto"
          loop={repeatMode === 'one'}
          onEnded={onNext}
          onPlay={() => {
            onPlayStateChange?.(true);
          }}
          onPlaying={() => {
            onPlayStateChange?.(true);
          }}
          onPause={() => {
            if (videoRef.current?.paused) {
              onPlayStateChange?.(false);
            }
          }}
          onCanPlay={() => {
            if (isPlaying && videoRef.current && videoRef.current.paused) {
              videoRef.current.play().catch(() => {});
            }
          }}
          onError={(e) => {
            console.warn('Video playback error on element:', e);
            if (videoSrcIndex + 1 < videoCandidates.length) {
              console.info('Switching to fallback video candidate:', videoCandidates[videoSrcIndex + 1]);
              setVideoSrcIndex(prev => prev + 1);
            }
          }}
          onTimeUpdate={(e) => {
            const vid = e.currentTarget;
            if (vid && onTimeUpdate) {
              const d = (Number.isFinite(vid.duration) && vid.duration > 0) ? vid.duration : undefined;
              onTimeUpdate(vid.currentTime, d);
            }
          }}
          onDurationChange={(e) => {
            const vid = e.currentTarget;
            if (vid && onTimeUpdate && Number.isFinite(vid.duration) && vid.duration > 0) {
              onTimeUpdate(vid.currentTime, vid.duration);
            }
          }}
          onLoadedMetadata={(e) => {
            const vid = e.currentTarget;
            if (vid.videoWidth && vid.videoHeight) {
              applyVideoOrientationAndAspect(vid.videoWidth, vid.videoHeight);
            }
            if (onTimeUpdate && Number.isFinite(vid.duration) && vid.duration > 0) {
              onTimeUpdate(vid.currentTime, vid.duration);
            }
            if (isPlaying && vid.paused) {
              vid.play().catch(() => {});
            }
          }}
          className={`w-full h-full ${videoFitMode === 'cover' ? 'object-cover' : 'object-contain'} pointer-events-none`}
        />

        {/* Lock Toast / User Feedback */}
        {showLockToast && (
          <div className="absolute top-14 left-1/2 -translate-x-1/2 bg-black/85 backdrop-blur-md text-white px-5 py-2.5 rounded-full border border-white/20 shadow-2xl z-[130] text-xs sm:text-sm font-semibold pointer-events-none flex items-center gap-2 animate-fadeIn">
            {isVideoLocked ? <Lock className="w-4 h-4 text-cyan-400" /> : <Unlock className="w-4 h-4 text-emerald-400" />}
            <span>{lockToastMessage}</span>
          </div>
        )}

        {/* Gesture Feedback (e.g. -10s, +10s, play, pause) */}
        {gestureFeedback && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/80 backdrop-blur-xl text-white px-6 py-3.5 rounded-2xl border border-white/20 shadow-2xl z-[140] pointer-events-none flex items-center gap-3 animate-scaleUp">
            {gestureFeedback.icon === 'rewind' && <RotateCcw className="w-6 h-6 text-cyan-400" />}
            {gestureFeedback.icon === 'forward' && <RotateCw className="w-6 h-6 text-cyan-400" />}
            {gestureFeedback.icon === 'play' && <Play className="w-6 h-6 text-emerald-400 fill-current" />}
            {gestureFeedback.icon === 'pause' && <Pause className="w-6 h-6 text-amber-400 fill-current" />}
            <span className="text-sm font-bold tracking-wide">{gestureFeedback.text}</span>
          </div>
        )}

        {/* Locked Mode: Minimal floating unlock button */}
        {isVideoLocked ? (
          <div className="absolute top-6 left-6 z-[120]">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsVideoLocked(false);
                setShowVideoControls(true);
                resetControlsTimeout();
                triggerLockToast('Screen Unlocked');
              }}
              className="px-4 py-2.5 rounded-full bg-cyan-600/90 hover:bg-cyan-500 text-white backdrop-blur-md border border-white/30 shadow-2xl flex items-center gap-2 active:scale-95 transition"
            >
              <Lock className="w-4 h-4 text-white" />
              <span className="text-xs font-bold tracking-wide">Locked • Tap to Unlock</span>
            </button>
          </div>
        ) : (
          /* Transparent Overlay Controls with Single-Tap Toggle */
          <div 
            className={`absolute inset-0 z-[110] flex flex-col justify-between p-4 sm:p-6 bg-gradient-to-b from-black/80 via-black/20 to-black/90 transition-opacity duration-300 ${
              showVideoControls ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
            }`}
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setShowVideoControls(false);
                if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
              }
            }}
          >
            {/* Top Bar */}
            <div 
              className="flex items-center justify-between gap-3"
              onClick={(e) => { e.stopPropagation(); resetControlsTimeout(); }}
            >
              <button
                onClick={handleExitVideoFullscreen}
                className="p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white backdrop-blur-md border border-white/20 active:scale-95 transition"
                title="Back to Videos"
              >
                <ChevronDown className="w-5 h-5 text-white" />
              </button>

              <div className="flex-1 min-w-0 px-2 text-left">
                <h3 className="text-sm sm:text-base font-bold text-white truncate drop-shadow-md">
                  {currentTrack.title}
                </h3>
                <p className="text-xs text-neutral-300 truncate">
                  {currentTrack.artist || 'Local Video'} {currentTrack.folder ? `• ${currentTrack.folder.split('/').pop()}` : ''}
                </p>
              </div>

              <div className="flex items-center gap-2">
                {currentTrack.hasMV && (
                  <button
                    onClick={() => onToggleDisplayMode()}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/60 hover:bg-black text-xs font-bold text-cyan-400 border border-cyan-400/40 backdrop-blur-md active:scale-95 transition"
                    title="Switch to Audio Mode"
                  >
                    <Music className="w-3.5 h-3.5" />
                    <span>Audio</span>
                  </button>
                )}

                {/* Aspect Ratio & Fit Mode Toggle */}
                <button
                  onClick={() => {
                    const nextMode = videoFitMode === 'contain' ? 'cover' : 'contain';
                    setVideoFitMode(nextMode);
                    triggerLockToast(nextMode === 'cover' ? 'Zoom to Fill (Cover)' : `Best Fit (${aspectRatioLabel})`);
                  }}
                  className="px-2.5 py-1.5 rounded-xl bg-black/60 hover:bg-black text-xs font-mono font-bold text-cyan-300 border border-white/20 backdrop-blur-md flex items-center gap-1.5 active:scale-95 transition"
                  title="Toggle Fit Mode"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>{aspectRatioLabel} ({videoFitMode === 'cover' ? 'Fill' : 'Fit'})</span>
                </button>

                {/* Rotate Orientation Toggle */}
                <button
                  onClick={handleToggleRotate}
                  className="p-2.5 rounded-full bg-black/60 hover:bg-black text-white border border-white/20 backdrop-blur-md active:scale-95 transition"
                  title="Rotate Orientation"
                >
                  <RefreshCw className="w-4 h-4 text-cyan-400" />
                </button>

                {/* Lock Controls Button */}
                <button
                  onClick={() => {
                    setIsVideoLocked(true);
                    setShowVideoControls(false);
                    triggerLockToast('Screen Locked');
                  }}
                  className="p-2.5 rounded-full bg-black/60 hover:bg-black text-white border border-white/20 backdrop-blur-md active:scale-95 transition"
                  title="Lock Controls"
                >
                  <Unlock className="w-4 h-4 text-white" />
                </button>
              </div>
            </div>

            {/* Center Controls: Prev Video, Rewind 10s, Play/Pause, Forward 10s, Next Video */}
            <div 
              className="flex items-center justify-center gap-6 sm:gap-12"
              onClick={(e) => { e.stopPropagation(); resetControlsTimeout(); }}
            >
              <button
                onClick={onPrev}
                className="p-3 sm:p-4 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md text-white transition active:scale-90 border border-white/20"
                title="Previous Video"
              >
                <SkipBack className="w-5 h-5 sm:w-7 sm:h-7 text-neutral-200" />
              </button>

              <button
                onClick={() => {
                  onSeek(Math.max(0, currentTime - 10));
                  triggerLockToast('-10s');
                }}
                className="p-3 sm:p-4 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md text-white transition active:scale-90 border border-white/20"
                title="Rewind 10 Seconds"
              >
                <RotateCcw className="w-5 h-5 sm:w-7 sm:h-7 text-cyan-400" />
              </button>

              <button
                onClick={onTogglePlay}
                className="p-4 sm:p-5 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-2xl transition active:scale-90 border border-white/30"
                title={isMediaActuallyPlaying ? 'Pause' : 'Play'}
              >
                {isMediaActuallyPlaying ? (
                  <Pause className="w-8 h-8 sm:w-10 sm:h-10 fill-current" />
                ) : (
                  <Play className="w-8 h-8 sm:w-10 sm:h-10 fill-current ml-1" />
                )}
              </button>

              <button
                onClick={() => {
                  onSeek(Math.min(duration, currentTime + 10));
                  triggerLockToast('+10s');
                }}
                className="p-3 sm:p-4 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md text-white transition active:scale-90 border border-white/20"
                title="Forward 10 Seconds"
              >
                <RotateCw className="w-5 h-5 sm:w-7 sm:h-7 text-cyan-400" />
              </button>

              <button
                onClick={onNext}
                className="p-3 sm:p-4 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md text-white transition active:scale-90 border border-white/20"
                title="Next Video"
              >
                <SkipForward className="w-5 h-5 sm:w-7 sm:h-7 text-neutral-200" />
              </button>
            </div>

            {/* Bottom Bar: Timeline, Speed Presets, Repeat & Exit */}
            <div 
              className="space-y-2.5 max-w-4xl w-full mx-auto"
              onClick={(e) => { e.stopPropagation(); resetControlsTimeout(); }}
            >
              {/* Timeline Seekbar */}
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono text-neutral-300 font-bold min-w-[44px] text-right">
                  {formatTime(isSeeking ? seekValue : currentTime)}
                </span>
                
                <div className="flex-1 relative py-2">
                  <input
                    type="range"
                    min={0}
                    max={effectiveDuration}
                    step={0.5}
                    value={Number.isFinite(isSeeking ? seekValue : currentTime) ? (isSeeking ? seekValue : currentTime) : 0}
                    onMouseDown={() => setIsSeeking(true)}
                    onTouchStart={() => setIsSeeking(true)}
                    onInput={(e) => handleSeekChange(parseFloat(e.currentTarget.value))}
                    onChange={(e) => {
                      const val = parseFloat(e.currentTarget.value);
                      handleSeekChange(val);
                      if (!isSeeking) handleSeekCommit(val);
                    }}
                    onMouseUp={(e) => handleSeekCommit(parseFloat(e.currentTarget.value))}
                    onTouchEnd={(e) => handleSeekCommit(parseFloat(e.currentTarget.value))}
                    className="w-full h-2 rounded-lg appearance-none bg-white/25 accent-cyan-400 cursor-pointer"
                  />
                </div>

                <span className="text-xs font-mono text-neutral-300 font-bold min-w-[44px]">
                  {formatTime(effectiveDuration)}
                </span>
              </div>

              <div className="flex items-center justify-between pt-1">
                {/* Speed Presets */}
                <div className="flex items-center gap-1 bg-black/60 backdrop-blur-md rounded-xl p-1 border border-white/10">
                  {[0.5, 0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => {
                        onChangeSpeed(rate);
                        triggerLockToast(`${rate}x Speed`);
                      }}
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition ${
                        playbackSpeed === rate ? 'bg-cyan-500 text-neutral-950 shadow' : 'text-neutral-300 hover:text-white'
                      }`}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  {/* Loop / Repeat Cycle */}
                  <button
                    onClick={onCycleRepeat}
                    className="p-2 rounded-xl bg-black/60 hover:bg-black text-white active:scale-90 transition border border-white/10 flex items-center gap-1 text-xs font-bold"
                    title={`Repeat: ${repeatMode}`}
                  >
                    {repeatMode === 'one' ? (
                      <>
                        <Repeat1 className="w-4 h-4 text-cyan-400" />
                        <span className="text-[10px] text-cyan-400">1</span>
                      </>
                    ) : (
                      <>
                        <Repeat className={`w-4 h-4 ${repeatMode === 'all' ? 'text-cyan-400' : 'text-neutral-400'}`} />
                        <span className={`text-[10px] ${repeatMode === 'all' ? 'text-cyan-400' : 'text-neutral-400'}`}>
                          {repeatMode === 'all' ? 'All' : 'Off'}
                        </span>
                      </>
                    )}
                  </button>

                  {/* Close / Minimize */}
                  <button
                    onClick={handleExitVideoFullscreen}
                    className="p-2 rounded-xl bg-black/60 hover:bg-black text-white active:scale-90 transition border border-white/10 flex items-center gap-1 text-xs font-bold"
                    title="Exit Fullscreen"
                  >
                    <Minimize2 className="w-4 h-4 text-cyan-400" />
                    <span>Close</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div 
      className={`fixed inset-0 z-50 backdrop-blur-3xl ${themeConfig.isDark ? 'bg-[#0f1117]/95 text-neutral-100' : 'bg-[#fcfbf9]/95 text-slate-900'} flex flex-col justify-between overflow-y-auto animate-slideUp select-none transition-all duration-200`}
      style={{
        transform: dragOffsetY > 0 ? `translateY(${dragOffsetY}px)` : undefined,
        opacity: dragOffsetY > 0 ? Math.max(0.3, 1 - dragOffsetY / 300) : 1
      }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div 
        className={`fixed inset-0 pointer-events-none ${themeConfig.isDark ? 'opacity-20' : 'opacity-10'} filter blur-3xl scale-125 transition-all duration-1000`}
        style={{
          backgroundImage: `radial-gradient(circle at 50% 30%, ${currentTrack.hasMV ? '#06b6d4' : '#6366f1'} 0%, transparent 70%)`
        }}
      />

      <div className="relative z-10 flex-1 flex flex-col justify-between max-w-md w-full mx-auto px-6 py-4">
        {/* Top Bar */}
        <div className="flex items-center justify-between">
          <button
            onClick={onClose}
            className={`p-2 rounded-full ${themeConfig.isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'} active:scale-95 transition`}
            title="Minimize Player"
          >
            <ChevronDown className="w-7 h-7" />
          </button>

          {currentTrack.hasMV ? (
            <div className={`flex items-center ${themeConfig.isDark ? 'bg-neutral-900/90 border-white/10' : 'bg-black/5 border-black/10'} border p-1 rounded-full shadow-inner`}>
              <button
                className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow"
              >
                <Music className="w-3.5 h-3.5" />
                <span>Audio</span>
              </button>

              <button
                onClick={() => onToggleDisplayMode()}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all text-neutral-600 dark:text-neutral-400 hover:text-white"
              >
                <Video className="w-3.5 h-3.5" />
                <span>Video MV</span>
              </button>
            </div>
          ) : (
            <div className={`text-xs font-bold uppercase tracking-widest ${themeConfig.isDark ? 'bg-neutral-900/80 border-white/5 text-neutral-400' : 'bg-black/5 border-black/10 text-neutral-600'} px-3.5 py-1 rounded-full border`}>
              LERZA PLAYER
            </div>
          )}

          <button
            onClick={onOpenEqualizer}
            className={`p-2 rounded-full ${themeConfig.isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'} active:scale-95 transition`}
            title="Equalizer"
          >
            <SlidersHorizontal className="w-5 h-5 opacity-80" />
          </button>
        </div>

        {/* Center Artwork / Stage Area */}
        <div className="my-auto py-2 flex items-center justify-center relative">
          {gestureFeedback && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30 animate-scaleUp">
              <div className="flex items-center gap-2.5 px-5 py-2.5 rounded-2xl bg-black/85 text-white backdrop-blur-xl border border-white/20 shadow-2xl font-bold text-sm tracking-wide">
                {gestureFeedback.icon === 'rewind' && <RotateCcw className="w-5 h-5 text-cyan-400" />}
                {gestureFeedback.icon === 'forward' && <RotateCw className="w-5 h-5 text-cyan-400" />}
                {gestureFeedback.icon === 'play' && <Play className="w-5 h-5 text-emerald-400 fill-current" />}
                {gestureFeedback.icon === 'pause' && <Pause className="w-5 h-5 text-amber-400 fill-current" />}
                <span>{gestureFeedback.text}</span>
              </div>
            </div>
          )}

          <div 
            onClick={handleStageTap}
            className="relative w-48 h-48 sm:w-60 sm:h-60 max-h-[32vh] max-w-[32vh] aspect-square rounded-2xl sm:rounded-3xl overflow-hidden shadow-2xl group border border-black/5 dark:border-white/10 cursor-pointer select-none shrink-0"
          >
            <img
              src={currentTrack.artworkUrl}
              alt={currentTrack.title}
              className={`w-full h-full object-cover transition-transform duration-700 ${
                isPlaying ? 'scale-105' : 'scale-100'
              }`}
              onError={(e) => {
                (e.target as HTMLImageElement).src = generateVinylAlbumArt(currentTrack.title, currentTrack.artist);
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/10" />
          </div>
        </div>

        {/* Track Info Area */}
        <div className="mt-2 mb-3">
          <h2 className="text-2xl sm:text-3xl font-black truncate tracking-tight text-neutral-900 dark:text-white leading-tight">
            {currentTrack.title}
          </h2>

          <div className="flex items-center justify-between gap-3 mt-1.5">
            <p className="text-base font-semibold truncate text-neutral-600 dark:text-neutral-400">
              {currentTrack.artist}
            </p>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => onToggleFavorite(currentTrack.id)}
                className="p-1.5 rounded-full active:scale-90 transition"
                title="Favorite"
              >
                <Heart
                  className={`w-6 h-6 transition-colors ${
                    currentTrack.isFavorite 
                      ? 'text-rose-500 fill-rose-500' 
                      : 'text-neutral-500 hover:text-rose-500'
                  }`}
                />
              </button>

              <button
                onClick={() => setShowThreeDotMenu(true)}
                className="p-1.5 rounded-full text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/10 active:scale-90 transition"
                title="Playback Options & Speed"
              >
                <MoreVertical className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Control Deck with Isolated Gesture Boundaries */}
        <div className="control-deck-area mt-auto backdrop-blur-2xl bg-black/[0.03] dark:bg-white/[0.04] border border-black/5 dark:border-white/10 rounded-3xl p-4 sm:p-5 shadow-xl space-y-4">
          
          {/* PRECISION SEEKBAR / TIMELINE CONTAINER */}
          <div className="seekbar-container relative select-none touch-none py-1">
            <div 
              ref={timelineTrackRef}
              id="player-timeline-track"
              className="relative py-3.5 cursor-pointer flex items-center group select-none"
            >
              {/* Native range slider for 100% reliable hardware touch & drag seeking */}
              <input
                type="range"
                min={0}
                max={effectiveDuration}
                step="0.1"
                value={Number.isFinite(seekValue) ? seekValue : 0}
                onMouseDown={() => setIsSeeking(true)}
                onTouchStart={() => setIsSeeking(true)}
                onInput={(e) => {
                  handleSeekChange(parseFloat(e.currentTarget.value));
                }}
                onChange={(e) => {
                  const val = parseFloat(e.currentTarget.value);
                  handleSeekChange(val);
                  if (!isSeeking) {
                    handleSeekCommit(val);
                  }
                }}
                onMouseUp={(e) => {
                  const val = parseFloat(e.currentTarget.value);
                  handleSeekCommit(val);
                }}
                onTouchEnd={(e) => {
                  const val = parseFloat(e.currentTarget.value);
                  handleSeekCommit(val);
                }}
                className="absolute inset-0 w-full h-full opacity-0 z-20 cursor-pointer touch-none m-0 p-0"
                aria-label="Seek timeline"
              />

              {/* Background Track */}
              <div className={`w-full h-2 rounded-full overflow-hidden ${themeConfig.isDark ? 'bg-neutral-800' : 'bg-neutral-300/80'} relative pointer-events-none`}>
                {/* Active Progress Fill */}
                <div 
                  className="h-full bg-cyan-500 dark:bg-cyan-400 rounded-full transition-[width] duration-75"
                  style={{ width: `${Math.min(100, Math.max(0, ((seekValue || 0) / effectiveDuration) * 100))}%` }}
                />
              </div>

              {/* Thumb Handle / Scrubber */}
              <div
                className={`absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-white shadow-md border-2 border-cyan-500 pointer-events-none transition-transform ${
                  isSeeking ? 'scale-125 ring-4 ring-cyan-500/30' : 'scale-100 group-hover:scale-110'
                }`}
                style={{ left: `${Math.min(100, Math.max(0, ((seekValue || 0) / effectiveDuration) * 100))}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 font-mono -mt-1 pointer-events-none">
              <span className={isSeeking ? 'text-cyan-400 font-bold' : ''}>{formatTime(seekValue)}</span>
              <span>{formatTime(effectiveDuration)}</span>
            </div>
          </div>

          {/* Action Buttons: Shuffle, Prev, Play/Pause, Next, Repeat */}
          <div className="flex items-center justify-between px-1">
            {/* Shuffle Button */}
            <button
              id="fullscreen-shuffle-btn"
              onClick={() => {
                onToggleShuffle();
                showGestureFeedback(!isShuffle ? 'Shuffle: Random Play' : 'Shuffle: OFF', 'forward');
              }}
              className={`p-3 rounded-2xl transition active:scale-90 flex flex-col items-center justify-center ${
                isShuffle 
                  ? 'text-cyan-400 bg-cyan-500/15 border border-cyan-500/30 shadow-md shadow-cyan-500/10' 
                  : 'text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
              title={isShuffle ? "Shuffle Mode: ON (All tracks random)" : "Shuffle Mode: OFF"}
            >
              <Shuffle className="w-6 h-6" />
              <span className="text-[9px] font-bold mt-0.5 tracking-wider">
                {isShuffle ? 'SHUF' : 'OFF'}
              </span>
            </button>

            {/* Previous Track */}
            <button
              id="fullscreen-prev-btn"
              onClick={onPrev}
              className={`p-3 rounded-full ${themeConfig.isDark ? 'text-white' : 'text-neutral-900'} hover:opacity-80 active:scale-90 transition`}
              title="Previous Track"
            >
              <SkipBack className="w-8 h-8 fill-current" />
            </button>

            {/* Play / Pause Toggle */}
            <button
              id="fullscreen-play-pause-btn"
              onClick={onTogglePlay}
              className={`w-18 h-18 sm:w-20 sm:h-20 rounded-full ${themeConfig.isDark ? 'bg-white text-neutral-950' : 'bg-neutral-900 text-white'} flex items-center justify-center shadow-2xl active:scale-95 transition-transform`}
              title={isMediaActuallyPlaying ? "Pause" : "Play"}
            >
              {isMediaActuallyPlaying ? (
                <Pause className="w-8 h-8 fill-current" />
              ) : (
                <Play className="w-8 h-8 fill-current ml-1" />
              )}
            </button>

            {/* Next Track */}
            <button
              id="fullscreen-next-btn"
              onClick={onNext}
              className={`p-3 rounded-full ${themeConfig.isDark ? 'text-white' : 'text-neutral-900'} hover:opacity-80 active:scale-90 transition`}
              title="Next Track"
            >
              <SkipForward className="w-8 h-8 fill-current" />
            </button>

            {/* Repeat Button */}
            <button
              id="fullscreen-repeat-btn"
              onClick={() => {
                onCycleRepeat();
                const nextText = repeatMode === 'off' ? 'Repeat: Current Track' : (repeatMode === 'one' ? 'Repeat: All Tracks' : 'Repeat: OFF');
                showGestureFeedback(nextText, 'forward');
              }}
              className={`p-3 rounded-2xl transition active:scale-90 flex flex-col items-center justify-center ${
                repeatMode !== 'off'
                  ? 'text-cyan-400 bg-cyan-500/15 border border-cyan-500/30 shadow-md shadow-cyan-500/10' 
                  : 'text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
              title={
                repeatMode === 'one' 
                  ? "Repeat: Current Track (Repeating Same Song)" 
                  : repeatMode === 'all' 
                  ? "Repeat: All Tracks" 
                  : "Repeat: OFF"
              }
            >
              {repeatMode === 'one' ? (
                <Repeat1 className="w-6 h-6" />
              ) : (
                <Repeat className="w-6 h-6" />
              )}
              <span className="text-[9px] font-bold mt-0.5 tracking-wider">
                {repeatMode === 'one' ? 'ONE' : (repeatMode === 'all' ? 'ALL' : 'OFF')}
              </span>
            </button>
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              onClick={onOpenEqualizer}
              className="p-2.5 rounded-full text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/10 active:scale-90 transition"
              title="Equalizer"
            >
              <SlidersHorizontal className="w-6 h-6" />
            </button>

            <div className={`px-5 py-1.5 rounded-full border text-xs font-bold ${
              themeConfig.isDark 
                ? 'bg-neutral-900/90 border-neutral-700 text-neutral-200' 
                : 'bg-[#F2E5CA] border-[#E5D4B2] text-neutral-800'
            }`}>
              {currentTrack.genre ? `${currentTrack.genre}` : 'LERZA PLAYER'}
            </div>

            <button
              onClick={onOpenQueue}
              className="p-2.5 rounded-full text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/10 active:scale-90 transition"
              title="Current Playlist / Queue"
            >
              <ListMusic className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Complete Three-Dot Bottom Sheet Menu */}
      {showThreeDotMenu && (
        <div 
          className="fixed inset-0 z-60 bg-black/60 backdrop-blur-sm flex items-end justify-center animate-fadeIn"
          onClick={() => setShowThreeDotMenu(false)}
        >
          <div 
            className={`w-full max-w-lg rounded-t-3xl ${themeConfig.isDark ? 'bg-neutral-900 text-white' : 'bg-[#FAF6EC] text-neutral-900'} p-5 border-t border-black/10 dark:border-white/10 shadow-2xl animate-slideUp max-h-[85vh] overflow-y-auto`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-neutral-300 dark:bg-neutral-700 rounded-full mx-auto mb-3" />
            
            <div className="flex items-center justify-between pb-3 border-b border-black/10 dark:border-white/10">
              <div className="flex items-center gap-2">
                <Gauge className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h3 className="text-base font-bold">Playback Options</h3>
              </div>
              <button
                onClick={() => setShowThreeDotMenu(false)}
                className="p-1 rounded-full hover:bg-black/5 dark:hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Playback Speed Section */}
            <div className="py-3.5 border-b border-black/10 dark:border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  Playback Speed
                </span>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-blue-600/15 text-blue-600 dark:text-blue-400">
                  {playbackSpeed}x
                </span>
              </div>
              <div className="grid grid-cols-6 gap-1.5">
                {speeds.map((s) => (
                  <button
                    key={s}
                    onClick={() => onChangeSpeed(s)}
                    className={`py-2 text-xs font-bold rounded-xl transition ${
                      playbackSpeed === s
                        ? 'bg-blue-600 text-white shadow-md'
                        : `${themeConfig.isDark ? 'bg-neutral-800 text-neutral-300' : 'bg-black/5 text-neutral-700'} hover:opacity-80`
                    }`}
                  >
                    {s}x
                  </button>
                ))}
              </div>
            </div>

            {/* Volume Boost Section */}
            <div className="py-3.5 border-b border-black/10 dark:border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-amber-500" />
                  Super Volume Boost
                </span>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-amber-500/15 text-amber-600 dark:text-amber-400">
                  {Math.round(volumeMultiplier * 100)}%
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {volumeOptions.map((opt) => (
                  <button
                    key={opt.label}
                    onClick={() => onChangeVolumeMultiplier(opt.val)}
                    className={`py-2 text-xs font-bold rounded-xl transition ${
                      volumeMultiplier === opt.val
                        ? 'bg-amber-500 text-neutral-950 shadow-md font-extrabold'
                        : `${themeConfig.isDark ? 'bg-neutral-800 text-neutral-300' : 'bg-black/5 text-neutral-700'} hover:opacity-80`
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Equalizer, Lyrics, Add to Playlist, Shuffle, Repeat Actions */}
            <div className="py-3.5 border-b border-black/10 dark:border-white/10 grid grid-cols-2 gap-2.5">
              <button
                onClick={() => {
                  setShowThreeDotMenu(false);
                  onOpenEqualizer();
                }}
                className={`flex items-center gap-2.5 p-3 rounded-2xl ${
                  themeConfig.isDark ? 'bg-neutral-800 hover:bg-neutral-700' : 'bg-black/5 hover:bg-black/10'
                } transition text-left`}
              >
                <SlidersHorizontal className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <div>
                  <div className="text-xs font-bold">Equalizer & Bass</div>
                  <div className="text-[11px] text-neutral-500">5-Band Audio DSP</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setShowThreeDotMenu(false);
                  onOpenLyrics();
                }}
                className={`flex items-center gap-2.5 p-3 rounded-2xl ${
                  themeConfig.isDark ? 'bg-neutral-800 hover:bg-neutral-700' : 'bg-black/5 hover:bg-black/10'
                } transition text-left`}
              >
                <FileText className="w-5 h-5 text-emerald-500" />
                <div>
                  <div className="text-xs font-bold">Lyrics</div>
                  <div className="text-[11px] text-neutral-500">View Song Words</div>
                </div>
              </button>

              {onAddToPlaylistClick && (
                <button
                  onClick={() => {
                    setShowThreeDotMenu(false);
                    onAddToPlaylistClick();
                  }}
                  className={`flex items-center gap-2.5 p-3 rounded-2xl ${
                    themeConfig.isDark ? 'bg-neutral-800 hover:bg-neutral-700' : 'bg-black/5 hover:bg-black/10'
                  } transition text-left`}
                >
                  <ListPlus className="w-5 h-5 text-amber-500" />
                  <div>
                    <div className="text-xs font-bold">Add to Playlist</div>
                    <div className="text-[11px] text-neutral-500">Save to list</div>
                  </div>
                </button>
              )}

              <button
                onClick={onToggleShuffle}
                className={`flex items-center gap-2.5 p-3 rounded-2xl ${
                  isShuffle 
                    ? 'bg-blue-600/20 text-blue-600 dark:text-blue-400 border border-blue-500/30' 
                    : (themeConfig.isDark ? 'bg-neutral-800' : 'bg-black/5')
                } transition text-left`}
              >
                <Shuffle className="w-5 h-5" />
                <div>
                  <div className="text-xs font-bold">Shuffle Mode</div>
                  <div className="text-[11px] text-neutral-500">{isShuffle ? 'On' : 'Off'}</div>
                </div>
              </button>

              <button
                onClick={onCycleRepeat}
                className={`flex items-center gap-2.5 p-3 rounded-2xl ${
                  repeatMode !== 'off'
                    ? 'bg-blue-600/20 text-blue-600 dark:text-blue-400 border border-blue-500/30' 
                    : (themeConfig.isDark ? 'bg-neutral-800' : 'bg-black/5')
                } transition text-left`}
              >
                {repeatMode === 'one' ? <Repeat1 className="w-5 h-5" /> : <Repeat className="w-5 h-5" />}
                <div>
                  <div className="text-xs font-bold">Repeat Mode</div>
                  <div className="text-[11px] text-neutral-500 capitalize">{repeatMode}</div>
                </div>
              </button>
            </div>

            {/* Sleep Timer Section */}
            {onSetSleepTimer && (
              <div className="py-3.5 border-b border-black/10 dark:border-white/10">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-bold flex items-center gap-2">
                    <Timer className="w-4 h-4 text-purple-500" />
                    Sleep Timer
                  </span>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-purple-500/15 text-purple-600 dark:text-purple-400">
                    {sleepTimerMinutes ? `${sleepTimerMinutes}m` : 'Off'}
                  </span>
                </div>
                <div className="grid grid-cols-5 gap-1.5">
                  {[
                    { label: 'Off', val: null },
                    { label: '15m', val: 15 },
                    { label: '30m', val: 30 },
                    { label: '45m', val: 45 },
                    { label: '60m', val: 60 }
                  ].map((item) => (
                    <button
                      key={item.label}
                      onClick={() => onSetSleepTimer(item.val)}
                      className={`py-2 text-xs font-bold rounded-xl transition ${
                        sleepTimerMinutes === item.val
                          ? 'bg-purple-600 text-white shadow-md'
                          : `${themeConfig.isDark ? 'bg-neutral-800 text-neutral-300' : 'bg-black/5 text-neutral-700'} hover:opacity-80`
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Audio Metadata Footer */}
            <div className="pt-3 text-xs space-y-1 text-neutral-500 dark:text-neutral-400 font-mono">
              <div className="flex justify-between">
                <span>Format:</span>
                <span className="font-bold text-neutral-700 dark:text-neutral-200">{currentTrack.fileFormat || 'MP3'}</span>
              </div>
              <div className="flex justify-between">
                <span>Duration:</span>
                <span className="font-bold text-neutral-700 dark:text-neutral-200">{formatTime(duration)}</span>
              </div>
              <div className="flex justify-between">
                <span>Album:</span>
                <span className="font-bold text-neutral-700 dark:text-neutral-200 truncate max-w-[200px]">{currentTrack.album || 'Unknown'}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
