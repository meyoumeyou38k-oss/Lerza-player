import React from 'react';

interface AdBannerProps {
  isOnline?: boolean;
  isAdsRemoved?: boolean;
}

export const AdBanner: React.FC<AdBannerProps> = () => {
  // All advertisements completely removed per user instructions
  return null;
};
