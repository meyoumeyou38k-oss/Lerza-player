import React, { useState } from 'react';
import { MediaTrack } from '../types';
import { Folder, Disc3, Mic2, Music, Play, ChevronRight } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface FoldersAlbumsArtistsViewProps {
  type: 'folders' | 'albums' | 'artists';
  tracks: MediaTrack[];
  onSelectTrack: (track: MediaTrack) => void;
}

export const FoldersAlbumsArtistsView: React.FC<FoldersAlbumsArtistsViewProps> = ({
  type,
  tracks,
  onSelectTrack
}) => {
  const { config: themeConfig } = useTheme();
  const [activeGroup, setActiveGroup] = useState<string | null>(null);

  // Compute groupings based on type
  const groupedData: Record<string, MediaTrack[]> = {};

  tracks.forEach(track => {
    let key = 'Unknown';
    if (type === 'folders') {
      key = track.folder || 'Internal / Media';
    } else if (type === 'albums') {
      key = track.album || 'Single Tracks';
    } else if (type === 'artists') {
      key = track.artist || 'Unknown Artist';
    }

    if (!groupedData[key]) {
      groupedData[key] = [];
    }
    groupedData[key].push(track);
  });

  const groupKeys = Object.keys(groupedData);

  return (
    <div className="px-4 py-3 max-w-6xl mx-auto pb-28">
      <div className="flex items-center justify-between mb-4">
        <h3 className={`text-sm font-bold ${themeConfig.textPrimary} capitalize`}>
          {type} ({groupKeys.length})
        </h3>
      </div>

      {/* Grid or List of Groupings */}
      <div className="space-y-2">
        {groupKeys.map(key => {
          const groupTracks = groupedData[key];
          const representativeTrack = groupTracks[0];
          const isExpanded = activeGroup === key;

          return (
            <div
              key={key}
              className={`rounded-2xl ${themeConfig.cardBg} border ${themeConfig.cardBorder} overflow-hidden transition`}
            >
              <div
                onClick={() => setActiveGroup(isExpanded ? null : key)}
                className={`flex items-center justify-between p-3 cursor-pointer ${themeConfig.cardHover} transition`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-11 h-11 rounded-xl ${themeConfig.isDark ? 'bg-neutral-800' : 'bg-slate-200'} flex items-center justify-center shrink-0 overflow-hidden relative`}>
                    {type === 'folders' ? (
                      <Folder className="w-5 h-5 text-cyan-500" />
                    ) : (
                      <img
                        src={representativeTrack.artworkUrl}
                        alt={key}
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h4 className={`text-sm font-semibold ${themeConfig.textPrimary} truncate`}>
                      {key}
                    </h4>
                    <p className={`text-xs ${themeConfig.textSecondary} mt-0.5`}>
                      {groupTracks.length} {groupTracks.length === 1 ? 'Track' : 'Tracks'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <ChevronRight
                    className={`w-4 h-4 ${themeConfig.textSecondary} transition-transform duration-300 ${
                      isExpanded ? 'rotate-90 text-cyan-500' : ''
                    }`}
                  />
                </div>
              </div>

              {/* Sub-list of tracks when expanded */}
              {isExpanded && (
                <div className={`px-3 pb-3 pt-1 border-t ${themeConfig.cardBorder} ${themeConfig.isDark ? 'bg-neutral-950/40' : 'bg-slate-50/70'} space-y-1`}>
                  {groupTracks.map((trk, i) => (
                    <div
                      key={trk.id}
                      onClick={() => onSelectTrack(trk)}
                      className={`flex items-center justify-between p-2 rounded-xl ${themeConfig.isDark ? 'hover:bg-white/5' : 'hover:bg-black/5'} cursor-pointer text-xs group`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className={`${themeConfig.textMuted} w-4 font-mono`}>{i + 1}</span>
                        <div className="truncate">
                          <p className={`font-semibold ${themeConfig.textPrimary} truncate group-hover:${themeConfig.accentText}`}>
                            {trk.title}
                          </p>
                          <p className={`text-[11px] ${themeConfig.textSecondary} truncate`}>
                            {trk.artist}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`${themeConfig.textMuted} font-mono`}>
                          {Math.floor(trk.duration / 60)}:{(trk.duration % 60).toString().padStart(2, '0')}
                        </span>
                        <Play className="w-3.5 h-3.5 text-cyan-500 opacity-0 group-hover:opacity-100 transition" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
