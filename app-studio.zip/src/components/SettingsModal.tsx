import React, { useState, useRef } from 'react';
import { AppSettings, ThemeMode } from '../types';
import { useTheme } from '../context/ThemeContext';
import { 
  Settings, 
  X, 
  ShieldCheck, 
  Clock, 
  Sliders, 
  Info, 
  Image as ImageIcon, 
  Trash2, 
  ArrowLeft, 
  Palette, 
  Check, 
  Sparkles,
  ExternalLink,
  RefreshCw,
  Globe,
  FolderPlus,
  Zap
} from 'lucide-react';

interface SettingsModalProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onOpenEqualizer: () => void;
  onClearDemoTracks: () => void;
  onClose: () => void;
  onScanAndImport?: () => void;
  currentVersion?: string;
  currentBuild?: number;
  onCheckForUpdates?: () => void;
  onOpenWebsite?: () => void;
  volumeMultiplier?: number;
  onChangeVolumeMultiplier?: (multiplier: number) => void;
  hiddenTracksCount?: number;
  onOpenVault?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onOpenEqualizer,
  onClearDemoTracks,
  onClose,
  onScanAndImport,
  currentVersion = '1.0.1',
  currentBuild = 101,
  onCheckForUpdates,
  onOpenWebsite,
  volumeMultiplier = 1.0,
  onChangeVolumeMultiplier,
  hiddenTracksCount = 0,
  onOpenVault
}) => {
  const { config: themeConfig } = useTheme();
  const [showPurchaseDialog, setShowPurchaseDialog] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [batteryExempt, setBatteryExempt] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  const handleRequestBatteryExemption = () => {
    if ((window as any).AndroidBridge?.requestBatteryOptimizationExemption) {
      try {
        (window as any).AndroidBridge.requestBatteryOptimizationExemption();
        setBatteryExempt(true);
      } catch (e) {
        console.warn('Battery exemption request error:', e);
      }
    } else {
      setBatteryExempt(prev => !prev);
    }
  };

  // Level 2 Sub-view Back Handler
  React.useEffect(() => {
    const onSubviewBack = (e: Event) => {
      if (showPurchaseDialog) {
        setShowPurchaseDialog(false);
        e.preventDefault();
      } else if (showClearConfirm) {
        setShowClearConfirm(false);
        e.preventDefault();
      }
    };
    window.addEventListener('subview-back-press', onSubviewBack);
    return () => window.removeEventListener('subview-back-press', onSubviewBack);
  }, [showPurchaseDialog, showClearConfirm]);

  const sleepOptions = [
    { label: 'Off', val: null },
    { label: '15 min', val: 15 },
    { label: '30 min', val: 30 },
    { label: '45 min', val: 45 },
    { label: '60 min', val: 60 },
  ];

  const PRESET_WALLPAPERS = [
    {
      id: 'cyberpunk',
      name: 'Cyber Neon',
      url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80',
      thumb: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=240&q=80'
    },
    {
      id: 'ocean',
      name: 'Deep Oceanic',
      url: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=1200&q=80',
      thumb: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=240&q=80'
    },
    {
      id: 'sunset',
      name: 'Sunset Sky',
      url: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80',
      thumb: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=240&q=80'
    },
    {
      id: 'studio',
      name: 'Acoustic Studio',
      url: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=1200&q=80',
      thumb: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=240&q=80'
    },
    {
      id: 'aurora',
      name: 'Emerald Aurora',
      url: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=1200&q=80',
      thumb: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=240&q=80'
    },
    {
      id: 'abstract',
      name: 'Dark Texture',
      url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
      thumb: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=240&q=80'
    }
  ];

  const currentWallpaper = settings.customWallpaper || (settings as any).customWallpaperUrl;

  const themeList: { id: ThemeMode; label: string; sub: string; color: string; border: string; previewBg: string }[] = [
    { id: 'dark', label: 'AMOLED Black', sub: 'Deep Pure Dark', color: 'bg-black text-white', border: 'border-white/20', previewBg: '#000000' },
    { id: 'light', label: 'Pure White', sub: 'Ultra Clean Light', color: 'bg-white text-slate-900', border: 'border-slate-300', previewBg: '#ffffff' },
    { id: 'pink', label: 'Soft Rose', sub: 'Pastel Rose Tint', color: 'bg-[#fff1f2] text-rose-950', border: 'border-rose-300', previewBg: '#fff1f2' },
    { id: 'green', label: 'Mint Sage', sub: 'Emerald Tint', color: 'bg-[#f0fdf4] text-emerald-950', border: 'border-emerald-300', previewBg: '#f0fdf4' },
    { id: 'sky', label: 'Pastel Sky', sub: 'Cyan Blue Tint', color: 'bg-[#f0f9ff] text-sky-950', border: 'border-sky-300', previewBg: '#f0f9ff' },
    { id: 'purple', label: 'Soft Lavender', sub: 'Royal Violet Tint', color: 'bg-[#faf5ff] text-purple-950', border: 'border-purple-300', previewBg: '#faf5ff' },
    { id: 'amber', label: 'Sunset Amber', sub: 'Warm Honey Glow', color: 'bg-[#fffbeb] text-amber-950', border: 'border-amber-300', previewBg: '#fffbeb' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className={`w-full max-w-lg ${themeConfig.modalBg} border ${themeConfig.modalBorder} rounded-3xl p-5 shadow-2xl max-h-[90vh] flex flex-col justify-between transition-colors animate-scaleUp`}>
        {/* Header with Back Button */}
        <div className={`flex items-center justify-between pb-3 border-b ${themeConfig.isDark ? 'border-white/10' : 'border-slate-200'} shrink-0`}>
          <div className="flex items-center gap-2.5">
            <button
              onClick={onClose}
              className={`p-1.5 -ml-1 rounded-xl transition flex items-center gap-1 text-xs font-semibold ${
                themeConfig.isDark ? 'bg-white/5 hover:bg-white/10 text-neutral-300' : 'bg-black/5 hover:bg-black/10 text-slate-700'
              }`}
              title="Back to Home"
            >
              <ArrowLeft className={`w-4 h-4 ${themeConfig.accentText}`} />
              <span>Back</span>
            </button>
            <div className={`h-5 w-px ${themeConfig.isDark ? 'bg-white/10' : 'bg-slate-200'} mx-0.5`} />
            <div className={`w-8 h-8 rounded-xl ${themeConfig.isDark ? 'bg-cyan-500/20 text-cyan-400' : 'bg-sky-500/20 text-sky-600'} flex items-center justify-center`}>
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className={`text-sm font-bold ${themeConfig.textPrimary}`}>Lerza Player Settings</h3>
              <p className={`text-[11px] ${themeConfig.textSecondary}`}>Media Import, Themes, Wallpaper & Performance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-full transition ${themeConfig.textSecondary} hover:${themeConfig.textPrimary} hover:bg-black/5`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="space-y-4 my-3 overflow-y-auto pr-1 flex-1">
          {/* Section: Scan & Import Media (Relocated from Main Header) */}
          {onScanAndImport && (
            <div>
              <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} mb-2 flex items-center gap-1.5`}>
                <FolderPlus className="w-3.5 h-3.5 text-cyan-500" />
                <span>Scan & Import Media</span>
              </h4>
              <div className={`p-3.5 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-white/5' : 'bg-slate-50 border-slate-200'} flex items-center justify-between`}>
                <div>
                  <p className={`text-xs font-semibold ${themeConfig.textPrimary}`}>Import Audio & Video Files</p>
                  <p className={`text-[11px] ${themeConfig.textSecondary}`}>Scan device storage and load songs or videos</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onScanAndImport();
                  }}
                  className={`px-3.5 py-1.5 rounded-xl ${themeConfig.accentBg} font-bold text-xs shadow-md active:scale-95 transition cursor-pointer flex items-center gap-1.5`}
                >
                  <FolderPlus className="w-4 h-4" />
                  <span>Import Media</span>
                </button>
              </div>
            </div>
          )}

          {/* Section: Background Playback & Battery Optimization */}
          <div>
            <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} mb-2 flex items-center gap-1.5`}>
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span>Background Playback & Performance</span>
            </h4>
            <div className={`p-3.5 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-white/5' : 'bg-slate-50 border-slate-200'} space-y-2.5`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-xs font-semibold ${themeConfig.textPrimary}`}>Battery Optimization Exemption</p>
                  <p className={`text-[11px] ${themeConfig.textSecondary}`}>Ensure audio never stops when screen turns off</p>
                </div>
                <button
                  type="button"
                  onClick={handleRequestBatteryExemption}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shadow-md active:scale-95 transition cursor-pointer ${
                    batteryExempt
                      ? 'bg-emerald-500 text-white shadow-emerald-500/20'
                      : 'bg-amber-500 hover:bg-amber-400 text-neutral-950 shadow-amber-500/20'
                  }`}
                >
                  {batteryExempt ? 'Exempt (Active)' : 'Request Exemption'}
                </button>
              </div>
              <p className={`text-[10.5px] ${themeConfig.textMuted} pt-1.5 border-t ${themeConfig.isDark ? 'border-white/5' : 'border-slate-200'}`}>
                Notification controls (Play/Pause, Next, Previous) remain active in the system lock screen and notification panel.
              </p>
            </div>
          </div>
          {/* Section: Themes Selector (Dark, Light, Pink, Green, Sky, Purple, Amber) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} flex items-center gap-1.5`}>
                <Palette className="w-3.5 h-3.5 text-cyan-500" />
                <span>App Theme Colors</span>
              </h4>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${themeConfig.isDark ? 'bg-white/10 text-neutral-300' : 'bg-slate-200 text-slate-700'}`}>
                Active: {settings.theme}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {themeList.map((t) => {
                const isSelected = settings.theme === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => onUpdateSettings({ theme: t.id })}
                    className={`p-2.5 rounded-2xl border text-left flex items-center gap-2.5 transition relative ${
                      isSelected
                        ? 'border-2 border-cyan-500 shadow-md ring-2 ring-cyan-500/20'
                        : `${themeConfig.isDark ? 'bg-neutral-900/60 border-white/10 hover:border-white/20' : 'bg-slate-50 border-slate-200 hover:border-slate-300'}`
                    }`}
                  >
                    <div
                      className={`w-6 h-6 rounded-full shrink-0 border ${t.border} shadow-xs flex items-center justify-center`}
                      style={{ backgroundColor: t.previewBg }}
                    >
                      {isSelected && (
                        <Check className={`w-3.5 h-3.5 ${t.id === 'light' ? 'text-black' : 'text-cyan-500'} stroke-[3]`} />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className={`text-xs font-bold truncate ${themeConfig.textPrimary}`}>
                        {t.label}
                      </p>
                      <p className={`text-[10px] truncate ${themeConfig.textSecondary}`}>
                        {t.sub}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
            <p className={`text-[11px] ${themeConfig.textMuted} mt-2`}>
              Theme selection instantly updates all headers, full-screen player, playlists, modals, and typography colors.
            </p>
          </div>

          {/* Section: ABOUT LERZA PLAYER & DEVELOPER */}
          <div className="pt-2">
            <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} mb-2 flex items-center gap-1.5`}>
              <Info className="w-3.5 h-3.5 text-cyan-500" />
              <span>About Lerza Player & Developer</span>
            </h4>
            <div className={`p-4 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-white/10' : 'bg-slate-50 border-slate-200'} space-y-3`}>
              <div className="flex items-center gap-3.5">
                <img 
                  src="/app-logo.png?v=2" 
                  alt="Lerza Player Logo" 
                  className="w-14 h-14 object-contain rounded-2xl shadow-sm drop-shadow-md shrink-0 select-none"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/app-icon.png?v=2';
                  }}
                />
                <div>
                  <h5 className={`text-sm font-black ${themeConfig.textPrimary} tracking-wide`}>
                    Lerza Player Pro Suite
                  </h5>
                  <p className={`text-xs ${themeConfig.textSecondary}`}>
                    Next-Gen Offline 4K Video & Audio Engine
                  </p>
                  <p className="text-[11px] text-cyan-500 font-bold mt-0.5">
                    Developed by: Faraz Munawar
                  </p>
                </div>
              </div>

              {/* Developer Profile & Introduction */}
              <div className={`p-3 rounded-xl ${themeConfig.isDark ? 'bg-black/30' : 'bg-white'} border ${themeConfig.isDark ? 'border-white/5' : 'border-slate-200'} text-xs leading-relaxed space-y-2`}>
                <p className={`font-semibold ${themeConfig.textPrimary} text-xs`}>
                  Developer Profile & Architecture:
                </p>
                <p className={`${themeConfig.textSecondary}`}>
                  Faraz Munawar is a dedicated software engineer specializing in responsive, high-performance multimedia applications. Lerza Player was engineered to bridge professional studio-grade WebAudio DSP hardware filtering with fluid 4K Ultra-HD offline video decoding.
                </p>
                <p className={`${themeConfig.textSecondary}`}>
                  Designed with an offline-first philosophy, Lerza Player delivers seamless audio-video switching, synchronous lyrics, smart auto-synchronized Favorites, customizable transparent wallpapers, and full color theme personalization.
                </p>
              </div>

              {/* Key Specs Grid */}
              <div className={`text-xs space-y-1.5 pt-2 border-t ${themeConfig.isDark ? 'border-white/10' : 'border-slate-200'}`}>
                <div className="flex justify-between">
                  <span className={themeConfig.textSecondary}>App Version:</span>
                  <span className="font-mono text-cyan-500 font-bold">v3.0.0 Pro Edition</span>
                </div>
                <div className="flex justify-between">
                  <span className={themeConfig.textSecondary}>Lead Developer:</span>
                  <span className={`font-semibold ${themeConfig.textPrimary}`}>Faraz Munawar</span>
                </div>
                <div className="flex justify-between">
                  <span className={themeConfig.textSecondary}>Core Engine:</span>
                  <span className={`font-semibold ${themeConfig.textPrimary}`}>Media3 & WebAudio DSP</span>
                </div>
                <div className="flex justify-between">
                  <span className={themeConfig.textSecondary}>Supported Themes:</span>
                  <span className="font-semibold text-emerald-600">Pure White, AMOLED, Rose, Mint, Sky, Purple, Amber</span>
                </div>
                <div className="flex justify-between">
                  <span className={themeConfig.textSecondary}>Smart Favorites:</span>
                  <span className="text-rose-500 font-semibold">Active & Synced</span>
                </div>
              </div>
            </div>
          </div>

          {/* Section: Custom Wallpaper & Transparency */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} flex items-center gap-1.5`}>
                <ImageIcon className="w-3.5 h-3.5 text-cyan-500" />
                <span>Custom Wallpaper & Transparency</span>
              </h4>
              {currentWallpaper && (
                <span className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                  Applied
                </span>
              )}
            </div>

            <div className={`p-3.5 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-white/5' : 'bg-slate-50 border-slate-200'} space-y-3`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-xs font-semibold ${themeConfig.textPrimary}`}>Device Gallery Photo</p>
                  <p className={`text-[11px] ${themeConfig.textSecondary}`}>
                    {currentWallpaper ? 'Custom wallpaper active' : 'Select any picture from your device gallery'}
                  </p>
                </div>
                <div>
                  <button 
                    type="button"
                    onClick={() => photoInputRef.current?.click()}
                    className={`px-3.5 py-2 rounded-xl ${themeConfig.isDark ? 'bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30' : 'bg-cyan-600 hover:bg-cyan-700 text-white'} font-semibold text-xs cursor-pointer active:scale-95 transition shadow-sm flex items-center gap-1.5`}
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>Choose Photo</span>
                  </button>
                  <input
                    ref={photoInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = () => {
                          if (typeof reader.result === 'string') {
                            onUpdateSettings({ 
                              customWallpaper: reader.result
                            });
                          }
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </div>
              </div>

              {/* Preset Curated Wallpapers */}
              <div>
                <p className={`text-[11px] font-semibold ${themeConfig.textSecondary} mb-2`}>
                  Or Choose Curated Aesthetic Wallpaper:
                </p>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {PRESET_WALLPAPERS.map((preset) => {
                    const isSelected = currentWallpaper === preset.url;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => {
                          onUpdateSettings({ 
                            customWallpaper: preset.url
                          });
                        }}
                        className={`group relative rounded-xl overflow-hidden aspect-video border transition cursor-pointer ${
                          isSelected 
                            ? 'border-2 border-cyan-400 ring-2 ring-cyan-400/30 scale-105 shadow-md' 
                            : 'border-white/10 hover:border-cyan-400/50 hover:scale-102'
                        }`}
                        title={preset.name}
                      >
                        <img 
                          src={preset.thumb} 
                          alt={preset.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                          <span className="text-[9px] font-bold text-white text-center px-1">
                            {preset.name}
                          </span>
                        </div>
                        {isSelected && (
                          <div className="absolute top-1 right-1 bg-cyan-500 rounded-full p-0.5 shadow-sm">
                            <Check className="w-2.5 h-2.5 text-black stroke-[3]" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Wallpaper Opacity Slider and Clear Action */}
              {currentWallpaper && (
                <div className={`pt-2 border-t ${themeConfig.isDark ? 'border-white/10' : 'border-slate-200'} space-y-2`}>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className={themeConfig.textSecondary}>Background Transparency (Opacity):</span>
                      <span className={`font-mono font-bold ${themeConfig.accentText}`}>
                        {Math.round((settings.wallpaperOpacity ?? 0.35) * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0.10"
                      max="0.85"
                      step="0.05"
                      value={settings.wallpaperOpacity ?? 0.35}
                      onChange={(e) => onUpdateSettings({ wallpaperOpacity: parseFloat(e.target.value) })}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ customWallpaper: null })}
                    className="text-xs text-rose-500 hover:text-rose-400 flex items-center gap-1 font-semibold transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove Wallpaper (Revert to Clean Theme)</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Section: Audio Enhancement & Equalizer */}
          <div className="space-y-3">
            <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} mb-2 flex items-center gap-1.5`}>
              <Sliders className="w-3.5 h-3.5 text-cyan-500" />
              <span>Audio Enhancement & Equalizer</span>
            </h4>
            
            {/* Equalizer Launch */}
            <div className={`p-3.5 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-white/5' : 'bg-slate-50 border-slate-200'} flex items-center justify-between`}>
              <div>
                <p className={`text-xs font-semibold ${themeConfig.textPrimary}`}>5-Band Hardware EQ & Bass Boost</p>
                <p className={`text-[11px] ${themeConfig.textSecondary}`}>32Hz - 16kHz DSP filters with stereo widening</p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onOpenEqualizer();
                }}
                className={`px-3 py-1.5 rounded-xl ${themeConfig.accentBg} font-bold text-xs shadow-md active:scale-95 transition cursor-pointer`}
              >
                Open EQ
              </button>
            </div>

            {/* Volume Boost / Hardware Gain Multiplier */}
            <div className={`p-3.5 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-white/5' : 'bg-slate-50 border-slate-200'} space-y-2`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-xs font-semibold ${themeConfig.textPrimary} flex items-center gap-1.5`}>
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    <span>Hardware Volume Boost</span>
                  </p>
                  <p className={`text-[11px] ${themeConfig.textSecondary}`}>
                    Gain amplification node (100% to 300% for quiet recordings)
                  </p>
                </div>
                <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-lg">
                  {Math.round(volumeMultiplier * 100)}%
                </span>
              </div>

              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {[
                  { label: '100%', val: 1.0, desc: 'Normal' },
                  { label: '150%', val: 1.5, desc: 'Boost' },
                  { label: '200%', val: 2.0, desc: 'Super' },
                  { label: '300%', val: 3.0, desc: 'Max 3x' }
                ].map((btn) => {
                  const isSelected = Math.abs(volumeMultiplier - btn.val) < 0.05;
                  return (
                    <button
                      key={btn.val}
                      onClick={() => onChangeVolumeMultiplier && onChangeVolumeMultiplier(btn.val)}
                      className={`py-2 px-1 rounded-xl text-center transition cursor-pointer flex flex-col items-center ${
                        isSelected
                          ? 'bg-amber-500 text-black font-extrabold shadow-md shadow-amber-500/20 scale-[1.02]'
                          : themeConfig.isDark
                          ? 'bg-neutral-800/80 hover:bg-neutral-700/80 text-neutral-300'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      <span className="text-xs font-bold">{btn.label}</span>
                      <span className={`text-[10px] ${isSelected ? 'text-black/75' : 'text-neutral-500'}`}>
                        {btn.desc}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Section: Sleep Timer */}
          <div>
            <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} mb-2 flex items-center gap-1.5`}>
              <Clock className="w-3.5 h-3.5 text-cyan-500" />
              <span>Sleep Timer</span>
            </h4>
            <div className="grid grid-cols-5 gap-2">
              {sleepOptions.map((opt) => (
                <button
                  key={opt.label}
                  onClick={() => onUpdateSettings({ sleepTimerMinutes: opt.val })}
                  className={`py-2 px-1 rounded-xl text-xs font-semibold border transition cursor-pointer ${
                    settings.sleepTimerMinutes === opt.val
                      ? `${themeConfig.accentBg} shadow-md`
                      : `${themeConfig.isDark ? 'bg-neutral-900/50 border-white/5 text-neutral-400 hover:text-white' : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'}`
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Section: Private Vault (محفوظ فائلیں) */}
          {onOpenVault && (
            <div>
              <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} mb-2 flex items-center gap-1.5`}>
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                <span>Private Vault (محفوظ فائلیں)</span>
              </h4>
              <div className={`p-3.5 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-cyan-500/20' : 'bg-slate-50 border-cyan-500/30'} flex items-center justify-between`}>
                <div>
                  <div className="flex items-center gap-2">
                    <p className={`text-xs font-semibold ${themeConfig.textPrimary}`}>Protected Files</p>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-400">
                      {hiddenTracksCount} Protected
                    </span>
                  </div>
                  <p className={`text-[11px] ${themeConfig.textSecondary}`}>
                    Unlock with your PIN or Pattern to view & restore hidden media
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenVault();
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs shadow-md shadow-cyan-500/20 active:scale-95 transition cursor-pointer flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Open Vault</span>
                </button>
              </div>
            </div>
          )}

          {/* Section: 100% Ad-Free Player */}
          <div>
            <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} mb-2 flex items-center gap-1.5`}>
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Ad-Free Experience (بغیر اشتہارات)</span>
            </h4>
            <div className={`p-3.5 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-emerald-500/20' : 'bg-emerald-50/50 border-emerald-200'} flex items-center justify-between`}>
              <div>
                <p className={`text-xs font-semibold ${themeConfig.textPrimary} flex items-center gap-1.5`}>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>100% Ad-Free Permanent Status</span>
                </p>
                <p className={`text-[11px] ${themeConfig.textSecondary}`}>
                  All banners, native ads, promo clips, and popups have been completely removed.
                </p>
              </div>
              <span className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Ad-Free Active
              </span>
            </div>
          </div>

          {/* Section: Storage & Clear Demo Files */}
          <div>
            <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} mb-2 flex items-center gap-1.5`}>
              <Trash2 className="w-3.5 h-3.5 text-rose-500" />
              <span>Storage & Demo Media</span>
            </h4>
            <div className={`p-3.5 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-white/5' : 'bg-slate-50 border-slate-200'} flex items-center justify-between`}>
              <div>
                <p className={`text-xs font-semibold ${themeConfig.textPrimary}`}>Sample Demo Tracks</p>
                <p className={`text-[11px] ${themeConfig.textSecondary}`}>Remove pre-loaded sample songs to display only real imported files</p>
              </div>
              <button
                onClick={() => setShowClearConfirm(true)}
                className="px-3 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-600 border border-rose-500/30 text-xs font-bold transition cursor-pointer"
              >
                Clear Demo Files
              </button>
            </div>
          </div>

          {/* Section: App Version & In-App Updates */}
          <div>
            <h4 className={`text-xs font-bold uppercase tracking-wider ${themeConfig.textSecondary} mb-2 flex items-center gap-1.5`}>
              <RefreshCw className="w-3.5 h-3.5 text-blue-500" />
              <span>App Version & Updates (اپڈیٹس)</span>
            </h4>
            <div className={`p-3.5 rounded-2xl border ${themeConfig.isDark ? 'bg-neutral-900/60 border-white/5' : 'bg-slate-50 border-slate-200'} space-y-3`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-xs font-bold ${themeConfig.textPrimary} flex items-center gap-2`}>
                    <span>Lerza Player Pro</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-blue-500/15 text-blue-500 font-bold">
                      v{currentVersion}
                    </span>
                  </p>
                  <p className={`text-[11px] ${themeConfig.textSecondary}`}>
                    Build {currentBuild} • Performance & Gesture Engine Updated
                  </p>
                </div>
                <button
                  onClick={onCheckForUpdates}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/20 flex items-center gap-1.5 transition cursor-pointer active:scale-95"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Check Update</span>
                </button>
              </div>

              {onOpenWebsite && (
                <div className="pt-2 border-t border-black/5 dark:border-white/5 flex items-center justify-between">
                  <span className={`text-[11px] ${themeConfig.textSecondary}`}>
                    Official Website & APK Downloads:
                  </span>
                  <button
                    onClick={onOpenWebsite}
                    className="text-xs font-bold text-blue-500 hover:text-blue-400 flex items-center gap-1 cursor-pointer"
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>lerzaplayer.vercel.app</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className={`pt-3 border-t ${themeConfig.isDark ? 'border-white/10' : 'border-slate-200'} text-center shrink-0`}>
          <p className={`text-[11px] ${themeConfig.textMuted}`}>
            Lerza Player Pro • Developed by Faraz Munawar • Offline Media Excellence
          </p>
        </div>

        {/* Simulated In-App Billing Modal */}
        {showPurchaseDialog && (
          <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
            <div className={`border rounded-2xl p-5 max-w-sm w-full shadow-2xl ${themeConfig.modalBg} ${themeConfig.modalBorder}`}>
              <h4 className={`text-base font-bold mb-1 ${themeConfig.textPrimary}`}>Google Play Billing</h4>
              <p className={`text-xs mb-4 ${themeConfig.textSecondary}`}>
                Simulated In-App Purchase: Lerza Player Pro (Ad-Free Lifetime License)
              </p>
              <div className={`p-3 rounded-xl mb-4 text-xs space-y-1 ${themeConfig.isDark ? 'bg-neutral-900' : 'bg-slate-100'}`}>
                <div className={`flex justify-between font-semibold ${themeConfig.textPrimary}`}>
                  <span>Product:</span>
                  <span>lerza_player_remove_ads_lifetime</span>
                </div>
                <div className={`flex justify-between ${themeConfig.textSecondary}`}>
                  <span>Price:</span>
                  <span>$1.99 USD</span>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowPurchaseDialog(false)}
                  className={`px-3 py-1.5 rounded-xl text-xs ${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`}
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    onUpdateSettings({ isAdsRemoved: !settings.isAdsRemoved });
                    setShowPurchaseDialog(false);
                  }}
                  className={`px-4 py-1.5 rounded-xl text-xs font-bold ${themeConfig.accentBg}`}
                >
                  {settings.isAdsRemoved ? 'Re-enable Ads (Test)' : 'Confirm Purchase'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Clear Demo Tracks Confirm Modal */}
        {showClearConfirm && (
          <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
            <div className={`border border-rose-500/30 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-3 ${themeConfig.modalBg}`}>
              <h4 className={`text-sm font-bold ${themeConfig.textPrimary}`}>Clear Pre-loaded Demo Tracks?</h4>
              <p className={`text-xs ${themeConfig.textSecondary}`}>
                This will remove the sample songs so only your real imported device songs and videos remain.
              </p>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className={`px-3 py-1.5 rounded-xl text-xs ${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`}
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    onClearDemoTracks();
                    setShowClearConfirm(false);
                  }}
                  className="px-4 py-1.5 rounded-xl text-xs font-bold bg-rose-500 hover:bg-rose-600 text-white"
                >
                  Clear Demo Files
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
