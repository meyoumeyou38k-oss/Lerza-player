import React from 'react';
import { ShieldCheck, Music2, Video, CheckCircle2, FolderSearch } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface PermissionModalProps {
  isOpen: boolean;
  onGrantPermission: () => void;
  onDismiss: () => void;
}

export const PermissionModal: React.FC<PermissionModalProps> = ({
  isOpen,
  onGrantPermission,
  onDismiss
}) => {
  const { config: themeConfig } = useTheme();

  if (!isOpen) return null;

  return (
    <div className={`fixed inset-0 z-70 ${themeConfig.isDark ? 'bg-black/85' : 'bg-black/50'} backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn`}>
      <div className={`w-full max-w-sm ${themeConfig.modalBg} border ${themeConfig.modalBorder} rounded-3xl p-5 shadow-2xl space-y-4`}>
        {/* Android 14 System Permission Header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 text-cyan-500 mx-auto flex items-center justify-center ring-4 ring-cyan-500/10">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <span className="text-[10px] font-mono tracking-widest uppercase text-cyan-500 font-bold bg-cyan-500/10 px-2.5 py-0.5 rounded-full">
              Android Media Permissions
            </span>
            <h3 className={`text-base font-bold ${themeConfig.textPrimary} mt-1.5`}>
              Allow Lerza Player to access media?
            </h3>
            <p className={`text-xs ${themeConfig.textSecondary} mt-1`}>
              Lerza Player requires offline device storage permissions to scan and play your music & video files.
            </p>
          </div>
        </div>

        {/* Permission breakdown cards */}
        <div className="space-y-2 text-xs">
          <div className={`flex items-center gap-3 p-2.5 rounded-xl ${themeConfig.cardBg} border ${themeConfig.cardBorder}`}>
            <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-500 flex items-center justify-center shrink-0">
              <Music2 className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <h4 className={`font-semibold ${themeConfig.textPrimary}`}>Music & Audio (`READ_MEDIA_AUDIO`)</h4>
              <p className={`text-[11px] ${themeConfig.textSecondary}`}>Scans local MP3, FLAC, WAV & AAC tracks</p>
            </div>
            <CheckCircle2 className="w-4 h-4 text-cyan-500 shrink-0" />
          </div>

          <div className={`flex items-center gap-3 p-2.5 rounded-xl ${themeConfig.cardBg} border ${themeConfig.cardBorder}`}>
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-500 flex items-center justify-center shrink-0">
              <Video className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <h4 className={`font-semibold ${themeConfig.textPrimary}`}>Videos & MV (`READ_MEDIA_VIDEO`)</h4>
              <p className={`text-[11px] ${themeConfig.textSecondary}`}>Scans MP4, MKV & video clips</p>
            </div>
            <CheckCircle2 className="w-4 h-4 text-cyan-500 shrink-0" />
          </div>
        </div>

        {/* Smart Filter note */}
        <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-500">
          <strong>Smart Music Filter Active:</strong> WhatsApp voice notes, PTT audios, and phone call recordings will be automatically filtered out.
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-1">
          <button
            onClick={onGrantPermission}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-400 text-neutral-950 font-bold text-xs shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 hover:opacity-95 active:scale-98 transition"
          >
            <FolderSearch className="w-4 h-4" />
            <span>Allow & Scan Device Media</span>
          </button>

          <button
            onClick={onDismiss}
            className={`w-full py-2 px-4 rounded-xl text-xs font-semibold ${themeConfig.textSecondary} hover:${themeConfig.textPrimary} transition`}
          >
            Use Demo Files For Now
          </button>
        </div>
      </div>
    </div>
  );
};
