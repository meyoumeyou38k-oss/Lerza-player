import React, { useEffect, useRef } from 'react';
import { LyricLine } from '../types';
import { FileText, X } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface LyricsModalProps {
  title: string;
  artist: string;
  lyrics?: LyricLine[];
  currentTime: number;
  onSeek: (time: number) => void;
  onClose: () => void;
}

export const LyricsModal: React.FC<LyricsModalProps> = ({
  title,
  artist,
  lyrics,
  currentTime,
  onSeek,
  onClose
}) => {
  const { config: themeConfig } = useTheme();
  const activeLineRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to active lyric line
  useEffect(() => {
    if (activeLineRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [currentTime]);

  const hasLyrics = lyrics && lyrics.length > 0;

  // Determine which lyric is currently active
  let currentActiveIndex = -1;
  if (hasLyrics) {
    for (let i = 0; i < lyrics.length; i++) {
      if (currentTime >= lyrics[i].time) {
        currentActiveIndex = i;
      } else {
        break;
      }
    }
  }

  return (
    <div className={`fixed inset-0 z-50 ${themeConfig.isDark ? 'bg-black/90' : 'bg-slate-900/80'} backdrop-blur-xl flex flex-col justify-between p-5 animate-fadeIn`}>
      {/* Header */}
      <div className={`flex items-center justify-between pb-3 border-b ${themeConfig.cardBorder} max-w-lg w-full mx-auto`}>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white truncate">{title}</h3>
          </div>
          <p className="text-xs text-neutral-300 truncate">{artist}</p>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-full hover:bg-white/10 text-neutral-300 hover:text-white transition"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Lyrics Body */}
      <div className="flex-1 overflow-y-auto py-8 text-center max-w-md mx-auto w-full space-y-6 no-scrollbar">
        {hasLyrics ? (
          lyrics.map((line, idx) => {
            const isActive = idx === currentActiveIndex;
            return (
              <div
                key={idx}
                ref={isActive ? activeLineRef : null}
                onClick={() => onSeek(line.time)}
                className={`cursor-pointer transition-all duration-300 py-1.5 px-3 rounded-xl ${
                  isActive
                    ? 'text-lg sm:text-xl font-extrabold text-cyan-300 scale-105 bg-cyan-500/20'
                    : 'text-sm sm:text-base font-medium text-neutral-300 hover:text-white'
                }`}
              >
                {line.text}
              </div>
            );
          })
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-neutral-400">
            <FileText className="w-12 h-12 text-neutral-500 mb-3" />
            <h4 className="text-base font-semibold text-neutral-200">
              Lyrics not available
            </h4>
            <p className="text-xs text-neutral-400 mt-1 max-w-xs">
              No synchronized .lrc or embedded lyrics were found in this media file's tags.
            </p>
          </div>
        )}
      </div>

      {/* Footer info */}
      <div className="pt-3 border-t border-white/10 text-center text-[11px] text-neutral-400 max-w-lg mx-auto w-full">
        Tap any line to jump to that moment in playback
      </div>
    </div>
  );
};
