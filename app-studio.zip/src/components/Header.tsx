import React, { useRef } from 'react';
import { 
  Search, 
  Settings, 
  X,
  ArrowLeft
} from 'lucide-react';
import { MediaTrack } from '../types';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenEqualizer?: () => void;
  onSearchChange: (query: string) => void;
  searchQuery: string;
  isSearchOpen: boolean;
  onToggleSearch: (open?: boolean) => void;
  onCloseSearchAndGoHome?: () => void;
  isOnline: boolean;
  onToggleOnline: () => void;
  onFilesImported: (newTracks: MediaTrack[]) => void;
  totalTracksCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSettings,
  onSearchChange,
  searchQuery,
  isSearchOpen,
  onToggleSearch,
  onCloseSearchAndGoHome,
  totalTracksCount
}) => {
  const searchInputRef = useRef<HTMLInputElement>(null);

  const handleCloseSearch = () => {
    onToggleSearch(false);
    onSearchChange('');
    if (onCloseSearchAndGoHome) {
      onCloseSearchAndGoHome();
    }
  };

  return (
    <header className="w-full px-4 pt-3 pb-2.5 select-none bg-white text-slate-900 border-b border-slate-200/90 shadow-xs z-30 transition-none">
      <div className="flex items-center justify-between gap-2 max-w-6xl mx-auto">

        {/* Brand Identity with User-Provided Cutout Logo */}
        <div className="flex items-center gap-2.5">
          <div className="relative w-9 h-9 sm:w-10 sm:h-10 shrink-0 flex items-center justify-center">
            <img 
              src="/app-logo.png?v=2" 
              alt="Lerza Player" 
              className="w-full h-full object-contain select-none rounded-xl shadow-xs"
              referrerPolicy="no-referrer"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                if (!target.src.includes('/app-icon.png')) {
                  target.src = '/app-icon.png?v=2';
                }
              }}
            />
          </div>
          <div className="flex items-center gap-2">
            <h1 className="text-base sm:text-lg font-black tracking-wider text-slate-900 whitespace-nowrap">
              LERZA PLAYER
            </h1>
            <span className="text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-sky-50 text-sky-700 border border-sky-200 font-extrabold">
              PRO
            </span>
          </div>
        </div>

        {/* Action Controls (Plus folder icon moved to Settings menu per requirements) */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Search Toggle */}
          <button
            onClick={() => {
              const next = !isSearchOpen;
              onToggleSearch(next);
              if (!next && searchQuery) {
                onSearchChange('');
              } else if (next) {
                setTimeout(() => searchInputRef.current?.focus(), 50);
              }
            }}
            title="Search Media"
            className={`p-2 rounded-xl transition cursor-pointer ${
              isSearchOpen 
                ? 'bg-sky-500 text-white shadow-xs' 
                : 'text-slate-700 hover:text-slate-950 hover:bg-slate-100 active:scale-95'
            }`}
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            title="Lerza Player Settings & Preferences"
            className="p-2 rounded-xl text-slate-700 hover:text-slate-950 hover:bg-slate-100 active:scale-95 transition cursor-pointer"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Expandable Search Input (Collapsible by back button) */}
      {isSearchOpen && (
        <div className="mt-2.5 max-w-6xl mx-auto animate-fadeIn">
          <div className="relative flex items-center gap-2">
            <button
              onClick={handleCloseSearch}
              className="p-2 rounded-xl text-slate-600 hover:text-slate-950 hover:bg-slate-100 active:scale-95 transition shrink-0 cursor-pointer"
              title="Close Search & Go to Home"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="relative flex-1 flex items-center">
              <Search className="w-4 h-4 absolute left-3 text-slate-400" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') {
                    handleCloseSearch();
                  }
                }}
                placeholder="Search songs, videos, artists, folders..."
                autoFocus
                className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-8 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500/40 focus:border-sky-500"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-2.5 text-xs text-slate-500 hover:text-slate-800 bg-slate-200 rounded-full w-5 h-5 flex items-center justify-center cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
