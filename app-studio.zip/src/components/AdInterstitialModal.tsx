import React from 'react';

interface AdInterstitialModalProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export const AdInterstitialModal: React.FC<AdInterstitialModalProps> = () => {
  // All advertisements completely removed per user instructions
  return null;
};
