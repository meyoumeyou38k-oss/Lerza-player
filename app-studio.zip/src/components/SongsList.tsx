import React, { useState, useRef, useEffect } from 'react';
import { MediaTrack } from '../types';
import { generateVinylAlbumArt } from '../utils/artworkExtractor';
import { 
  Play, 
  Heart, 
  MoreVertical, 
  Video, 
  ListPlus, 
  ArrowUpDown, 
  PlusCircle, 
  Trash2,
  Music2,
  CheckSquare,
  Square,
  X,
  Check,
  EyeOff
} from 'lucide-react';
import { AdNative } from './AdNative';
import { useTheme } from '../context/ThemeContext';

interface SongsListProps {
  songs: MediaTrack[];
  currentTrack: MediaTrack | null;
  isPlaying: boolean;
  onSelectTrack: (track: MediaTrack, currentList?: MediaTrack[]) => void;
  onTogglePlay?: () => void;
  onToggleFavorite: (trackId: string) => void;
  onAddToQueue: (track: MediaTrack) => void;
  onPlayNext: (track: MediaTrack) => void;
  onAddToPlaylistClick: (track: MediaTrack) => void;
  onDeleteTrack: (trackId: string) => void;
  onDeleteMultipleTracks: (trackIds: string[]) => void;
  onHideTracks?: (trackIds: string[]) => void;
  isOnline: boolean;
  isAdsRemoved: boolean;
}

type SortField = 'name' | 'artist' | 'duration' | 'date' | 'plays';

export const SongsList: React.FC<SongsListProps> = ({
  songs,
  currentTrack,
  isPlaying,
  onSelectTrack,
  onTogglePlay,
  onToggleFavorite,
  onAddToQueue,
  onPlayNext,
  onAddToPlaylistClick,
  onDeleteTrack,
  onDeleteMultipleTracks,
  onHideTracks,
  isOnline,
  isAdsRemoved
}) => {
  const { config: themeConfig } = useTheme();
  const [sortField, setSortField] = useState<SortField>('date');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  
  // Multi-selection state
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [trackToDelete, setTrackToDelete] = useState<MediaTrack | null>(null);
  const [showBatchDeleteConfirm, setShowBatchDeleteConfirm] = useState(false);

  // Long press tracking refs
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);
  const touchStartPos = useRef<{ x: number; y: number } | null>(null);
  const isScrolling = useRef<boolean>(false);

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Progressive chunked rendering for instant startup and low memory usage
  const [renderLimit, setRenderLimit] = useState(35);
  const loadMoreSentinelRef = useRef<HTMLDivElement | null>(null);

  // Reset pagination when list or sort changes
  useEffect(() => {
    setRenderLimit(35);
  }, [songs.length, sortField]);

  // Infinite scroll trigger sentinel
  useEffect(() => {
    if (!loadMoreSentinelRef.current) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        setRenderLimit(prev => Math.min(prev + 35, songs.length));
      }
    }, { rootMargin: '350px' });

    observer.observe(loadMoreSentinelRef.current);
    return () => observer.disconnect();
  }, [songs.length, renderLimit]);

  const sortedSongs = [...songs].sort((a, b) => {
    if (sortField === 'name') return a.title.localeCompare(b.title);
    if (sortField === 'artist') return a.artist.localeCompare(b.artist);
    if (sortField === 'duration') return b.duration - a.duration;
    if (sortField === 'plays') return b.playCount - a.playCount;
    return b.dateAdded - a.dateAdded; // default date
  });

  const handleTouchStart = (e: React.TouchEvent, track: MediaTrack) => {
    if (isSelectionMode) return;
    const touch = e.touches[0];
    touchStartPos.current = { x: touch.clientX, y: touch.clientY };
    isScrolling.current = false;

    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }

    longPressTimer.current = setTimeout(() => {
      if (!isScrolling.current) {
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          try { navigator.vibrate(35); } catch (_) {}
        }
        setIsSelectionMode(true);
        setSelectedIds(new Set([track.id]));
      }
    }, 650);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStartPos.current) return;
    const touch = e.touches[0];
    const dx = Math.abs(touch.clientX - touchStartPos.current.x);
    const dy = Math.abs(touch.clientY - touchStartPos.current.y);
    
    // If movement exceeds 8px in either direction, user is scrolling! Cancel long-press immediately.
    if (dx > 8 || dy > 8) {
      isScrolling.current = true;
      handleEndLongPress();
    }
  };

  const handleTouchEnd = () => {
    handleEndLongPress();
    touchStartPos.current = null;
    isScrolling.current = false;
  };

  const handleEndLongPress = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const toggleSelectTrack = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
      if (newSet.size === 0) {
        setIsSelectionMode(false);
      }
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
  };

  const handleSelectAll = () => {
    if (selectedIds.size === sortedSongs.length) {
      setSelectedIds(new Set());
      setIsSelectionMode(false);
    } else {
      setSelectedIds(new Set(sortedSongs.map(s => s.id)));
    }
  };

  const handleConfirmBatchDelete = () => {
    onDeleteMultipleTracks(Array.from(selectedIds));
    setSelectedIds(new Set());
    setIsSelectionMode(false);
    setShowBatchDeleteConfirm(false);
  };

  return (
    <div className="px-4 py-3 max-w-6xl mx-auto pb-28">
      {/* Sticky Selection Top Action Bar */}
      {isSelectionMode ? (
        <div className={`sticky top-2 z-30 mb-3 ${
          themeConfig.isDark ? 'bg-[#121520] border-cyan-500/40 text-white' : 'bg-white border-slate-300 text-slate-900 shadow-md'
        } border rounded-2xl p-3 shadow-xl flex items-center justify-between animate-fadeIn`}>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setIsSelectionMode(false);
                setSelectedIds(new Set());
              }}
              className={`p-1 ${themeConfig.textMuted} hover:${themeConfig.textPrimary} rounded-lg ${themeConfig.isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'}`}
            >
              <X className="w-5 h-5" />
            </button>
            <span className={`text-xs font-bold ${themeConfig.textPrimary}`}>
              {selectedIds.size} Selected
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSelectAll}
              className={`text-xs font-semibold px-2.5 py-1 rounded-lg ${
                themeConfig.isDark ? 'bg-neutral-800 text-neutral-300 hover:text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              } transition`}
            >
              {selectedIds.size === sortedSongs.length ? 'Deselect All' : 'Select All'}
            </button>

            {selectedIds.size > 0 && onHideTracks && (
              <button
                onClick={() => {
                  onHideTracks(Array.from(selectedIds));
                  setSelectedIds(new Set());
                  setIsSelectionMode(false);
                }}
                className="flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500 hover:text-neutral-950 transition"
                title="Hide selected tracks in Private Vault"
              >
                <EyeOff className="w-3.5 h-3.5" />
                <span>Hide ({selectedIds.size})</span>
              </button>
            )}

            {selectedIds.size > 0 && (
              <button
                onClick={() => setShowBatchDeleteConfirm(true)}
                className="flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-lg bg-rose-500/20 text-rose-500 border border-rose-500/30 hover:bg-rose-500 hover:text-white transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete ({selectedIds.size})</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        /* Normal Controls Bar: Count & Sort */
        <div className="flex items-center justify-between mb-3">
          <span className={`text-xs font-semibold ${themeConfig.textMuted}`}>
            {sortedSongs.length} Songs Available
          </span>

          <div className={`flex items-center gap-1.5 ${themeConfig.cardBg} border ${themeConfig.cardBorder} rounded-xl px-2.5 py-1 text-xs ${themeConfig.textSecondary}`}>
            <ArrowUpDown className={`w-3.5 h-3.5 ${themeConfig.accentText}`} />
            <span className={`${themeConfig.textMuted} font-medium`}>Sort:</span>
            <select
              value={sortField}
              onChange={(e) => setSortField(e.target.value as SortField)}
              className={`bg-transparent text-xs font-semibold ${themeConfig.accentText} focus:outline-none cursor-pointer`}
            >
              <option value="date" className={themeConfig.isDark ? 'bg-neutral-900 text-white' : 'bg-white text-slate-900'}>Date Added</option>
              <option value="name" className={themeConfig.isDark ? 'bg-neutral-900 text-white' : 'bg-white text-slate-900'}>Title (A-Z)</option>
              <option value="artist" className={themeConfig.isDark ? 'bg-neutral-900 text-white' : 'bg-white text-slate-900'}>Artist</option>
              <option value="duration" className={themeConfig.isDark ? 'bg-neutral-900 text-white' : 'bg-white text-slate-900'}>Duration</option>
              <option value="plays" className={themeConfig.isDark ? 'bg-neutral-900 text-white' : 'bg-white text-slate-900'}>Most Played</option>
            </select>
          </div>
        </div>
      )}

      {/* Song List - Clean Joined List without liquid glass blur */}
      <div className="divide-y divide-black/5 dark:divide-white/5 bg-transparent rounded-2xl overflow-hidden select-none">
        {sortedSongs.slice(0, renderLimit).map((track, index) => {
          const isCurrent = currentTrack?.id === track.id;
          const isSelected = selectedIds.has(track.id);

          return (
            <React.Fragment key={track.id}>
              {/* Native Ad insertion every 13 songs (every 12-15 songs per user request) */}
              {(index + 1) % 13 === 0 && (index + 1) < sortedSongs.length && (
                <div className="p-2 bg-neutral-100 dark:bg-neutral-900 border-y border-neutral-200/50 dark:border-white/10">
                  <AdNative isOnline={isOnline} isAdsRemoved={isAdsRemoved} />
                </div>
              )}

              <div
                onMouseDown={() => {
                  if (isSelectionMode) return;
                  if (longPressTimer.current) clearTimeout(longPressTimer.current);
                  longPressTimer.current = setTimeout(() => {
                    setIsSelectionMode(true);
                    setSelectedIds(new Set([track.id]));
                  }, 650);
                }}
                onMouseUp={handleEndLongPress}
                onMouseLeave={handleEndLongPress}
                onTouchStart={(e) => handleTouchStart(e, track)}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
                onTouchCancel={handleTouchEnd}
                onContextMenu={(e) => {
                  if (!isSelectionMode) {
                    e.preventDefault();
                  }
                }}
                className={`group w-full flex items-center justify-between py-2.5 sm:py-3 px-3.5 sm:px-4 transition-colors select-none ${
                  isSelected
                    ? 'bg-blue-600/20'
                    : isCurrent
                    ? 'bg-blue-500/10 dark:bg-blue-500/15'
                    : 'hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 dark:active:bg-white/10'
                }`}
              >
                {/* Checkbox in selection mode */}
                {isSelectionMode && (
                  <button
                    onClick={() => toggleSelectTrack(track.id)}
                    className="p-1 mr-2 text-cyan-400 shrink-0"
                  >
                    {isSelected ? (
                      <CheckSquare className="w-5 h-5 text-blue-600 fill-blue-600/20" />
                    ) : (
                      <Square className={`w-5 h-5 ${themeConfig.textMuted}`} />
                    )}
                  </button>
                )}

                {/* Left & Middle: Artwork & Full-Width Details */}
                <div
                  onClick={() => {
                    if (isSelectionMode) {
                      toggleSelectTrack(track.id);
                    } else {
                      onSelectTrack(track, sortedSongs);
                    }
                  }}
                  className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer pr-1"
                >
                  <div className={`relative w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden shrink-0 ${
                    themeConfig.isDark ? 'bg-neutral-800' : 'bg-slate-200'
                  } shadow-sm`}>
                    <img
                      src={track.artworkUrl}
                      alt={track.title}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = generateVinylAlbumArt(track.title, track.artist);
                      }}
                    />
                    {isCurrent && isPlaying ? (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <div className="flex items-end gap-[3px] h-4">
                          <span className="w-1 bg-white animate-bounce rounded-full" style={{ height: '70%', animationDuration: '0.6s' }}></span>
                          <span className="w-1 bg-white animate-bounce rounded-full" style={{ height: '100%', animationDuration: '0.8s', animationDelay: '0.15s' }}></span>
                          <span className="w-1 bg-white animate-bounce rounded-full" style={{ height: '80%', animationDuration: '0.7s', animationDelay: '0.3s' }}></span>
                        </div>
                      </div>
                    ) : (
                      !isSelectionMode && (
                        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                          <Play className="w-5 h-5 text-white fill-white" />
                        </div>
                      )
                    )}
                  </div>

                  {/* Text Container: Full width utilization, multi-line support, no cramping */}
                  <div className="min-w-0 flex-1 flex flex-col justify-center">
                    <div className="flex items-baseline gap-1.5 flex-wrap">
                      <h4 className={`text-[15px] sm:text-base font-bold leading-snug line-clamp-2 break-words ${
                        isCurrent && isPlaying
                          ? 'text-[#2563EB] dark:text-[#3B82F6] font-extrabold'
                          : themeConfig.textPrimary
                      }`}>
                        {track.title}
                      </h4>
                      {track.hasMV && (
                        <span className="shrink-0 inline-flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                          <Video className="w-2.5 h-2.5" /> MV
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 mt-0.5 flex-wrap min-w-0">
                      {/* Prominent LYRICS badge */}
                      <span className="border border-neutral-400/70 dark:border-neutral-500/70 text-[9px] font-extrabold px-1.5 py-0.5 rounded leading-none text-neutral-600 dark:text-neutral-300 shrink-0 inline-flex items-center tracking-wider">
                        LYRICS
                      </span>
                      <span className={`text-xs sm:text-sm font-medium leading-normal line-clamp-1 break-words ${themeConfig.textSecondary}`}>
                        {track.artist}{track.album && track.album !== 'Device Storage' ? ` • ${track.album}` : ''}
                      </span>
                      {track.fileFormat && (
                        <span className={`text-[9px] uppercase font-mono px-1 py-0.5 rounded shrink-0 ${
                          themeConfig.isDark ? 'bg-neutral-800/80 text-neutral-400' : 'bg-slate-200 text-slate-700'
                        }`}>
                          {track.fileFormat}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right: Favorite & Actions - Compacted to maximize title/artist width */}
                {!isSelectionMode && (
                  <div className="flex items-center gap-1 shrink-0 relative">
                    <button
                      onClick={() => onToggleFavorite(track.id)}
                      className={`p-2 ${themeConfig.textMuted} hover:text-rose-500 active:scale-95 transition`}
                      title={track.isFavorite ? "Remove from Favorites" : "Add to Favorites"}
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          track.isFavorite ? 'text-rose-500 fill-rose-500' : ''
                        }`}
                      />
                    </button>

                    <button
                      onClick={() => setActiveMenuId(activeMenuId === track.id ? null : track.id)}
                      className={`p-2 ${themeConfig.textMuted} hover:${themeConfig.textPrimary} rounded-lg ${
                        themeConfig.isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'
                      } active:scale-95 transition`}
                      title="More options"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {/* Dropdown Menu */}
                    {activeMenuId === track.id && (
                      <>
                        {/* Outside click backdrop to dismiss menu on tap anywhere */}
                        <div
                          className="fixed inset-0 z-20 cursor-default"
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveMenuId(null);
                          }}
                          onTouchStart={(e) => {
                            e.stopPropagation();
                            setActiveMenuId(null);
                          }}
                        />
                        <div className={`absolute right-0 top-10 w-44 ${themeConfig.modalBg} border ${themeConfig.modalBorder} rounded-xl shadow-2xl py-1.5 z-30 backdrop-blur-md animate-fadeIn`}>
                          <button
                            onClick={() => {
                              onPlayNext(track);
                              setActiveMenuId(null);
                            }}
                            className={`w-full text-left px-3.5 py-2 text-xs ${themeConfig.textPrimary} hover:${themeConfig.isDark ? 'bg-white/10' : 'bg-slate-100'} hover:${themeConfig.accentText} flex items-center gap-2`}
                          >
                            <Play className="w-3.5 h-3.5" /> Play Next
                          </button>
                          <button
                            onClick={() => {
                              onAddToQueue(track);
                              setActiveMenuId(null);
                            }}
                            className={`w-full text-left px-3.5 py-2 text-xs ${themeConfig.textPrimary} hover:${themeConfig.isDark ? 'bg-white/10' : 'bg-slate-100'} hover:${themeConfig.accentText} flex items-center gap-2`}
                          >
                            <ListPlus className="w-3.5 h-3.5" /> Add to Queue
                          </button>
                          <button
                            onClick={() => {
                              onAddToPlaylistClick(track);
                              setActiveMenuId(null);
                            }}
                            className={`w-full text-left px-3.5 py-2 text-xs ${themeConfig.textPrimary} hover:${themeConfig.isDark ? 'bg-white/10' : 'bg-slate-100'} hover:${themeConfig.accentText} flex items-center gap-2`}
                          >
                            <PlusCircle className="w-3.5 h-3.5" /> Add to Playlist
                          </button>
                          {onHideTracks && (
                            <button
                              onClick={() => {
                                onHideTracks([track.id]);
                                setActiveMenuId(null);
                              }}
                              className={`w-full text-left px-3.5 py-2 text-xs ${themeConfig.textPrimary} hover:${themeConfig.isDark ? 'bg-white/10' : 'bg-slate-100'} hover:text-cyan-400 flex items-center gap-2`}
                            >
                              <EyeOff className="w-3.5 h-3.5" /> Hide in Vault
                            </button>
                          )}
                          <div className={`my-1 border-t ${themeConfig.modalBorder}`} />
                          <button
                            onClick={() => {
                              setTrackToDelete(track);
                              setActiveMenuId(null);
                            }}
                            className="w-full text-left px-3.5 py-2 text-xs text-rose-500 hover:bg-rose-500/10 flex items-center gap-2"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> Delete from Library
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            </React.Fragment>
          );
        })}

        {/* Lazy Loading Sentinel & Load More button */}
        {renderLimit < sortedSongs.length && (
          <div ref={loadMoreSentinelRef} className="py-3 text-center">
            <button
              onClick={() => setRenderLimit(prev => Math.min(prev + 35, sortedSongs.length))}
              className={`px-4 py-2 rounded-xl text-xs font-bold ${
                themeConfig.isDark ? 'bg-white/10 text-neutral-300 hover:bg-white/15' : 'bg-black/5 text-neutral-700 hover:bg-black/10'
              } transition active:scale-95`}
            >
              Load more ({sortedSongs.length - renderLimit} remaining)
            </button>
          </div>
        )}

        {sortedSongs.length === 0 && (
          <div className={`text-center py-12 ${themeConfig.textSecondary}`}>
            <Music2 className={`w-12 h-12 mx-auto mb-3 ${themeConfig.textMuted}`} />
            <h4 className={`text-sm font-semibold ${themeConfig.textPrimary}`}>No songs found</h4>
            <p className={`text-xs ${themeConfig.textMuted} mt-1 max-w-xs mx-auto`}>
              Tap below to scan your device storage and load all downloaded songs.
            </p>
            <button
              type="button"
              onClick={() => {
                if ((window as any).AndroidBridge?.scanLocalAudio) {
                  try {
                    (window as any).AndroidBridge.scanLocalAudio();
                  } catch (e) {
                    console.warn(e);
                  }
                }
                const input = document.querySelector('input[type="file"][accept*="audio"]') as HTMLInputElement;
                input?.click();
              }}
              className="mt-4 px-4 py-2 rounded-xl text-xs font-black bg-cyan-500 hover:bg-cyan-400 text-neutral-950 transition active:scale-95 shadow-md shadow-cyan-500/20 cursor-pointer"
            >
              Scan & Load Device Songs
            </button>
          </div>
        )}
      </div>

      {/* Single Item Delete Confirmation Dialog */}
      {trackToDelete && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className={`${themeConfig.modalBg} border border-rose-500/30 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-3`}>
            <h4 className={`text-sm font-bold ${themeConfig.textPrimary}`}>Delete Music File?</h4>
            <p className={`text-xs ${themeConfig.textSecondary}`}>
              Are you sure you want to remove <strong className={themeConfig.textPrimary}>"{trackToDelete.title}"</strong> from your Lerza Player library?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setTrackToDelete(null)}
                className={`px-3 py-1.5 rounded-xl text-xs ${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`}
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteTrack(trackToDelete.id);
                  setTrackToDelete(null);
                }}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-rose-500 hover:bg-rose-600 text-white shadow-lg shadow-rose-500/20"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Batch Delete Confirmation Dialog */}
      {showBatchDeleteConfirm && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className={`${themeConfig.modalBg} border border-rose-500/30 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-3`}>
            <h4 className={`text-sm font-bold ${themeConfig.textPrimary}`}>Delete {selectedIds.size} Tracks?</h4>
            <p className={`text-xs ${themeConfig.textSecondary}`}>
              Are you sure you want to delete these {selectedIds.size} selected tracks from your Lerza Player library?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowBatchDeleteConfirm(false)}
                className={`px-3 py-1.5 rounded-xl text-xs ${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`}
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmBatchDelete}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-rose-500 hover:bg-rose-600 text-white shadow-lg shadow-rose-500/20"
              >
                Delete Selected
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
