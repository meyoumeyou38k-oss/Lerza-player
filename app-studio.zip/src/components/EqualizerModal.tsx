import React from 'react';
import { Sliders, X, Sparkles, Volume2 } from 'lucide-react';
import { EQUALIZER_PRESETS } from '../data/sampleMedia';
import { EqualizerPresetName } from '../types';
import { useTheme } from '../context/ThemeContext';

interface EqualizerModalProps {
  bandGains: number[];
  bassBoost: number;
  virtualizer: boolean;
  activePreset: string;
  onBandChange: (bandIndex: number, gain: number) => void;
  onBassBoostChange: (level: number) => void;
  onVirtualizerToggle: () => void;
  onSelectPreset: (preset: string) => void;
  onReset: () => void;
  onClose: () => void;
}

export const EqualizerModal: React.FC<EqualizerModalProps> = ({
  bandGains,
  bassBoost,
  virtualizer,
  activePreset,
  onBandChange,
  onBassBoostChange,
  onVirtualizerToggle,
  onSelectPreset,
  onReset,
  onClose
}) => {
  const { config: themeConfig } = useTheme();

  const bands = [
    { label: '60 Hz', sub: 'Sub-Bass' },
    { label: '230 Hz', sub: 'Bass' },
    { label: '910 Hz', sub: 'Mid' },
    { label: '3.6 kHz', sub: 'Upper-Mid' },
    { label: '14 kHz', sub: 'Treble' }
  ];

  const presets = Object.keys(EQUALIZER_PRESETS) as EqualizerPresetName[];

  return (
    <div className={`fixed inset-0 z-50 ${themeConfig.isDark ? 'bg-black/80' : 'bg-black/50'} backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn`}>
      <div className={`w-full max-w-md ${themeConfig.modalBg} border ${themeConfig.modalBorder} rounded-3xl p-5 shadow-2xl`}>
        {/* Header */}
        <div className={`flex items-center justify-between pb-3 border-b ${themeConfig.cardBorder} mb-4`}>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-500 flex items-center justify-center">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h3 className={`text-sm font-bold ${themeConfig.textPrimary}`}>5-Band Equalizer</h3>
              <p className={`text-[11px] ${themeConfig.textSecondary}`}>Web Audio API Hardware Filters</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onReset}
              className={`text-xs ${themeConfig.textSecondary} hover:${themeConfig.accentText} px-2 py-1 rounded transition`}
            >
              Reset
            </button>
            <button
              onClick={onClose}
              className={`p-1.5 rounded-full ${themeConfig.textSecondary} hover:${themeConfig.textPrimary} transition`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Preset Chips */}
        <div className="mb-6">
          <label className={`block text-[11px] font-semibold uppercase tracking-wider ${themeConfig.textSecondary} mb-2`}>
            Sound Presets
          </label>
          <div className="flex flex-wrap gap-1.5">
            {presets.map(preset => {
              const isActive = activePreset === preset;
              return (
                <button
                  key={preset}
                  onClick={() => onSelectPreset(preset)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold capitalize transition ${
                    isActive
                      ? `${themeConfig.accentBg} font-bold shadow-md`
                      : `${themeConfig.cardBg} ${themeConfig.textSecondary} border ${themeConfig.cardBorder} hover:${themeConfig.textPrimary}`
                  }`}
                >
                  {preset.replace('_', ' ')}
                </button>
              );
            })}
          </div>
        </div>

        {/* Sliders for 5 Frequencies */}
        <div className={`${themeConfig.cardBg} border ${themeConfig.cardBorder} rounded-2xl p-4 mb-5`}>
          <div className="flex justify-between items-center h-44 px-2">
            {bands.map((band, idx) => {
              const gain = bandGains[idx] || 0;

              return (
                <div key={band.label} className="flex flex-col items-center h-full justify-between w-12">
                  <span className={`text-[10px] font-mono ${themeConfig.accentText} font-bold`}>
                    {gain > 0 ? `+${gain}` : gain}dB
                  </span>

                  {/* Vertical Range Slider */}
                  <div className="relative h-28 flex items-center justify-center">
                    <input
                      type="range"
                      min="-12"
                      max="12"
                      step="1"
                      value={gain}
                      onChange={(e) => onBandChange(idx, parseFloat(e.target.value))}
                      className={`h-28 w-1.5 ${themeConfig.isDark ? 'bg-neutral-800' : 'bg-slate-200'} rounded-lg appearance-none cursor-pointer accent-cyan-500 focus:outline-none [writing-mode:vertical-lr] [direction:rtl]`}
                    />
                  </div>

                  <div className="text-center">
                    <span className={`block text-[11px] font-bold ${themeConfig.textPrimary}`}>{band.label}</span>
                    <span className={`block text-[9px] ${themeConfig.textMuted}`}>{band.sub}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Audio Effects: Bass Boost & 3D Virtualizer */}
        <div className="space-y-4 pt-1">
          {/* Bass Boost Slider */}
          <div>
            <div className="flex items-center justify-between text-xs font-semibold mb-1.5">
              <span className={`${themeConfig.textPrimary} flex items-center gap-1.5`}>
                <Volume2 className={`w-3.5 h-3.5 ${themeConfig.accentText}`} /> Bass Boost
              </span>
              <span className={`${themeConfig.accentText} font-mono font-bold`}>{bassBoost}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={bassBoost}
              onChange={(e) => onBassBoostChange(parseInt(e.target.value))}
              className={`w-full h-1.5 ${themeConfig.isDark ? 'bg-neutral-800' : 'bg-slate-200'} rounded-lg appearance-none cursor-pointer accent-cyan-500`}
            />
          </div>

          {/* Virtualizer Toggle */}
          <div className="flex items-center justify-between py-1">
            <div>
              <h4 className={`text-xs font-semibold ${themeConfig.textPrimary}`}>Spatial 3D Virtualizer</h4>
              <p className={`text-[11px] ${themeConfig.textSecondary}`}>Expands stereo field width</p>
            </div>
            <button
              onClick={onVirtualizerToggle}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                virtualizer ? 'bg-cyan-500' : themeConfig.isDark ? 'bg-neutral-800' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  virtualizer ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
