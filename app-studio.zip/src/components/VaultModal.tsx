import React, { useState } from 'react';
import { Lock, Eye, EyeOff, Music, Video, Play, Trash2, KeyRound, ShieldCheck, X } from 'lucide-react';
import { MediaTrack, VaultConfig } from '../types';
import { useTheme } from '../context/ThemeContext';

const formatDuration = (sec: number) => {
  const mins = Math.floor(sec / 60);
  const secs = Math.floor(sec % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

interface VaultModalProps {
  isOpen: boolean;
  onClose: () => void;
  hiddenTracks: MediaTrack[];
  onUnhideTrack: (trackId: string) => void;
  onUnhideAll: () => void;
  onPlayTrack: (track: MediaTrack) => void;
  onChangeLock: () => void;
  vaultConfig: VaultConfig;
}

export const VaultModal: React.FC<VaultModalProps> = ({
  isOpen,
  onClose,
  hiddenTracks,
  onUnhideTrack,
  onUnhideAll,
  onPlayTrack,
  onChangeLock,
  vaultConfig
}) => {
  const { config: themeConfig } = useTheme();
  const [activeTab, setActiveTab] = useState<'all' | 'songs' | 'videos'>('all');

  if (!isOpen) return null;

  const hiddenSongs = hiddenTracks.filter(t => !t.isVideoOnly && !t.hasMV);
  const hiddenVideos = hiddenTracks.filter(t => t.isVideoOnly || t.hasMV);

  const displayedTracks = activeTab === 'songs'
    ? hiddenSongs
    : activeTab === 'videos'
    ? hiddenVideos
    : hiddenTracks;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className={`w-full max-w-xl h-[85vh] max-h-[720px] rounded-3xl ${themeConfig.modalBg} border ${themeConfig.modalBorder} shadow-2xl flex flex-col overflow-hidden`}>
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className={`text-lg font-black tracking-tight ${themeConfig.textPrimary}`}>
                  Private Vault
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {vaultConfig.lockType.toUpperCase()} Protected
                </span>
              </div>
              <p className={`text-xs ${themeConfig.textSecondary}`}>
                Hidden from media lists ({hiddenTracks.length} protected)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={onChangeLock}
              className="p-2 rounded-xl bg-neutral-900/60 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-white/5 text-xs font-semibold flex items-center gap-1.5 transition"
              title="Change PIN or Pattern"
            >
              <KeyRound className="w-4 h-4 text-cyan-400" />
              <span className="hidden sm:inline">Change Lock</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-neutral-800/80 text-neutral-400 hover:text-white transition"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="p-3 bg-black/20 border-b border-white/5 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'all'
                  ? 'bg-cyan-500 text-neutral-950 shadow-sm'
                  : `${themeConfig.textSecondary} hover:text-white`
              }`}
            >
              <span>All</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">
                {hiddenTracks.length}
              </span>
            </button>
            <button
              onClick={() => setActiveTab('songs')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'songs'
                  ? 'bg-cyan-500 text-neutral-950 shadow-sm'
                  : `${themeConfig.textSecondary} hover:text-white`
              }`}
            >
              <Music className="w-3.5 h-3.5" />
              <span>Songs</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">
                {hiddenSongs.length}
              </span>
            </button>
            <button
              onClick={() => setActiveTab('videos')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'videos'
                  ? 'bg-cyan-500 text-neutral-950 shadow-sm'
                  : `${themeConfig.textSecondary} hover:text-white`
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Videos</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">
                {hiddenVideos.length}
              </span>
            </button>
          </div>

          {hiddenTracks.length > 0 && (
            <button
              onClick={onUnhideAll}
              className="text-xs text-neutral-400 hover:text-cyan-400 font-semibold px-2 py-1 transition flex items-center gap-1"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Unhide All</span>
            </button>
          )}
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2">
          {displayedTracks.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8">
              <div className="w-16 h-16 rounded-full bg-neutral-900 border border-white/5 flex items-center justify-center text-neutral-500 mb-3">
                <EyeOff className="w-8 h-8" />
              </div>
              <h3 className={`text-base font-bold ${themeConfig.textPrimary}`}>
                No Hidden Items
              </h3>
              <p className={`text-xs max-w-xs mt-1 leading-relaxed ${themeConfig.textSecondary}`}>
                Files you hide from the player will safely appear here. System files remain in device storage.
              </p>
            </div>
          ) : (
            displayedTracks.map(track => {
              const isVid = track.isVideoOnly || track.hasMV;
              return (
                <div
                  key={track.id}
                  className="flex items-center gap-3 p-2.5 rounded-2xl bg-neutral-900/50 hover:bg-neutral-900/80 border border-white/5 transition group"
                >
                  {/* Artwork / Icon */}
                  <div
                    onClick={() => {
                      onPlayTrack(track);
                      onClose();
                    }}
                    className="relative w-12 h-12 rounded-xl bg-neutral-800 overflow-hidden shrink-0 cursor-pointer group-hover:ring-2 ring-cyan-500/50 transition"
                  >
                    {track.artworkUrl ? (
                      <img
                        src={track.artworkUrl}
                        alt=""
                        className="w-full h-full object-cover"
                        loading="lazy"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-neutral-500">
                        {isVid ? <Video className="w-5 h-5" /> : <Music className="w-5 h-5" />}
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                      <Play className="w-4 h-4 text-white fill-white" />
                    </div>
                  </div>

                  {/* Title and details */}
                  <div
                    onClick={() => {
                      onPlayTrack(track);
                      onClose();
                    }}
                    className="flex-1 min-w-0 cursor-pointer"
                  >
                    <h4 className={`text-sm font-semibold truncate ${themeConfig.textPrimary}`}>
                      {track.title}
                    </h4>
                    <div className="flex items-center gap-2 text-xs text-neutral-400 mt-0.5">
                      <span className="truncate max-w-[120px]">{track.artist || 'Unknown'}</span>
                      <span>•</span>
                      <span>{formatDuration(track.duration)}</span>
                      {track.fileFormat && (
                        <>
                          <span>•</span>
                          <span className="uppercase text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-300">
                            {track.fileFormat}
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => {
                        onPlayTrack(track);
                        onClose();
                      }}
                      className="p-2 rounded-xl hover:bg-cyan-500/20 text-neutral-400 hover:text-cyan-300 transition"
                      title="Play"
                    >
                      <Play className="w-4 h-4 fill-current" />
                    </button>
                    <button
                      onClick={() => onUnhideTrack(track.id)}
                      className="p-2 rounded-xl hover:bg-emerald-500/20 text-neutral-400 hover:text-emerald-400 transition flex items-center gap-1 text-xs font-semibold"
                      title="Unhide from Vault"
                    >
                      <Eye className="w-4 h-4" />
                      <span className="hidden sm:inline">Unhide</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Note */}
        <div className="p-3 bg-black/40 border-t border-white/5 text-center text-[11px] text-neutral-500 shrink-0">
          Only hidden within this media player. Original files on phone storage remain untouched.
        </div>
      </div>
    </div>
  );
};
