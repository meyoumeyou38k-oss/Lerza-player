import React from 'react';

interface AdNativeProps {
  isOnline?: boolean;
  isAdsRemoved?: boolean;
}

export const AdNative: React.FC<AdNativeProps> = () => {
  // All advertisements completely removed per user instructions
  return null;
};
