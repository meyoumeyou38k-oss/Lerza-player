import React from 'react';
import { CategoryTab } from '../types';
import { Video, Music, Folder, ListMusic, Disc3, Mic2 } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface CategoryChipsProps {
  activeTab: CategoryTab;
  onTabChange: (tab: CategoryTab) => void;
  counts: {
    videos: number;
    songs: number;
    playlists: number;
    folders: number;
    albums: number;
    artists: number;
  };
}

export const CategoryChips: React.FC<CategoryChipsProps> = ({
  activeTab,
  onTabChange,
  counts
}) => {
  const { config: themeConfig } = useTheme();

  // Primary navigation tabs in user's exact requested order:
  // 1. Videos (پہلا سیکشن)
  // 2. Songs (ویڈیو سیکشن کے بعد گانوں کا سیکشن)
  // 3. Playlists (پلے لسٹس)
  // 4. Folders (فولڈرز)
  const primaryTabs: { id: CategoryTab; label: string; icon: React.ReactNode; count: number }[] = [
    { id: 'videos', label: 'Videos', icon: <Video className="w-4 h-4" />, count: counts.videos },
    { id: 'songs', label: 'Songs', icon: <Music className="w-4 h-4" />, count: counts.songs },
    { id: 'playlists', label: 'Playlists', icon: <ListMusic className="w-4 h-4" />, count: counts.playlists },
    { id: 'folders', label: 'Folders', icon: <Folder className="w-4 h-4" />, count: counts.folders },
  ];

  const secondaryTabs: { id: CategoryTab; label: string; icon: React.ReactNode; count: number }[] = [
    { id: 'albums', label: 'Albums', icon: <Disc3 className="w-3.5 h-3.5" />, count: counts.albums },
    { id: 'artists', label: 'Artists', icon: <Mic2 className="w-3.5 h-3.5" />, count: counts.artists }
  ];

  return (
    <div className="w-full py-2.5 px-3 sm:px-4 transition-colors select-none">
      <div className="max-w-6xl mx-auto">
        {/* Horizontal Scrollable Pill Chips matching Lark Player Screenshot */}
        <div className="flex items-center gap-2.5 overflow-x-auto no-scrollbar py-1">
          {/* 1. Videos (User requested 1st tab) */}
          <button
            type="button"
            onClick={() => onTabChange('videos')}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 shrink-0 cursor-pointer active:scale-95 ${
              activeTab === 'videos'
                ? 'bg-[#2563EB] text-white shadow-md shadow-blue-500/20 font-bold'
                : `border border-neutral-400/60 dark:border-neutral-600/70 ${
                    themeConfig.isDark 
                      ? 'text-neutral-200 hover:bg-white/10 hover:text-white' 
                      : 'text-neutral-800 hover:bg-black/5 hover:text-neutral-950'
                  } bg-transparent`
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>Videos</span>
          </button>

          {/* 2. Songs (User requested 2nd tab) */}
          <button
            type="button"
            onClick={() => onTabChange('songs')}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 shrink-0 cursor-pointer active:scale-95 ${
              activeTab === 'songs'
                ? 'bg-[#2563EB] text-white shadow-md shadow-blue-500/20 font-bold'
                : `border border-neutral-400/60 dark:border-neutral-600/70 ${
                    themeConfig.isDark 
                      ? 'text-neutral-200 hover:bg-white/10 hover:text-white' 
                      : 'text-neutral-800 hover:bg-black/5 hover:text-neutral-950'
                  } bg-transparent`
            }`}
          >
            <span>Songs</span>
          </button>

          {/* 3. Playlists (User requested 3rd tab) */}
          <button
            type="button"
            onClick={() => onTabChange('playlists')}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 shrink-0 cursor-pointer active:scale-95 ${
              activeTab === 'playlists'
                ? 'bg-[#2563EB] text-white shadow-md shadow-blue-500/20 font-bold'
                : `border border-neutral-400/60 dark:border-neutral-600/70 ${
                    themeConfig.isDark 
                      ? 'text-neutral-200 hover:bg-white/10 hover:text-white' 
                      : 'text-neutral-800 hover:bg-black/5 hover:text-neutral-950'
                  } bg-transparent`
            }`}
          >
            <span>Playlists</span>
          </button>

          {/* 4. Folders (User requested 4th tab) */}
          <button
            type="button"
            onClick={() => onTabChange('folders')}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 shrink-0 cursor-pointer active:scale-95 ${
              activeTab === 'folders'
                ? 'bg-[#2563EB] text-white shadow-md shadow-blue-500/20 font-bold'
                : `border border-neutral-400/60 dark:border-neutral-600/70 ${
                    themeConfig.isDark 
                      ? 'text-neutral-200 hover:bg-white/10 hover:text-white' 
                      : 'text-neutral-800 hover:bg-black/5 hover:text-neutral-950'
                  } bg-transparent`
            }`}
          >
            <span>Folders</span>
          </button>

          {/* 5. Albums */}
          <button
            type="button"
            onClick={() => onTabChange('albums')}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 shrink-0 cursor-pointer active:scale-95 ${
              activeTab === 'albums'
                ? 'bg-[#2563EB] text-white shadow-md shadow-blue-500/20 font-bold'
                : `border border-neutral-400/60 dark:border-neutral-600/70 ${
                    themeConfig.isDark 
                      ? 'text-neutral-200 hover:bg-white/10 hover:text-white' 
                      : 'text-neutral-800 hover:bg-black/5 hover:text-neutral-950'
                  } bg-transparent`
            }`}
          >
            <span>Albums</span>
          </button>

          {/* 6. Artists */}
          <button
            type="button"
            onClick={() => onTabChange('artists')}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 shrink-0 cursor-pointer active:scale-95 ${
              activeTab === 'artists'
                ? 'bg-[#2563EB] text-white shadow-md shadow-blue-500/20 font-bold'
                : `border border-neutral-400/60 dark:border-neutral-600/70 ${
                    themeConfig.isDark 
                      ? 'text-neutral-200 hover:bg-white/10 hover:text-white' 
                      : 'text-neutral-800 hover:bg-black/5 hover:text-neutral-950'
                  } bg-transparent`
            }`}
          >
            <span>Artists</span>
          </button>
        </div>
      </div>
    </div>
  );
};
