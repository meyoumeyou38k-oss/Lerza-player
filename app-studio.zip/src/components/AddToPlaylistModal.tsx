import React from 'react';
import { Playlist, MediaTrack } from '../types';
import { ListPlus, X } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface AddToPlaylistModalProps {
  track: MediaTrack | null;
  playlists: Playlist[];
  onAddTrackToPlaylist: (playlistId: string, trackId: string) => void;
  onClose: () => void;
}

export const AddToPlaylistModal: React.FC<AddToPlaylistModalProps> = ({
  track,
  playlists,
  onAddTrackToPlaylist,
  onClose
}) => {
  const { config: themeConfig } = useTheme();

  if (!track) return null;

  return (
    <div className={`fixed inset-0 z-60 ${themeConfig.isDark ? 'bg-black/80' : 'bg-black/50'} backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn`}>
      <div className={`w-full max-w-sm ${themeConfig.modalBg} border ${themeConfig.modalBorder} rounded-2xl p-5 shadow-2xl`}>
        <div className={`flex items-center justify-between pb-3 border-b ${themeConfig.cardBorder} mb-3`}>
          <div className="flex items-center gap-2">
            <ListPlus className="w-5 h-5 text-cyan-500" />
            <h3 className={`text-sm font-bold ${themeConfig.textPrimary}`}>Add to Playlist</h3>
          </div>
          <button onClick={onClose} className={`p-1 ${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className={`text-xs ${themeConfig.textSecondary} mb-3 truncate`}>
          Select playlist for <strong className={themeConfig.textPrimary}>"{track.title}"</strong>
        </p>

        <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
          {playlists.map(pl => {
            const alreadyIn = pl.trackIds.includes(track.id);
            return (
              <button
                key={pl.id}
                disabled={alreadyIn}
                onClick={() => {
                  onAddTrackToPlaylist(pl.id, track.id);
                  onClose();
                }}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left text-xs font-semibold transition ${
                  alreadyIn 
                    ? `${themeConfig.isDark ? 'bg-neutral-900/40 text-neutral-600' : 'bg-slate-100 text-slate-400'} cursor-not-allowed`
                    : `${themeConfig.cardBg} border ${themeConfig.cardBorder} hover:border-cyan-500/40 ${themeConfig.textPrimary} hover:${themeConfig.accentText}`
                }`}
              >
                <span>{pl.title}</span>
                <span className={`text-[11px] font-mono ${themeConfig.textSecondary}`}>
                  {alreadyIn ? 'Added' : `+ Add (${pl.trackIds.length})`}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
