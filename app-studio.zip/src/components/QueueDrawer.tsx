import React from 'react';
import { MediaTrack } from '../types';
import { ListMusic, X, Trash2, Play, Music } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface QueueDrawerProps {
  queue: MediaTrack[];
  currentIndex: number;
  onSelectTrack: (index: number) => void;
  onRemoveTrack: (index: number) => void;
  onClearQueue: () => void;
  onClose: () => void;
}

export const QueueDrawer: React.FC<QueueDrawerProps> = ({
  queue,
  currentIndex,
  onSelectTrack,
  onRemoveTrack,
  onClearQueue,
  onClose
}) => {
  const { config: themeConfig } = useTheme();

  return (
    <div className={`fixed inset-0 z-50 ${themeConfig.isDark ? 'bg-black/80' : 'bg-black/50'} backdrop-blur-md flex justify-end animate-fadeIn`}>
      <div className={`w-full max-w-md ${themeConfig.modalBg} h-full flex flex-col justify-between border-l ${themeConfig.modalBorder} p-4 shadow-2xl`}>
        {/* Header */}
        <div className={`flex items-center justify-between pb-3 border-b ${themeConfig.cardBorder}`}>
          <div className="flex items-center gap-2">
            <ListMusic className="w-5 h-5 text-cyan-500" />
            <div>
              <h3 className={`text-sm font-bold ${themeConfig.textPrimary}`}>Playback Queue</h3>
              <p className={`text-[11px] ${themeConfig.textSecondary}`}>
                {queue.length} Tracks in queue
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {queue.length > 0 && (
              <button
                onClick={onClearQueue}
                className={`text-xs ${themeConfig.textSecondary} hover:text-rose-500 px-2 py-1 transition flex items-center gap-1`}
                title="Clear all queue"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
            <button
              onClick={onClose}
              className={`p-1.5 rounded-full ${themeConfig.textSecondary} hover:${themeConfig.textPrimary} transition`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Queue Items */}
        <div className="flex-1 overflow-y-auto py-3 space-y-1.5 no-scrollbar">
          {queue.map((track, idx) => {
            const isPlayingNow = idx === currentIndex;

            return (
              <div
                key={`${track.id}-${idx}`}
                onClick={() => onSelectTrack(idx)}
                className={`group flex items-center justify-between p-2 rounded-xl cursor-pointer transition ${
                  isPlayingNow
                    ? 'bg-cyan-500/15 border border-cyan-500/30'
                    : `${themeConfig.isDark ? 'hover:bg-neutral-800/60' : 'hover:bg-slate-100'} border border-transparent`
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <span className={`w-5 text-center text-xs font-mono ${
                    isPlayingNow ? `${themeConfig.accentText} font-bold` : themeConfig.textMuted
                  }`}>
                    {idx + 1}
                  </span>
                  <img
                    src={track.artworkUrl}
                    alt={track.title}
                    className="w-10 h-10 rounded-lg object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <h4 className={`text-xs font-semibold truncate ${
                      isPlayingNow ? themeConfig.accentText : themeConfig.textPrimary
                    }`}>
                      {track.title}
                    </h4>
                    <p className={`text-[11px] ${themeConfig.textSecondary} truncate mt-0.5`}>
                      {track.artist}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => onRemoveTrack(idx)}
                    className={`p-1.5 ${themeConfig.textMuted} hover:text-rose-500 rounded transition`}
                    title="Remove from queue"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}

          {queue.length === 0 && (
            <div className={`h-full flex flex-col items-center justify-center ${themeConfig.textMuted} py-16`}>
              <Music className="w-12 h-12 mb-2 opacity-50" />
              <p className="text-xs">Queue is empty</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className={`pt-3 border-t ${themeConfig.cardBorder} text-center text-[11px] ${themeConfig.textMuted}`}>
          Media3 Background Queue System
        </div>
      </div>
    </div>
  );
};
