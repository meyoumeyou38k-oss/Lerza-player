import { MediaTrack, Playlist } from '../types';

export const INITIAL_TRACKS: MediaTrack[] = [];

export const INITIAL_PLAYLISTS: Playlist[] = [];

export const ADMOB_CONFIG = {
  appId: 'ca-app-pub-9045781362216532~7360959118',
  bannerUnitId: 'ca-app-pub-9045781362216532/5856305753',
  nativeUnitId: 'ca-app-pub-9045781362216532/5873100120',
  interstitialUnitId: 'ca-app-pub-9045781362216532/4368446768',
};

export const EQUALIZER_PRESETS: Record<string, number[]> = {
  flat: [0, 0, 0, 0, 0],
  bass_boost: [6, 4, 1, 0, -1],
  pop: [-1, 2, 4, 3, 1],
  rock: [4, 2, -1, 2, 4],
  vocal: [-2, 1, 4, 3, 0],
  jazz: [3, 1, 0, 2, 3],
  electronic: [5, 3, -1, 3, 4]
};
