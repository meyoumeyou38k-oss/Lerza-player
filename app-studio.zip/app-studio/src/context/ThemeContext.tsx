import React, { createContext, useContext } from 'react';
import { ThemeMode } from '../types';
import { ThemeConfig, getThemeConfig } from '../utils/theme';

interface ThemeContextType {
  theme: ThemeMode;
  config: ThemeConfig;
  setTheme: (theme: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: 'light',
  config: getThemeConfig('light'),
  setTheme: () => {}
});

export const ThemeProvider: React.FC<{
  theme: ThemeMode;
  onThemeChange: (theme: ThemeMode) => void;
  children: React.ReactNode;
}> = ({ theme, onThemeChange, children }) => {
  const config = getThemeConfig(theme);

  return (
    <ThemeContext.Provider value={{ theme, config, setTheme: onThemeChange }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
