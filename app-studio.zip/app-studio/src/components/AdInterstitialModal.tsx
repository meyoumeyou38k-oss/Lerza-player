import React, { useState, useEffect } from 'react';
import { ADMOB_CONFIG } from '../data/sampleMedia';
import { X, ExternalLink, Sparkles } from 'lucide-react';

interface AdInterstitialModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdInterstitialModal: React.FC<AdInterstitialModalProps> = ({
  isOpen,
  onClose
}) => {
  const [countdown, setCountdown] = useState(3);
  const [canClose, setCanClose] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setCountdown(3);
      setCanClose(false);
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setCanClose(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleOpenAd = () => {
    const url = 'https://play.google.com/store/apps';
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch {
      window.location.href = url;
    }
  };

  return (
    <div className="fixed inset-0 z-70 bg-black/95 flex flex-col justify-between p-6 animate-fadeIn backdrop-blur-md">
      {/* Top Bar with countdown & close */}
      <div className="flex items-center justify-between max-w-lg w-full mx-auto">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded">
            AdMob Interstitial
          </span>
          <span className="text-xs text-neutral-400 font-mono truncate max-w-[150px] sm:max-w-none">
            {ADMOB_CONFIG.interstitialUnitId}
          </span>
        </div>

        {canClose ? (
          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white text-xs font-black transition cursor-pointer"
          >
            <span>Skip Ad</span>
            <X className="w-4 h-4" />
          </button>
        ) : (
          <span className="text-xs font-mono text-neutral-300 bg-neutral-900/90 px-3 py-1 rounded-full border border-white/20">
            Skip in {countdown}s
          </span>
        )}
      </div>

      {/* Main Interstitial Ad Body */}
      <div className="max-w-md w-full mx-auto my-auto text-center space-y-5">
        <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-cyan-500 to-indigo-600 mx-auto flex items-center justify-center shadow-2xl shadow-cyan-500/40 border border-cyan-400/30">
          <span className="text-white font-black text-2xl tracking-tighter">
            LERZA PRO
          </span>
        </div>

        <div>
          <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-widest bg-cyan-500/10 px-2.5 py-1 rounded-full">
            Featured Music Upgrade
          </span>
          <h2 className="text-2xl font-black text-white tracking-tight mt-2">
            Stream Master Pro
          </h2>
          <p className="text-sm text-neutral-300 max-w-xs mx-auto mt-2 leading-relaxed">
            Unlock lossless FLAC streaming, 32-band equalizer, and background visualizer.
          </p>
        </div>

        <div className="pt-3">
          <button
            type="button"
            onClick={handleOpenAd}
            className="w-full py-3 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 to-teal-400 text-neutral-950 font-black text-sm shadow-xl shadow-cyan-500/25 flex items-center justify-center gap-2 hover:opacity-95 active:scale-98 transition cursor-pointer"
          >
            <span>Explore & Install</span>
            <ExternalLink className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Bottom Ad Attribution */}
      <div className="text-center text-[10px] text-neutral-500 max-w-lg w-full mx-auto">
        Frequency controlled: Maximum 1 interstitial per session (non-intrusive playback safe).
      </div>
    </div>
  );
};
