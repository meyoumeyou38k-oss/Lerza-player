import React from 'react';
import { MediaTrack } from '../types';
import { Play, Pause, SkipForward, ListMusic, Video } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { generateVinylAlbumArt } from '../utils/artworkExtractor';

interface MiniPlayerProps {
  currentTrack: MediaTrack;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev?: () => void;
  onOpenFullPlayer: () => void;
  onOpenQueue: () => void;
  onSeek?: (seconds: number) => void;
}

export const MiniPlayer: React.FC<MiniPlayerProps> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  onTogglePlay,
  onNext,
  onPrev,
  onOpenFullPlayer,
  onOpenQueue,
  onSeek
}) => {
  const { config: themeConfig } = useTheme();
  const touchStartRef = React.useRef<{ x: number; y: number } | null>(null);
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    const deltaX = e.changedTouches[0].clientX - touchStartRef.current.x;
    const deltaY = e.changedTouches[0].clientY - touchStartRef.current.y;
    touchStartRef.current = null;

    if (Math.abs(deltaX) > 40 && Math.abs(deltaX) > Math.abs(deltaY) * 1.2) {
      if (deltaX < 0) {
        onNext();
      } else if (onPrev) {
        onPrev();
      }
    }
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const maxDur = duration > 0 ? duration : (currentTrack.duration || 0);
    if (!onSeek || maxDur <= 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    if (rect.width <= 0) return;
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    onSeek(ratio * maxDur);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 px-2.5 pb-2.5 max-w-2xl mx-auto pointer-events-none">
      <div 
        onClick={onOpenFullPlayer}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        className={`pointer-events-auto group relative ${themeConfig.miniPlayerBg} backdrop-blur-xl rounded-2xl p-2.5 cursor-pointer transition-all duration-300 transform active:scale-[0.99] border`}
      >
        {/* Clickable Progress Bar at top edge for instant seeking */}
        <div 
          onClick={handleProgressClick}
          title="Click to seek"
          className={`absolute -top-1 left-3 right-3 h-3 flex items-center cursor-pointer group/bar`}
        >
          <div className={`w-full h-[3px] group-hover/bar:h-[5px] ${themeConfig.isDark ? 'bg-white/10' : 'bg-black/10'} rounded-full overflow-hidden transition-all`}>
            <div 
              className="h-full bg-gradient-to-r from-cyan-500 to-teal-400 rounded-full transition-all duration-100"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        <div className="flex items-center justify-between gap-3 pt-1">
          {/* Left: Artwork + Title */}
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div className={`relative w-11 h-11 rounded-xl overflow-hidden shrink-0 ${themeConfig.isDark ? 'bg-neutral-800' : 'bg-slate-200'} shadow-md`}>
              <img 
                src={currentTrack.artworkUrl} 
                alt={currentTrack.title}
                className={`w-full h-full object-cover transition-all ${
                  isPlaying ? 'scale-105' : 'scale-100 opacity-90'
                }`}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = generateVinylAlbumArt(currentTrack.title, currentTrack.artist);
                }}
              />
              {currentTrack.hasMV && (
                <div className="absolute bottom-0.5 right-0.5 bg-black/70 px-1 py-0.2 rounded text-[8px] font-bold text-cyan-300 flex items-center">
                  <Video className="w-2 h-2" />
                </div>
              )}
            </div>

            <div className="min-w-0 flex-1">
              <h4 className={`text-xs font-bold ${themeConfig.textPrimary} truncate group-hover:${themeConfig.accentText} transition`}>
                {currentTrack.title}
              </h4>
              <p className={`text-[11px] ${themeConfig.textSecondary} truncate mt-0.5`}>
                {currentTrack.artist}
              </p>
            </div>
          </div>

          {/* Right: Controls */}
          <div className="flex items-center gap-1 shrink-0" onClick={e => e.stopPropagation()}>
            <button
              onClick={onTogglePlay}
              className={`w-10 h-10 rounded-full ${themeConfig.accentBg} flex items-center justify-center shadow-lg active:scale-95 transition`}
              title={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? (
                <Pause className="w-5 h-5 fill-current" />
              ) : (
                <Play className="w-5 h-5 fill-current ml-0.5" />
              )}
            </button>

            <button
              onClick={onNext}
              className={`p-2 ${themeConfig.textSecondary} hover:${themeConfig.textPrimary} active:scale-95 transition`}
              title="Next Track"
            >
              <SkipForward className="w-5 h-5" />
            </button>

            <button
              onClick={onOpenQueue}
              className={`p-2 ${themeConfig.textSecondary} hover:${themeConfig.accentText} active:scale-95 transition`}
              title="Current Queue"
            >
              <ListMusic className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
