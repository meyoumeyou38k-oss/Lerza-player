import React, { useState, useEffect } from 'react';
import { Playlist, MediaTrack } from '../types';
import { Plus, ListMusic, Play, Trash2, Shuffle, Heart } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface PlaylistsViewProps {
  playlists: Playlist[];
  allTracks: MediaTrack[];
  onCreatePlaylist: (title: string, description: string) => void;
  onDeletePlaylist: (playlistId: string) => void;
  onPlayPlaylist: (playlist: Playlist, shuffle?: boolean) => void;
  onSelectTrack: (track: MediaTrack) => void;
  onToggleFavorite?: (trackId: string) => void;
}

export const PlaylistsView: React.FC<PlaylistsViewProps> = ({
  playlists,
  allTracks,
  onCreatePlaylist,
  onDeletePlaylist,
  onPlayPlaylist,
  onSelectTrack,
  onToggleFavorite
}) => {
  const { config: themeConfig } = useTheme();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null);
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);

  // Intercept back button to close open playlist detail or create modal
  useEffect(() => {
    const handleSubviewBack = (e: Event) => {
      if (showCreateModal) {
        setShowCreateModal(false);
        e.preventDefault();
      } else if (selectedPlaylist || isFavoritesOpen) {
        setSelectedPlaylist(null);
        setIsFavoritesOpen(false);
        e.preventDefault();
      }
    };
    window.addEventListener('subview-back-press', handleSubviewBack);
    return () => window.removeEventListener('subview-back-press', handleSubviewBack);
  }, [showCreateModal, selectedPlaylist, isFavoritesOpen]);

  // Compute all favorite tracks dynamically
  const favoriteTracks = allTracks.filter(t => t.isFavorite);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onCreatePlaylist(newTitle.trim(), newDesc.trim());
    setNewTitle('');
    setNewDesc('');
    setShowCreateModal(false);
  };

  const handlePlayFavorites = (shuffle = false) => {
    if (favoriteTracks.length === 0) return;
    const favPlaylist: Playlist = {
      id: 'favorites',
      title: 'Favorites (پسندیدہ)',
      description: 'Your favorite songs and videos',
      trackIds: favoriteTracks.map(t => t.id),
      createdAt: Date.now()
    };
    onPlayPlaylist(favPlaylist, shuffle);
  };

  const currentPlaylistTracks = isFavoritesOpen
    ? favoriteTracks
    : selectedPlaylist 
    ? allTracks.filter(t => selectedPlaylist.trackIds.includes(t.id))
    : [];

  return (
    <div className="px-4 py-3 max-w-6xl mx-auto pb-28">
      {/* Header and Create Button */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className={`text-base font-bold ${themeConfig.textPrimary} transition-colors`}>
            Playlists & Folders ({playlists.length + 1})
          </h3>
          <p className={`text-xs ${themeConfig.textSecondary}`}>
            Organize your media & view your favorites
          </p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl ${themeConfig.accentBg} font-bold text-xs shadow-md active:scale-95 transition`}
        >
          <Plus className="w-4 h-4" />
          <span>New Playlist</span>
        </button>
      </div>

      {/* PINNED FAVORITES FOLDER CARD */}
      <div className="mb-4">
        <div
          onClick={() => {
            setSelectedPlaylist(null);
            setIsFavoritesOpen(true);
          }}
          className={`group p-3.5 rounded-2xl cursor-pointer transition-all border shadow-sm flex items-center justify-between gap-3 ${
            isFavoritesOpen
              ? `${themeConfig.cardActive} border-rose-500/50 shadow-rose-500/10`
              : `${themeConfig.cardBg} ${themeConfig.cardHover} border-rose-500/30 hover:border-rose-500/60`
          }`}
        >
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div className="w-14 h-14 rounded-2xl overflow-hidden shrink-0 bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center shadow-md relative group-hover:scale-105 transition">
              <Heart className="w-7 h-7 text-white fill-white animate-pulse" />
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                <Play className="w-5 h-5 text-white fill-white" />
              </div>
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <h4 className={`text-sm font-bold truncate ${themeConfig.textPrimary} group-hover:text-rose-500 transition`}>
                  Favorites (پسندیدہ گانے)
                </h4>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-500 border border-rose-500/30 shrink-0">
                  Auto Synced
                </span>
              </div>
              <p className={`text-xs ${themeConfig.textSecondary} truncate mt-0.5`}>
                {favoriteTracks.length} {favoriteTracks.length === 1 ? 'Track' : 'Tracks'} • خودکار فولڈر
              </p>
              <p className={`text-[11px] ${themeConfig.textMuted} truncate mt-0.5`}>
                Any song you tap the heart (❤️) on is saved here automatically
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0" onClick={e => e.stopPropagation()}>
            <button
              onClick={() => handlePlayFavorites(false)}
              disabled={favoriteTracks.length === 0}
              className="p-2 text-rose-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition disabled:opacity-40"
              title="Play All Favorites"
            >
              <Play className="w-5 h-5 fill-rose-500" />
            </button>
            <button
              onClick={() => handlePlayFavorites(true)}
              disabled={favoriteTracks.length === 0}
              className="p-2 text-rose-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition disabled:opacity-40"
              title="Shuffle Favorites"
            >
              <Shuffle className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Playlist Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {playlists.map((pl) => {
          const count = pl.trackIds.length;
          const isSelected = selectedPlaylist?.id === pl.id && !isFavoritesOpen;
          const cover = pl.artworkUrl || (
            allTracks.find(t => pl.trackIds.includes(t.id))?.artworkUrl || 
            'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80'
          );

          return (
            <div
              key={pl.id}
              onClick={() => {
                setIsFavoritesOpen(false);
                setSelectedPlaylist(pl);
              }}
              className={`group p-3 rounded-2xl cursor-pointer transition flex items-center justify-between gap-3 border shadow-xs ${
                isSelected
                  ? `${themeConfig.cardActive} border ${themeConfig.accentBorder}`
                  : `${themeConfig.cardBg} ${themeConfig.cardHover} ${themeConfig.cardBorder}`
              }`}
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <div className={`w-14 h-14 rounded-xl overflow-hidden shrink-0 ${themeConfig.isDark ? 'bg-neutral-800' : 'bg-slate-200'} relative`}>
                  <img src={cover} alt={pl.title} className="w-full h-full object-cover group-hover:scale-105 transition" />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                    <Play className="w-5 h-5 text-white fill-white" />
                  </div>
                </div>
                <div className="min-w-0 flex-1">
                  <h4 className={`text-sm font-semibold truncate ${themeConfig.textPrimary} group-hover:${themeConfig.accentText} transition`}>
                    {pl.title}
                  </h4>
                  <p className={`text-xs ${themeConfig.textSecondary} truncate mt-0.5`}>
                    {count} {count === 1 ? 'Song' : 'Songs'}
                  </p>
                  {pl.description && (
                    <p className={`text-[11px] ${themeConfig.textMuted} truncate mt-0.5`}>
                      {pl.description}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0" onClick={e => e.stopPropagation()}>
                <button
                  onClick={() => onPlayPlaylist(pl, false)}
                  className={`p-2 ${themeConfig.accentText} hover:bg-black/5 rounded-lg transition`}
                  title="Play"
                >
                  <Play className="w-4 h-4 fill-current" />
                </button>
                <button
                  onClick={() => onDeletePlaylist(pl.id)}
                  className="p-2 text-neutral-400 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition"
                  title="Delete playlist"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Playlist / Favorites Tracks Detailed View (if clicked) */}
      {(selectedPlaylist || isFavoritesOpen) && (
        <div className={`mt-6 p-4 rounded-3xl border shadow-lg ${themeConfig.cardBg} ${themeConfig.cardBorder} transition-colors`}>
          <div className={`flex items-center justify-between pb-3 border-b ${themeConfig.isDark ? 'border-white/10' : 'border-slate-200'} mb-3`}>
            <div>
              <h4 className={`text-base font-bold flex items-center gap-2 ${themeConfig.textPrimary}`}>
                {isFavoritesOpen ? (
                  <>
                    <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
                    <span>Favorites (پسندیدہ گانے)</span>
                  </>
                ) : (
                  <>
                    <ListMusic className={`w-5 h-5 ${themeConfig.accentText}`} />
                    <span>{selectedPlaylist?.title}</span>
                  </>
                )}
              </h4>
              <p className={`text-xs ${themeConfig.textSecondary} mt-0.5`}>
                {currentPlaylistTracks.length} Songs in this {isFavoritesOpen ? 'favorites folder' : 'playlist'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (isFavoritesOpen) {
                    handlePlayFavorites(false);
                  } else if (selectedPlaylist) {
                    onPlayPlaylist(selectedPlaylist, false);
                  }
                }}
                disabled={currentPlaylistTracks.length === 0}
                className={`px-3 py-1.5 rounded-xl ${themeConfig.accentBg} font-bold text-xs flex items-center gap-1.5 disabled:opacity-40 transition`}
              >
                <Play className="w-3.5 h-3.5 fill-current" /> Play All
              </button>
              <button
                onClick={() => {
                  if (isFavoritesOpen) {
                    handlePlayFavorites(true);
                  } else if (selectedPlaylist) {
                    onPlayPlaylist(selectedPlaylist, true);
                  }
                }}
                disabled={currentPlaylistTracks.length === 0}
                className={`px-3 py-1.5 rounded-xl ${themeConfig.isDark ? 'bg-neutral-800 text-white' : 'bg-slate-100 text-slate-800'} font-semibold text-xs flex items-center gap-1.5 disabled:opacity-40 transition`}
              >
                <Shuffle className="w-3.5 h-3.5" /> Shuffle
              </button>
              <button
                onClick={() => {
                  setSelectedPlaylist(null);
                  setIsFavoritesOpen(false);
                }}
                className={`p-1.5 ${themeConfig.textSecondary} hover:${themeConfig.textPrimary} rounded-lg`}
              >
                ✕
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            {currentPlaylistTracks.map((trk, i) => (
              <div
                key={trk.id}
                onClick={() => onSelectTrack(trk)}
                className={`flex items-center justify-between p-2.5 rounded-xl cursor-pointer text-xs transition ${
                  themeConfig.isDark ? 'hover:bg-white/5' : 'hover:bg-black/5'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <span className={`${themeConfig.textMuted} w-4 font-mono text-center`}>{i + 1}</span>
                  <img src={trk.artworkUrl} className="w-9 h-9 rounded-lg object-cover shrink-0 shadow-xs" alt={trk.title} />
                  <div className="truncate flex-1">
                    <p className={`font-semibold ${themeConfig.textPrimary} truncate`}>{trk.title}</p>
                    <p className={`text-[11px] ${themeConfig.textSecondary} truncate`}>{trk.artist}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {onToggleFavorite && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(trk.id);
                      }}
                      className="p-1.5 text-rose-500 hover:scale-110 transition"
                      title={trk.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                    >
                      <Heart className={`w-4 h-4 ${trk.isFavorite ? 'fill-rose-500 text-rose-500' : 'text-neutral-400'}`} />
                    </button>
                  )}
                  <span className={`${themeConfig.textMuted} font-mono text-[11px]`}>
                    {Math.floor(trk.duration / 60)}:{(trk.duration % 60).toString().padStart(2, '0')}
                  </span>
                </div>
              </div>
            ))}
            {currentPlaylistTracks.length === 0 && (
              <p className={`text-center py-6 text-xs ${themeConfig.textMuted}`}>
                {isFavoritesOpen 
                  ? 'No favorite tracks yet. Tap the heart (❤️) icon on any song to save it here!' 
                  : 'No songs in this playlist yet. Add songs from the Songs tab!'}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Modal: Create Playlist */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className={`w-full max-w-sm ${themeConfig.modalBg} border ${themeConfig.modalBorder} rounded-3xl p-5 shadow-2xl transition-colors`}>
            <h3 className={`text-base font-bold ${themeConfig.textPrimary} mb-3`}>Create New Playlist</h3>
            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className={`block text-xs font-medium ${themeConfig.textSecondary} mb-1`}>Playlist Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  placeholder="e.g. Gym Workout, Relaxing"
                  autoFocus
                  required
                  className={`w-full ${themeConfig.inputBg} border ${themeConfig.inputBorder} rounded-xl px-3 py-2 text-sm ${themeConfig.inputText} focus:outline-none focus:ring-1 focus:ring-cyan-500`}
                />
              </div>
              <div>
                <label className={`block text-xs font-medium ${themeConfig.textSecondary} mb-1`}>Description (Optional)</label>
                <input
                  type="text"
                  value={newDesc}
                  onChange={e => setNewDesc(e.target.value)}
                  placeholder="Short note about this mix"
                  className={`w-full ${themeConfig.inputBg} border ${themeConfig.inputBorder} rounded-xl px-3 py-2 text-sm ${themeConfig.inputText} focus:outline-none focus:ring-1 focus:ring-cyan-500`}
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold ${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-4 py-2 rounded-xl text-xs font-bold ${themeConfig.accentBg} shadow-md`}
                >
                  Create Playlist
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
