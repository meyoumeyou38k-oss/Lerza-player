import React, { useState, useEffect } from 'react';
import { ADMOB_CONFIG } from '../data/sampleMedia';
import { ExternalLink, RefreshCw } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface AdBannerProps {
  isOnline: boolean;
  isAdsRemoved: boolean;
}

const SPONSOR_ADS = [
  {
    id: 'ad-1',
    title: 'Sony WH-1000XM5 Hi-Res Audio',
    tagline: 'Industry-leading noise cancelling with Auto NC Optimizer.',
    cta: 'Shop Now',
    url: 'https://www.sony.com/electronics/headband-headphones/wh-1000xm5',
    color: 'from-amber-500 to-orange-600',
    badge: 'Hardware Sponsor'
  },
  {
    id: 'ad-2',
    title: 'SoundCloud Go+ Unlimited',
    tagline: 'Save tracks offline with zero interruptions. Try 30 days free.',
    cta: 'Try Free',
    url: 'https://soundcloud.com/go',
    color: 'from-orange-500 to-rose-600',
    badge: 'Music Streaming'
  },
  {
    id: 'ad-3',
    title: 'AudioMaster AI Equalizer DSP',
    tagline: 'Precision 32-band parametric mastering engine for audiophiles.',
    cta: 'Get App',
    url: 'https://play.google.com/store/apps',
    color: 'from-cyan-500 to-blue-600',
    badge: 'Top Audio App'
  },
  {
    id: 'ad-4',
    title: 'Sennheiser Momentum 4 Wireless',
    tagline: 'Exceptional 60-hour battery life and audiophile-grade transducers.',
    cta: 'Explore',
    url: 'https://www.sennheiser-hearing.com',
    color: 'from-emerald-500 to-teal-600',
    badge: 'Audiophile Gear'
  }
];

export const AdBanner: React.FC<AdBannerProps> = ({ isOnline, isAdsRemoved }) => {
  const { config: themeConfig } = useTheme();
  const [adIndex, setAdIndex] = useState(0);
  const [fade, setFade] = useState(true);

  // Auto-rotate banner ad every 25 seconds if active
  useEffect(() => {
    if (!isOnline || isAdsRemoved) return;
    const interval = setInterval(() => {
      setFade(false);
      setTimeout(() => {
        setAdIndex((prev) => (prev + 1) % SPONSOR_ADS.length);
        setFade(true);
      }, 250);
    }, 25000);
    return () => clearInterval(interval);
  }, [isOnline, isAdsRemoved]);

  // Requirement #24: If offline or ads removed, hide ad container immediately
  if (!isOnline || isAdsRemoved) {
    return null;
  }

  const currentAd = SPONSOR_ADS[adIndex];

  const handleOpenAd = (url: string) => {
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch {
      window.location.href = url;
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto my-2.5 px-3 transition-all duration-300">
      <div 
        className={`${themeConfig.cardBg} border ${themeConfig.cardBorder} rounded-xl p-2.5 flex items-center justify-between gap-3 shadow-md hover:border-cyan-500/40 transition-all ${
          fade ? 'opacity-100 scale-100' : 'opacity-40 scale-98'
        } duration-300`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="flex flex-col items-center shrink-0">
            <span className="text-[9px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-400 border border-amber-500/30 px-1.5 py-0.5 rounded leading-none">
              Ad
            </span>
            <span className="text-[8px] text-neutral-400 font-mono mt-0.5">Google</span>
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h4 className={`text-xs font-bold ${themeConfig.textPrimary} truncate`}>
                {currentAd.title}
              </h4>
              <span className="text-[9px] font-semibold text-cyan-400 bg-cyan-500/10 px-1.5 py-0.2 rounded shrink-0">
                {currentAd.badge}
              </span>
            </div>
            <p className={`text-[11px] ${themeConfig.textSecondary} truncate mt-0.5`}>
              {currentAd.tagline}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            title="Next sponsor"
            onClick={() => {
              setFade(false);
              setTimeout(() => {
                setAdIndex((prev) => (prev + 1) % SPONSOR_ADS.length);
                setFade(true);
              }, 150);
            }}
            className={`p-1.5 rounded-lg ${themeConfig.isDark ? 'hover:bg-white/10 text-neutral-400' : 'hover:bg-slate-200 text-slate-500'} active:scale-95 transition`}
          >
            <RefreshCw className="w-3 h-3" />
          </button>

          <button 
            type="button"
            onClick={() => handleOpenAd(currentAd.url)}
            className="bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-extrabold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1 transition active:scale-95 shadow-sm shadow-cyan-500/20 cursor-pointer"
          >
            <span>{currentAd.cta}</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>
      </div>

      <div className="flex justify-between items-center px-1.5 mt-1">
        <span className={`text-[9px] ${themeConfig.textMuted} font-mono flex items-center gap-1`}>
          <span>AdMob Unit:</span>
          <span className="truncate max-w-[200px] sm:max-w-none">{ADMOB_CONFIG.bannerUnitId}</span>
        </span>
        <span className={`text-[9px] ${themeConfig.textMuted}`}>
          Verified Sponsor
        </span>
      </div>
    </div>
  );
};
