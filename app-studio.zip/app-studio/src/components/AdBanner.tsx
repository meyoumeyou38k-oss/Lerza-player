import React from 'react';

interface AdBannerProps {
  isOnline: boolean;
  isAdsRemoved: boolean;
}

export const AdBanner: React.FC<AdBannerProps> = () => {
  return null;
};
