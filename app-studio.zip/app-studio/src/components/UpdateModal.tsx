import React, { useState } from 'react';
import { 
  Sparkles, 
  Download, 
  X, 
  CheckCircle2, 
  ExternalLink, 
  RefreshCw,
  Clock,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export interface UpdateInfo {
  latestVersion: string;
  versionCode: number;
  minSupportedVersionCode?: number;
  releaseDate?: string;
  title: string;
  titleUrdu?: string;
  releaseNotes: string[];
  downloadUrl: string;
  apkDirectUrl?: string;
  isMandatory?: boolean;
  fileSize?: string;
}

interface UpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  updateInfo: UpdateInfo | null;
  currentVersion: string;
}

export const UpdateModal: React.FC<UpdateModalProps> = ({
  isOpen,
  onClose,
  updateInfo,
  currentVersion
}) => {
  const { config: themeConfig } = useTheme();
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadDone, setDownloadDone] = useState(false);

  if (!isOpen || !updateInfo) return null;

  const handleStartUpdate = () => {
    const targetUrl = updateInfo.apkDirectUrl || updateInfo.downloadUrl;
    
    // Simulate real download progress for immediate visual feedback
    setIsDownloading(true);
    setDownloadProgress(15);

    const timer1 = setTimeout(() => setDownloadProgress(45), 400);
    const timer2 = setTimeout(() => setDownloadProgress(85), 800);
    const timer3 = setTimeout(() => {
      setDownloadProgress(100);
      setDownloadDone(true);
      setIsDownloading(false);

      // Open download URL
      if (typeof window !== 'undefined') {
        const link = document.createElement('a');
        link.href = targetUrl;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }, 1200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  };

  return (
    <div 
      className="fixed inset-0 z-70 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn select-none"
      onClick={() => !updateInfo.isMandatory && onClose()}
    >
      <div 
        className={`w-full max-w-md rounded-3xl ${
          themeConfig.isDark 
            ? 'bg-gradient-to-b from-[#1c1d24] to-[#121318] text-white border-white/10' 
            : 'bg-gradient-to-b from-white to-[#f7f5ef] text-neutral-900 border-black/10'
        } border shadow-2xl p-5 sm:p-6 animate-scaleUp overflow-hidden relative`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Decorative Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-1 bg-gradient-to-r from-blue-500 via-cyan-400 to-indigo-500 rounded-full blur-xs" />

        {/* Close Button (only if not mandatory) */}
        {!updateInfo.isMandatory && (
          <button
            onClick={onClose}
            className={`absolute top-4 right-4 p-2 rounded-full ${
              themeConfig.isDark ? 'hover:bg-white/10 text-neutral-400' : 'hover:bg-black/5 text-neutral-600'
            } transition`}
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Header with App Logo & Update Badge */}
        <div className="flex items-start gap-4 mb-4">
          <div className="relative w-14 h-14 rounded-2xl overflow-hidden shadow-lg border border-blue-500/30 bg-neutral-900 shrink-0">
            <img 
              src="/app-logo.png?v=2" 
              alt="Lerza Player" 
              className="w-full h-full object-cover"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = '/app-icon.png?v=2';
              }}
            />
            <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white rounded-full p-1 shadow">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>

          <div className="min-w-0 flex-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/15 text-blue-600 dark:text-blue-400 text-xs font-bold mb-1">
              <span>New Version Available</span>
              <span className="font-mono font-extrabold">v{updateInfo.latestVersion}</span>
            </div>
            <h3 className="text-lg sm:text-xl font-black tracking-tight leading-snug">
              {updateInfo.titleUrdu || updateInfo.title}
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Current: v{currentVersion} • Size: {updateInfo.fileSize || '14.2 MB'}
            </p>
          </div>
        </div>

        {/* What's New Box */}
        <div className={`p-4 rounded-2xl ${
          themeConfig.isDark ? 'bg-neutral-800/60 border-white/5' : 'bg-black/5 border-black/5'
        } border mb-5`}>
          <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-2">
            <Sparkles className="w-4 h-4" />
            <span>نیا کیا ہے؟ (What's New)</span>
          </div>
          <ul className="space-y-1.5 text-xs sm:text-sm text-neutral-700 dark:text-neutral-300">
            {updateInfo.releaseNotes.map((note, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span className="leading-snug">{note}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Security & Verification Badge */}
        <div className="flex items-center gap-2 text-[11px] text-neutral-500 dark:text-neutral-400 mb-4 px-1">
          <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>100% Virus-Free • Verified Official APK Build</span>
        </div>

        {/* Download Progress Bar if downloading */}
        {isDownloading && (
          <div className="mb-4 space-y-1.5 animate-fadeIn">
            <div className="flex justify-between text-xs font-mono font-bold text-neutral-500">
              <span>ڈاؤنلوڈ شروع ہو رہا ہے...</span>
              <span>{downloadProgress}%</span>
            </div>
            <div className="w-full h-2 bg-neutral-200 dark:bg-neutral-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-blue-600 to-cyan-500 transition-all duration-300 rounded-full"
                style={{ width: `${downloadProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Download Done Notice */}
        {downloadDone && (
          <div className="mb-4 p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>ڈاؤنلوڈ مکمل! اپنے نوٹیفکیشن یا ڈاؤنلوڈ فولڈر سے APK انسٹال کریں۔</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          {!updateInfo.isMandatory && (
            <button
              onClick={onClose}
              disabled={isDownloading}
              className={`flex-1 py-3 px-4 rounded-2xl text-xs sm:text-sm font-bold border ${
                themeConfig.isDark 
                  ? 'border-white/10 hover:bg-white/5 text-neutral-300' 
                  : 'border-black/10 hover:bg-black/5 text-neutral-700'
              } transition active:scale-95 disabled:opacity-50`}
            >
              بعد میں (Later)
            </button>
          )}

          <button
            onClick={handleStartUpdate}
            disabled={isDownloading}
            className="flex-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 shadow-lg shadow-blue-500/25 active:scale-95 transition disabled:opacity-60 cursor-pointer"
          >
            {isDownloading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>ڈاؤنلوڈ ہو رہا ہے...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>ابھی اپڈیٹ کریں (Update Now)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
