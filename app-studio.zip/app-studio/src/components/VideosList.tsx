import React, { useState, useRef, useEffect } from 'react';
import { MediaTrack } from '../types';
import { 
  Play, 
  Heart, 
  Film, 
  Folder, 
  Trash2, 
  MoreVertical, 
  CheckSquare, 
  Square, 
  X 
} from 'lucide-react';
import { AdNative } from './AdNative';
import { useTheme } from '../context/ThemeContext';

interface VideosListProps {
  videos: MediaTrack[];
  onSelectVideo: (track: MediaTrack) => void;
  onToggleFavorite: (trackId: string) => void;
  onDeleteVideo: (trackId: string) => void;
  onDeleteMultipleVideos: (trackIds: string[]) => void;
  isOnline: boolean;
  isAdsRemoved: boolean;
}

export const VideosList: React.FC<VideosListProps> = ({
  videos,
  onSelectVideo,
  onToggleFavorite,
  onDeleteVideo,
  onDeleteMultipleVideos,
  isOnline,
  isAdsRemoved
}) => {
  const { config: themeConfig } = useTheme();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>(() => {
    try {
      const saved = localStorage.getItem('lerza_video_view_mode') || localStorage.getItem('fz_video_view_mode');
      return (saved === 'list' || saved === 'grid') ? saved : 'grid';
    } catch {
      return 'grid';
    }
  });

  useEffect(() => {
    try {
      const saved = localStorage.getItem('lerza_video_view_mode') || localStorage.getItem('fz_video_view_mode');
      if (saved === 'list' || saved === 'grid') {
        setViewMode(saved);
      }
    } catch (e) {
      console.warn('Could not read video view mode preference:', e);
    }
  }, []);

  const handleSetViewMode = (mode: 'grid' | 'list') => {
    setViewMode(mode);
    try {
      localStorage.setItem('lerza_video_view_mode', mode);
      localStorage.setItem('fz_video_view_mode', mode);
    } catch (e) {
      console.warn('Could not save video view mode preference:', e);
    }
  };
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  // Multi-selection state
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [videoToDelete, setVideoToDelete] = useState<MediaTrack | null>(null);
  const [showBatchDeleteConfirm, setShowBatchDeleteConfirm] = useState(false);

  // Long press tracking refs
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);
  const touchStartPos = useRef<{ x: number; y: number } | null>(null);
  const isScrolling = useRef<boolean>(false);

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleTouchStart = (e: React.TouchEvent, vid: MediaTrack) => {
    if (isSelectionMode) return;
    const touch = e.touches[0];
    touchStartPos.current = { x: touch.clientX, y: touch.clientY };
    isScrolling.current = false;

    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }

    longPressTimer.current = setTimeout(() => {
      if (!isScrolling.current) {
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          try { navigator.vibrate(35); } catch (_) {}
        }
        setIsSelectionMode(true);
        setSelectedIds(new Set([vid.id]));
      }
    }, 650);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStartPos.current) return;
    const touch = e.touches[0];
    const dx = Math.abs(touch.clientX - touchStartPos.current.x);
    const dy = Math.abs(touch.clientY - touchStartPos.current.y);

    if (dx > 8 || dy > 8) {
      isScrolling.current = true;
      handleEndLongPress();
    }
  };

  const handleTouchEnd = () => {
    handleEndLongPress();
    touchStartPos.current = null;
    isScrolling.current = false;
  };

  const handleEndLongPress = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
      if (next.size === 0) setIsSelectionMode(false);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const handleSelectAll = () => {
    if (selectedIds.size === videos.length) {
      setSelectedIds(new Set());
      setIsSelectionMode(false);
    } else {
      setSelectedIds(new Set(videos.map(v => v.id)));
    }
  };

  const handleConfirmBatchDelete = () => {
    onDeleteMultipleVideos(Array.from(selectedIds));
    setSelectedIds(new Set());
    setIsSelectionMode(false);
    setShowBatchDeleteConfirm(false);
  };

  return (
    <div className="px-4 py-3 max-w-6xl mx-auto pb-28">
      {/* Sticky Selection Top Action Bar */}
      {isSelectionMode ? (
        <div className="sticky top-2 z-30 mb-3 bg-[#121520] border border-cyan-500/40 rounded-2xl p-3 shadow-xl flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setIsSelectionMode(false);
                setSelectedIds(new Set());
              }}
              className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
            <span className="text-xs font-bold text-white">
              {selectedIds.size} Selected
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSelectAll}
              className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-neutral-800 text-neutral-300 hover:text-white transition"
            >
              {selectedIds.size === videos.length ? 'Deselect All' : 'Select All'}
            </button>

            {selectedIds.size > 0 && (
              <button
                onClick={() => setShowBatchDeleteConfirm(true)}
                className="flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/30 hover:bg-rose-500 hover:text-white transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete ({selectedIds.size})</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        /* Normal Header Info & Switcher */
        <div className="flex items-center justify-between mb-3 gap-2">
          <div className="flex items-center gap-2">
            <span className={`text-xs font-semibold ${themeConfig.textSecondary}`}>
              {videos.length} Videos Available
            </span>
            <button
              onClick={() => {
                if ((window as any).AndroidBridge?.scanLocalVideos) {
                  try {
                    (window as any).AndroidBridge.scanLocalVideos();
                  } catch (e) {
                    console.warn('Scan videos bridge error:', e);
                  }
                }
              }}
              className={`text-[11px] font-bold px-2 py-0.5 rounded-lg border transition ${
                themeConfig.isDark 
                  ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20' 
                  : 'bg-sky-50 border-sky-300 text-sky-700 hover:bg-sky-100'
              }`}
              title="Refresh and scan device storage for all videos"
            >
              Scan Device
            </button>
          </div>
          <div className={`flex items-center gap-1 ${themeConfig.isDark ? 'bg-neutral-900/80 border-white/5' : 'bg-slate-100 border-slate-200'} border rounded-xl p-1 text-xs`}>
            <button
              onClick={() => handleSetViewMode('grid')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                viewMode === 'grid' ? `${themeConfig.accentBg} shadow-sm` : `${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`
              }`}
            >
              Grid
            </button>
            <button
              onClick={() => handleSetViewMode('list')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                viewMode === 'list' ? `${themeConfig.accentBg} shadow-sm` : `${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`
              }`}
            >
              List
            </button>
          </div>
        </div>
      )}

      {videos.length === 0 ? (
        <div className={`text-center py-16 px-4 rounded-2xl border ${themeConfig.cardBorder} ${themeConfig.cardBg}`}>
          <Film className="w-12 h-12 mx-auto mb-3 text-cyan-400 opacity-60" />
          <h3 className={`text-base font-bold ${themeConfig.textPrimary} mb-1`}>No Videos Found</h3>
          <p className={`text-xs ${themeConfig.textSecondary} max-w-md mx-auto mb-4`}>
            Scan device storage or import your local video files (.mp4, .mkv, .webm) to play them in high definition with audio equalizer support.
          </p>
          <button
            onClick={() => {
              if ((window as any).AndroidBridge?.scanLocalVideos) {
                (window as any).AndroidBridge.scanLocalVideos();
              }
              const inputEl = document.querySelector('input[type="file"]') as HTMLInputElement;
              if (inputEl) inputEl.click();
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold ${themeConfig.accentBg} shadow-lg`}
          >
            Scan & Import Device Videos
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {videos.map((vid, idx) => {
            const isSelected = selectedIds.has(vid.id);

            return (
              <React.Fragment key={vid.id}>
                {idx === 3 && (
                  <div className="col-span-full">
                    <AdNative isOnline={isOnline} isAdsRemoved={isAdsRemoved} />
                  </div>
                )}
                <div 
                  onMouseDown={() => {
                    if (isSelectionMode) return;
                    if (longPressTimer.current) clearTimeout(longPressTimer.current);
                    longPressTimer.current = setTimeout(() => {
                      setIsSelectionMode(true);
                      setSelectedIds(new Set([vid.id]));
                    }, 650);
                  }}
                  onMouseUp={handleEndLongPress}
                  onMouseLeave={handleEndLongPress}
                  onTouchStart={(e) => handleTouchStart(e, vid)}
                  onTouchMove={handleTouchMove}
                  onTouchEnd={handleTouchEnd}
                  onTouchCancel={handleTouchEnd}
                  onContextMenu={(e) => {
                    if (!isSelectionMode) e.preventDefault();
                  }}
                  onClick={() => {
                    if (isSelectionMode) toggleSelect(vid.id);
                    else onSelectVideo(vid);
                  }}
                  className={`group ${themeConfig.cardBg} border rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 flex flex-col relative select-none ${
                    isSelected
                      ? 'border-cyan-500 shadow-lg shadow-cyan-500/20'
                      : `${themeConfig.cardBorder} hover:border-cyan-500/40 hover:shadow-xl`
                  }`}
                >
                  {/* Selection Checkbox */}
                  {isSelectionMode && (
                    <div className="absolute top-2 left-2 z-10 bg-black/60 backdrop-blur-md rounded-lg p-1 text-cyan-400">
                      {isSelected ? (
                        <CheckSquare className="w-5 h-5 text-cyan-400 fill-cyan-400/20" />
                      ) : (
                        <Square className="w-5 h-5 text-white" />
                      )}
                    </div>
                  )}

                  {/* Thumbnail with overlay */}
                  <div className="relative aspect-video w-full bg-neutral-800 overflow-hidden">
                    <img
                      src={vid.artworkUrl}
                      alt={vid.title}
                      loading="lazy"
                      decoding="async"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/app-icon.png';
                      }}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end justify-between p-2.5">
                      <span className="text-[11px] font-mono font-bold bg-black/60 backdrop-blur-md px-2 py-0.5 rounded text-white border border-white/10">
                        {formatDuration(vid.duration)}
                      </span>
                      {!isSelectionMode && (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onToggleFavorite(vid.id);
                            }}
                            className="p-1.5 rounded-full bg-black/50 backdrop-blur-md hover:scale-110 active:scale-95 transition"
                          >
                            <Heart
                              className={`w-4 h-4 ${
                                vid.isFavorite ? 'text-rose-500 fill-rose-500' : 'text-white'
                              }`}
                            />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setVideoToDelete(vid);
                            }}
                            className="p-1.5 rounded-full bg-black/50 backdrop-blur-md text-neutral-400 hover:text-rose-400 hover:scale-110 active:scale-95 transition"
                            title="Delete Video"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Center Play Button Overlay */}
                    {!isSelectionMode && (
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/30 transition">
                        <div className="w-12 h-12 rounded-full bg-cyan-500 flex items-center justify-center shadow-lg shadow-cyan-500/40 transform group-hover:scale-110 transition">
                          <Play className="w-5 h-5 text-neutral-950 fill-neutral-950 ml-0.5" />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Video Info */}
                  <div className="p-3 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className={`text-sm font-semibold ${themeConfig.textPrimary} group-hover:${themeConfig.accentText} transition line-clamp-1`}>
                        {vid.title}
                      </h4>
                      <p className={`text-xs ${themeConfig.textSecondary} truncate mt-0.5`}>
                        {vid.artist}
                      </p>
                    </div>
                    <div className={`flex items-center justify-between text-[11px] ${themeConfig.textMuted} mt-2`}>
                      <span className="truncate max-w-[150px] flex items-center gap-1">
                        <Folder className="w-3 h-3 text-cyan-500" />
                        {vid.folder.split('/').pop()}
                      </span>
                      <span>{vid.fileSize || 'HD'}</span>
                    </div>
                  </div>
                </div>
              </React.Fragment>
            );
          })}
        </div>
      ) : (
        /* List View */
        <div className="space-y-2">
          {videos.map((vid) => {
            const isSelected = selectedIds.has(vid.id);

            return (
              <div
                key={vid.id}
                onMouseDown={() => {
                  if (isSelectionMode) return;
                  if (longPressTimer.current) clearTimeout(longPressTimer.current);
                  longPressTimer.current = setTimeout(() => {
                    setIsSelectionMode(true);
                    setSelectedIds(new Set([vid.id]));
                  }, 650);
                }}
                onMouseUp={handleEndLongPress}
                onMouseLeave={handleEndLongPress}
                onTouchStart={(e) => handleTouchStart(e, vid)}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
                onTouchCancel={handleTouchEnd}
                onContextMenu={(e) => {
                  if (!isSelectionMode) e.preventDefault();
                }}
                onClick={() => {
                  if (isSelectionMode) toggleSelect(vid.id);
                  else onSelectVideo(vid);
                }}
                className={`group flex items-center justify-between p-2.5 rounded-2xl border cursor-pointer transition select-none ${
                  isSelected
                    ? 'bg-cyan-500/15 border-cyan-500'
                    : `${themeConfig.cardBg} ${themeConfig.cardHover} ${themeConfig.cardBorder} hover:border-cyan-500/30`
                }`}
              >
                {isSelectionMode && (
                  <button onClick={() => toggleSelect(vid.id)} className="p-1 mr-2 text-cyan-500">
                    {isSelected ? (
                      <CheckSquare className="w-5 h-5 text-cyan-500 fill-cyan-500/20" />
                    ) : (
                      <Square className={`w-5 h-5 ${themeConfig.textMuted}`} />
                    )}
                  </button>
                )}

                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className={`relative w-20 h-13 rounded-xl overflow-hidden shrink-0 ${themeConfig.isDark ? 'bg-neutral-800' : 'bg-slate-200'}`}>
                    <img
                      src={vid.artworkUrl}
                      alt={vid.title}
                      loading="lazy"
                      decoding="async"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/app-icon.png';
                      }}
                      className="w-full h-full object-cover group-hover:scale-105 transition"
                    />
                    <span className="absolute bottom-1 right-1 text-[9px] font-mono font-bold bg-black/80 px-1 py-0.2 rounded text-white">
                      {formatDuration(vid.duration)}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className={`text-sm font-semibold ${themeConfig.textPrimary} group-hover:${themeConfig.accentText} truncate`}>
                      {vid.title}
                    </h4>
                    <p className={`text-xs ${themeConfig.textSecondary} truncate mt-0.5`}>
                      {vid.artist} • {vid.folder.split('/').pop()}
                    </p>
                  </div>
                </div>

                {!isSelectionMode && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(vid.id);
                      }}
                      className={`p-2 ${themeConfig.textSecondary} hover:text-rose-500 transition`}
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          vid.isFavorite ? 'text-rose-500 fill-rose-500' : ''
                        }`}
                      />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setVideoToDelete(vid);
                      }}
                      className={`p-2 ${themeConfig.textSecondary} hover:text-rose-400 transition`}
                      title="Delete Video"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {videos.length === 0 && (
        <div className="text-center py-12 text-neutral-400">
          <Film className="w-12 h-12 mx-auto mb-3 text-neutral-600" />
          <h4 className="text-sm font-semibold text-neutral-300">No videos found</h4>
          <p className="text-xs text-neutral-500 mt-1">
            Import video files using the Scan icon in the top header.
          </p>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      {videoToDelete && (
        <div className={`fixed inset-0 z-60 ${themeConfig.isDark ? 'bg-black/80' : 'bg-black/50'} flex items-center justify-center p-4`}>
          <div className={`${themeConfig.modalBg} border border-rose-500/30 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-3`}>
            <h4 className={`text-sm font-bold ${themeConfig.textPrimary}`}>Delete Video File?</h4>
            <p className={`text-xs ${themeConfig.textSecondary}`}>
              Are you sure you want to remove <strong className={themeConfig.textPrimary}>"{videoToDelete.title}"</strong> from your library?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setVideoToDelete(null)}
                className={`px-3 py-1.5 rounded-xl text-xs ${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`}
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteVideo(videoToDelete.id);
                  setVideoToDelete(null);
                }}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-rose-500 hover:bg-rose-600 text-white"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Batch Delete Confirmation Dialog */}
      {showBatchDeleteConfirm && (
        <div className={`fixed inset-0 z-60 ${themeConfig.isDark ? 'bg-black/80' : 'bg-black/50'} flex items-center justify-center p-4`}>
          <div className={`${themeConfig.modalBg} border border-rose-500/30 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-3`}>
            <h4 className={`text-sm font-bold ${themeConfig.textPrimary}`}>Delete {selectedIds.size} Videos?</h4>
            <p className={`text-xs ${themeConfig.textSecondary}`}>
              Are you sure you want to delete these {selectedIds.size} selected videos from your library?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowBatchDeleteConfirm(false)}
                className={`px-3 py-1.5 rounded-xl text-xs ${themeConfig.textSecondary} hover:${themeConfig.textPrimary}`}
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmBatchDelete}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-rose-500 hover:bg-rose-600 text-white"
              >
                Delete Selected
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
