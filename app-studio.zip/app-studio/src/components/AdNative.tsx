import React, { useState, useEffect } from 'react';
import { ADMOB_CONFIG } from '../data/sampleMedia';
import { ExternalLink, Sparkles, RefreshCw, Zap } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface AdNativeProps {
  isOnline: boolean;
  isAdsRemoved: boolean;
}

const NATIVE_ADS = [
  {
    id: 'native-btc',
    brand: 'MEXC',
    title: 'Grow BTC While You Sleep',
    subtitle: 'Stake USDT to earn BTC Enjoy up to 600% APR',
    cta: 'Start Now',
    url: 'https://mexc.com',
    type: 'crypto',
    badge: 'Sponsored',
    gradient: 'from-blue-600 to-indigo-700'
  },
  {
    id: 'native-sound',
    brand: 'LERZA AUDIO',
    title: 'Unlock 3D Studio Sound & Bass',
    subtitle: 'High-res lossless audio engine with 10-band equalizer',
    cta: 'Boost Audio',
    url: 'https://play.google.com/store/apps',
    type: 'audio',
    badge: 'Trending Audio AI',
    gradient: 'from-cyan-500 to-teal-500'
  },
  {
    id: 'native-vocal',
    brand: 'AI MUSIC',
    title: 'Isolate Vocals & Instrumentals',
    subtitle: 'Separate acapellas and beats in seconds with lossless AI',
    cta: 'Try Free',
    url: 'https://play.google.com/store/apps',
    type: 'music',
    badge: 'Editor Choice',
    gradient: 'from-purple-600 to-pink-600'
  }
];

export const AdNative: React.FC<AdNativeProps> = ({ isOnline, isAdsRemoved }) => {
  const { config: themeConfig } = useTheme();
  const [adIdx, setAdIdx] = useState(0);

  // Rotate native ad every 40 seconds
  useEffect(() => {
    if (!isOnline || isAdsRemoved) return;
    const timer = setInterval(() => {
      setAdIdx((prev) => (prev + 1) % NATIVE_ADS.length);
    }, 40000);
    return () => clearInterval(timer);
  }, [isOnline, isAdsRemoved]);

  if (!isOnline || isAdsRemoved) {
    return null;
  }

  const ad = NATIVE_ADS[adIdx];

  const handleOpen = (url: string) => {
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch {
      window.location.href = url;
    }
  };

  return (
    <div className="my-3 overflow-hidden rounded-2xl bg-neutral-950 border border-neutral-800 shadow-xl relative text-white">
      {/* Background ambient lighting */}
      <div className="absolute -top-12 -right-12 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="p-4 sm:p-5 relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        {/* Left Side: Brand Logo, Title, Subtitle, CTA Button */}
        <div className="flex-1 min-w-0 pr-2">
          {/* Brand header */}
          <div className="flex items-center gap-2 mb-2">
            <div className="w-5 h-5 rounded-md bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 text-[10px] font-black">
              <Zap className="w-3 h-3 fill-cyan-400" />
            </div>
            <span className="text-xs font-black tracking-wider text-cyan-400">
              {ad.brand}
            </span>
          </div>

          {/* Main Headline (matches screenshot) */}
          <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-tight mb-1.5">
            {ad.title}
          </h3>

          {/* Subtext */}
          <p className="text-xs sm:text-sm font-semibold text-amber-400 mb-4 max-w-sm leading-snug">
            {ad.subtitle}
          </p>

          {/* CTA Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleOpen(ad.url)}
              className="px-5 py-2 rounded-xl bg-white hover:bg-neutral-100 text-neutral-950 font-black text-xs sm:text-sm shadow-lg active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>{ad.cta}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>

            {/* Switch Ad button */}
            <button
              type="button"
              title="Next Sponsor"
              onClick={() => setAdIdx((prev) => (prev + 1) % NATIVE_ADS.length)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition active:scale-95"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right Side: 3D Illustration matching screenshot */}
        <div className="self-end sm:self-center shrink-0 flex items-center justify-center relative">
          <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-2xl bg-gradient-to-tr from-cyan-950/60 to-indigo-950/60 border border-white/10 flex flex-col items-center justify-center p-2 relative overflow-hidden shadow-inner">
            {/* 3D Arrow and coins visual */}
            <div className="absolute top-2 right-2 text-cyan-400 animate-pulse">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M7 17L17 7M17 7H7M17 7V17" />
              </svg>
            </div>
            <div className="text-4xl sm:text-5xl mb-1">🤖</div>
            <div className="flex items-center gap-1">
              <span className="text-xs font-black text-amber-400">💰 600%</span>
              <span className="text-[10px] text-cyan-300 font-bold">APR</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Ad Tag (Matching screenshot Ad indicator) */}
      <div className="px-4 py-1 bg-black/40 border-t border-white/5 flex items-center justify-between text-[10px] text-neutral-400">
        <div className="flex items-center gap-1.5">
          <span className="bg-cyan-500/20 text-cyan-400 font-bold px-1.5 py-0.2 rounded text-[9px]">
            AD
          </span>
          <span className="font-medium text-neutral-400">Google AdMob Native Sponsored</span>
        </div>
        <span className="font-mono text-neutral-500 text-[9px]">{ADMOB_CONFIG.nativeUnitId}</span>
      </div>
    </div>
  );
};

