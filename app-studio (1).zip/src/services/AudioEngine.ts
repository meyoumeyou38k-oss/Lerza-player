/**
 * Real Web Audio API & MediaSession service for Lerza Player.
 * Connects Equalizer BiquadFilter nodes, MediaSession lock screen notifications,
 * and audio effects.
 */

class AudioEngineService {
  private audioCtx: AudioContext | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private filters: BiquadFilterNode[] = [];
  private bassFilter: BiquadFilterNode | null = null;
  private volumeGainNode: GainNode | null = null;
  private currentMediaElement: HTMLMediaElement | null = null;
  private isInitialized = false;
  private currentVolumeMultiplier = 1.0; // 1.0 = 100%, 1.5 = 150%, 2.0 = 200%, 3.0 = 300%

  // Frequencies for the 5-band equalizer
  private readonly frequencies = [60, 230, 910, 3600, 14000];

  public init(mediaElement: HTMLMediaElement) {
    try {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!this.audioCtx) {
        this.audioCtx = new AudioCtxClass();
      }

      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }

      if (this.currentMediaElement === mediaElement && this.isInitialized && this.sourceNode) {
        return;
      }

      this.currentMediaElement = mediaElement;

      // Connect source node only once per media element
      if (!this.sourceNode) {
        try {
          this.sourceNode = this.audioCtx.createMediaElementSource(mediaElement);
        } catch (sourceErr) {
          console.warn('createMediaElementSource notice:', sourceErr);
        }
      }

      if (!this.sourceNode) {
        return;
      }

      // Build 5-band filter chain
      this.filters = this.frequencies.map((freq, index) => {
        const filter = this.audioCtx!.createBiquadFilter();
        if (index === 0) {
          filter.type = 'lowshelf';
        } else if (index === this.frequencies.length - 1) {
          filter.type = 'highshelf';
        } else {
          filter.type = 'peaking';
          filter.Q.value = 1.0;
        }
        filter.frequency.value = freq;
        filter.gain.value = 0;
        return filter;
      });

      // Bass boost filter
      this.bassFilter = this.audioCtx.createBiquadFilter();
      this.bassFilter.type = 'lowshelf';
      this.bassFilter.frequency.value = 100;
      this.bassFilter.gain.value = 0;

      // Volume booster GainNode (Allows 100% to 300% amplification)
      this.volumeGainNode = this.audioCtx.createGain();
      this.volumeGainNode.gain.value = this.currentVolumeMultiplier;

      // Chain: Source -> Filter0 -> Filter1 ... -> Bass -> VolumeBoost Gain -> Destination
      let lastNode: AudioNode = this.sourceNode;
      this.filters.forEach(filter => {
        lastNode.connect(filter);
        lastNode = filter;
      });

      lastNode.connect(this.bassFilter);
      this.bassFilter.connect(this.volumeGainNode);
      this.volumeGainNode.connect(this.audioCtx.destination);

      this.isInitialized = true;
    } catch (err) {
      console.warn('AudioEngine Web Audio setup warning (fallback to native audio):', err);
    }
  }

  public setVolumeMultiplier(multiplier: number) {
    this.currentVolumeMultiplier = multiplier;
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      try { this.audioCtx.resume(); } catch {}
    }
    if (this.volumeGainNode && this.audioCtx) {
      try {
        this.volumeGainNode.gain.setValueAtTime(multiplier, this.audioCtx.currentTime);
      } catch {
        this.volumeGainNode.gain.value = multiplier;
      }
    }
  }

  public getVolumeMultiplier(): number {
    return this.currentVolumeMultiplier;
  }

  public setBandGain(bandIndex: number, gainDb: number) {
    if (this.filters[bandIndex]) {
      this.filters[bandIndex].gain.value = gainDb;
    }
  }

  public setAllBands(gains: number[]) {
    gains.forEach((gain, idx) => {
      this.setBandGain(idx, gain);
    });
  }

  public setBassBoost(levelPercent: number) {
    if (this.bassFilter) {
      this.bassFilter.gain.value = (levelPercent / 100) * 12;
    }
  }

  public setPlaybackState(state: 'none' | 'paused' | 'playing') {
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.playbackState = state;
      } catch (e) {
        console.warn('MediaSession playbackState error:', e);
      }
    }
  }

  public updatePositionState(params: { duration: number; position: number; playbackRate?: number }) {
    if ('mediaSession' in navigator && 'setPositionState' in navigator.mediaSession) {
      try {
        const safeDuration = Math.max(1, params.duration || 1);
        const safePos = Math.max(0, Math.min(params.position || 0, safeDuration));
        navigator.mediaSession.setPositionState({
          duration: safeDuration,
          playbackRate: params.playbackRate || 1.0,
          position: safePos
        });
      } catch (e) {
        // Ignored if not yet supported
      }
    }
  }

  public updateMediaSession(params: {
    title: string;
    artist: string;
    album: string;
    artworkUrl: string;
    isPlaying?: boolean;
    onPlay: () => void;
    onPause: () => void;
    onNext: () => void;
    onPrev: () => void;
    onSeek: (seconds: number) => void;
  }) {
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: params.title || 'Lerza Track',
          artist: params.artist || 'Lerza Player',
          album: params.album || 'Lerza Music',
          artwork: [
            { src: params.artworkUrl || '/app-icon.png', sizes: '96x96', type: 'image/png' },
            { src: params.artworkUrl || '/app-icon.png', sizes: '192x192', type: 'image/png' },
            { src: params.artworkUrl || '/app-icon.png', sizes: '512x512', type: 'image/png' }
          ]
        });

        navigator.mediaSession.setActionHandler('play', params.onPlay);
        navigator.mediaSession.setActionHandler('pause', params.onPause);
        navigator.mediaSession.setActionHandler('nexttrack', params.onNext);
        navigator.mediaSession.setActionHandler('previoustrack', params.onPrev);

        navigator.mediaSession.setActionHandler('seekto', (details) => {
          if (details.seekTime !== undefined) {
            params.onSeek(details.seekTime);
          }
        });

        navigator.mediaSession.setActionHandler('seekbackward', (details) => {
          const skipTime = details.seekOffset || 10;
          if (this.currentMediaElement) {
            params.onSeek(Math.max(0, this.currentMediaElement.currentTime - skipTime));
          }
        });

        navigator.mediaSession.setActionHandler('seekforward', (details) => {
          const skipTime = details.seekOffset || 10;
          if (this.currentMediaElement) {
            params.onSeek(this.currentMediaElement.currentTime + skipTime);
          }
        });

        if (params.isPlaying !== undefined) {
          navigator.mediaSession.playbackState = params.isPlaying ? 'playing' : 'paused';
        }
      } catch (err) {
        console.warn('MediaSession configuration notice:', err);
      }
    }
  }
}

export const AudioEngine = new AudioEngineService();
