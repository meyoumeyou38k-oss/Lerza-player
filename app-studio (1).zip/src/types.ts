export interface LyricLine {
  time: number; // in seconds
  text: string;
}

export interface MediaTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  artworkUrl: string;
  audioUrl: string;
  videoUrl?: string; // If track has corresponding MV
  hasMV: boolean;
  lyrics?: LyricLine[];
  genre: string;
  dateAdded: number;
  playCount: number;
  folder: string;
  isFavorite: boolean;
  fileSize?: string;
  fileFormat?: 'MP3' | 'FLAC' | 'AAC' | 'MP4' | 'MKV' | 'WEBM';
  filePath?: string;
  isVideoOnly?: boolean;
}

export type CategoryTab = 'videos' | 'songs' | 'playlists' | 'folders' | 'albums' | 'artists';

export interface Playlist {
  id: string;
  title: string;
  description?: string;
  trackIds: string[];
  createdAt: number;
  artworkUrl?: string;
}

export type RepeatMode = 'off' | 'all' | 'one';
export type PlayerDisplayMode = 'audio' | 'video';

export interface EqualizerBand {
  frequency: number;
  label: string;
  gain: number; // -12 to 12 dB
}

export type EqualizerPresetName = 'flat' | 'bass_boost' | 'pop' | 'rock' | 'vocal' | 'jazz' | 'electronic';

export interface AdConfig {
  appId: string;
  bannerUnitId: string;
  nativeUnitId: string;
  interstitialUnitId: string;
}

export type ThemeMode = 'dark' | 'light' | 'pink' | 'green' | 'purple' | 'sky' | 'amber';

export interface AppSettings {
  theme: ThemeMode;
  customWallpaper: string | null; // Data URL or null
  wallpaperOpacity: number; // 0.1 to 0.5 (default 0.25)
  isAdsRemoved: boolean;
  resumePlayback: boolean;
  audioCrossfade: number; // 0-10 seconds
  sleepTimerMinutes: number | null; // null = off
  playbackSpeed: number; // 0.5, 0.75, 1, 1.25, 1.5, 2.0
  bassBoostLevel: number; // 0-100%
  virtualizerEnabled: boolean;
  filterWhatsAppAndRecordings: boolean; // Hide WhatsApp voice notes and call recordings
  minAudioDurationFilter: number; // Hide short audios < 15 seconds (voice notes)
  language: 'en' | 'ur' | 'hi';
}
