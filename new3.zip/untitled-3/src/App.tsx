import React, { useState, useRef, useEffect } from 'react';
import { 
  MediaTrack, 
  Playlist, 
  CategoryTab, 
  RepeatMode, 
  PlayerDisplayMode, 
  AppSettings 
} from './types';
import { 
  INITIAL_TRACKS, 
  INITIAL_PLAYLISTS, 
  EQUALIZER_PRESETS 
} from './data/sampleMedia';
import { AudioEngine } from './services/AudioEngine';

import { Header } from './components/Header';
import { CategoryChips } from './components/CategoryChips';
import { AdBanner } from './components/AdBanner';
import { SongsList } from './components/SongsList';
import { VideosList } from './components/VideosList';
import { PlaylistsView } from './components/PlaylistsView';
import { FoldersAlbumsArtistsView } from './components/FoldersAlbumsArtistsView';
import { MiniPlayer } from './components/MiniPlayer';
import { FullScreenPlayer } from './components/FullScreenPlayer';
import { LyricsModal } from './components/LyricsModal';
import { EqualizerModal } from './components/EqualizerModal';
import { QueueDrawer } from './components/QueueDrawer';
import { SettingsModal } from './components/SettingsModal';
import { AddToPlaylistModal } from './components/AddToPlaylistModal';
import { AdInterstitialModal } from './components/AdInterstitialModal';
import { PermissionModal } from './components/PermissionModal';
import { UpdateModal, UpdateInfo } from './components/UpdateModal';
import { ThemeProvider } from './context/ThemeContext';
import { getThemeConfig } from './utils/theme';

export default function App() {
  // --- Persistent & Core States ---
  const [tracks, setTracks] = useState<MediaTrack[]>(() => {
    const saved = localStorage.getItem('lerza_tracks') || localStorage.getItem('fz_tracks');
    if (saved) {
      try {
        const parsed: MediaTrack[] = JSON.parse(saved);
        const demoIds = ['track-1', 'track-2', 'track-3', 'track-4', 'track-5', 'video-1', 'video-2'];
        const filtered = parsed.filter(t => !demoIds.includes(t.id));
        return filtered.map((t) => {
          const updated = { ...t };
          if (updated.videoUrl && updated.videoUrl.includes('commondatastorage.googleapis.com')) {
            updated.videoUrl = 'https://www.w3schools.com/html/mov_bbb.mp4';
          }
          if (updated.audioUrl && updated.audioUrl.includes('commondatastorage.googleapis.com')) {
            updated.audioUrl = 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3';
          }
          return updated;
        });
      } catch {
        return INITIAL_TRACKS;
      }
    }
    return INITIAL_TRACKS;
  });

  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    const saved = localStorage.getItem('lerza_playlists') || localStorage.getItem('fz_playlists');
    return saved ? JSON.parse(saved) : INITIAL_PLAYLISTS;
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('lerza_settings') || localStorage.getItem('fz_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.warn('Settings parse warning:', e);
      }
    }
    return {
      theme: 'light',
      isAdsRemoved: false,
      resumePlayback: true,
      audioCrossfade: 0,
      sleepTimerMinutes: null,
      playbackSpeed: 1.0,
      bassBoostLevel: 30,
      virtualizerEnabled: false,
      filterWhatsAppAndRecordings: true,
      minAudioDurationFilter: 15,
      language: 'en'
    };
  });

  const [activeTab, setActiveTab] = useState<CategoryTab>('songs');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(true);

  // --- Playback State ---
  const [currentTrack, setCurrentTrack] = useState<MediaTrack | null>(tracks[0] || null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(tracks[0]?.duration || 0);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('all');
  const [isShuffle, setIsShuffle] = useState(false);
  const [displayMode, setDisplayMode] = useState<PlayerDisplayMode>('audio');
  
  // --- Queue State ---
  const [queue, setQueue] = useState<MediaTrack[]>(tracks);
  const [queueIndex, setQueueIndex] = useState(0);

  // --- Modals & Views ---
  const [isFullScreenOpen, setIsFullScreenOpen] = useState(false);
  const [isLyricsOpen, setIsLyricsOpen] = useState(false);
  const [isEqualizerOpen, setIsEqualizerOpen] = useState(false);
  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPermissionModalOpen, setIsPermissionModalOpen] = useState(false);
  const [trackForPlaylistModal, setTrackForPlaylistModal] = useState<MediaTrack | null>(null);

  // --- Equalizer State ---
  const [eqBands, setEqBands] = useState<number[]>([0, 0, 0, 0, 0]);
  const [activeEqPreset, setActiveEqPreset] = useState<string>('flat');
  const [volumeMultiplier, setVolumeMultiplier] = useState<number>(1.0);

  // --- Interstitial Ad State ---
  const [isInterstitialOpen, setIsInterstitialOpen] = useState(false);
  const [hasShownSessionInterstitial, setHasShownSessionInterstitial] = useState(false);

  // --- App Version ---
  const APP_VERSION = '1.0.1';
  const APP_BUILD = 101;
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [updateInfo, setUpdateInfo] = useState<UpdateInfo | null>(null);
  const [, setIsCheckingUpdate] = useState(false);

  // --- Gesture & Smooth Drag References ---
  const playerContainerRef = useRef<HTMLDivElement | null>(null);
  const touchStartYRef = useRef<number>(0);
  const touchStartXRef = useRef<number>(0);
  const currentDragXRef = useRef<number>(0);
  const currentDragYRef = useRef<number>(0);
  const [isDragging, setIsDragging] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hiddenImportInputRef = useRef<HTMLInputElement>(null);

  const checkForUpdates = async (isManual = false) => {
    try {
      setIsCheckingUpdate(true);
      const res = await fetch(`/update-check.json?t=${Date.now()}`);
      if (!res.ok) throw new Error('Update manifest not reachable');
      const data: UpdateInfo = await res.json();
      if (data && data.versionCode > APP_BUILD) {
        setUpdateInfo(data);
        setIsUpdateModalOpen(true);
      } else if (isManual) {
        alert(`آپ کے پاس Lerza Player کا تازہ ترین ورژن (v${APP_VERSION}) موجود ہے!`);
      }
    } catch (err) {
      console.warn('Update check warning:', err);
    } finally {
      setIsCheckingUpdate(false);
    }
  };

  const handleScanAndImport = () => {
    if ((window as any).AndroidBridge?.scanLocalAudio) {
      try {
        (window as any).AndroidBridge.scanLocalAudio();
        if ((window as any).AndroidBridge.scanLocalVideos) {
          (window as any).AndroidBridge.scanLocalVideos();
        }
      } catch (e) {
        console.warn('Native scan trigger notice:', e);
      }
    }
    hiddenImportInputRef.current?.click();
  };

  const handleImportedLocalFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const imported: MediaTrack[] = [];
    Array.from(files).forEach((file, idx) => {
      const url = URL.createObjectURL(file);
      const isVid = file.type.startsWith('video');
      imported.push({
        id: `imported-${Date.now()}-${idx}`,
        title: file.name.replace(/\.[^/.]+$/, ''),
        artist: 'Device Storage',
        album: isVid ? 'Imported Videos' : 'Imported Music',
        duration: 0,
        audioUrl: isVid ? undefined : url,
        videoUrl: isVid ? url : undefined,
        artworkUrl: isVid ? undefined : '/app-icon.png',
        hasMV: isVid,
        isVideoOnly: isVid,
        genre: isVid ? 'Video' : 'Audio',
        dateAdded: Date.now(),
        playCount: 0,
        folder: 'Imported',
        isFavorite: false,
        fileFormat: isVid ? 'MP4' : 'MP3'
      });
    });
    setTracks(prev => [...imported, ...prev]);
    setQueue(prev => [...imported, ...prev]);
    if (e.target) e.target.value = '';
  };

  const sanitizeTracksForStorage = (list: MediaTrack[]): MediaTrack[] => {
    return list.map(t => ({
      id: String(t.id),
      title: String(t.title || ''),
      artist: String(t.artist || ''),
      album: String(t.album || ''),
      duration: Number(t.duration) || 0,
      artworkUrl: String(t.artworkUrl || ''),
      audioUrl: String(t.audioUrl || ''),
      videoUrl: t.videoUrl ? String(t.videoUrl) : undefined,
      hasMV: Boolean(t.hasMV),
      lyrics: Array.isArray(t.lyrics) ? t.lyrics : undefined,
      genre: String(t.genre || ''),
      dateAdded: Number(t.dateAdded) || Date.now(),
      playCount: Number(t.playCount) || 0,
      folder: String(t.folder || ''),
      isFavorite: Boolean(t.isFavorite),
      fileSize: t.fileSize ? String(t.fileSize) : undefined,
      fileFormat: t.fileFormat,
      isVideoOnly: Boolean(t.isVideoOnly)
    }));
  };

  const safeStringify = (data: unknown): string => {
    const seen = new WeakSet();
    return JSON.stringify(data, (key, value) => {
      if (typeof value === 'object' && value !== null) {
        if (typeof Node !== 'undefined' && value instanceof Node) return undefined;
        if (typeof window !== 'undefined' && (value === window || value === document)) return undefined;
        if (seen.has(value)) return undefined;
        seen.add(value);
      }
      return value;
    });
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const customOrFavorites = tracks.filter(t => t.isFavorite || t.id.startsWith('local-') || !t.id.startsWith('android-media-'));
        const toSave = customOrFavorites.length > 0 ? customOrFavorites.slice(0, 60) : tracks.slice(0, 40);
        const sanitized = sanitizeTracksForStorage(toSave);
        localStorage.setItem('lerza_tracks', safeStringify(sanitized));
      } catch (e) {
        console.warn('Tracks storage warning handled gracefully:', e);
      }
    }, 1200);

    return () => clearTimeout(timer);
  }, [tracks]);

  useEffect(() => {
    try {
      localStorage.setItem('lerza_playlists', safeStringify(playlists));
    } catch (e) {}
  }, [playlists]);

  useEffect(() => {
    try {
      localStorage.setItem('lerza_settings', safeStringify(settings));
    } catch (e) {}
  }, [settings]);

  useEffect(() => {
    if (typeof navigator !== 'undefined' && 'onLine' in navigator) {
      setIsOnline(navigator.onLine);
    }
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // --- Header Smooth Scroll Animation State ---
  const [headerTranslateY, setHeaderTranslateY] = useState(0);
  const [headerOpacity, setHeaderOpacity] = useState(1);
  const lastScrollTopRef = useRef(0);
  const [exitToastVisible, setExitToastVisible] = useState(false);
  const lastBackPressTimeRef = useRef(0);

  // Lark Player-Style Proportional Smooth Finger-Tracking Header Hide Logic
  const handleMainScroll = (e: React.UIEvent<HTMLElement>) => {
    const currentScrollY = e.currentTarget.scrollTop;
    const HEADER_HEIGHT = 100; // Header ki total height pixel mein

    if (currentScrollY <= 0) {
      setHeaderTranslateY(0);
      setHeaderOpacity(1);
    } else if (currentScrollY < HEADER_HEIGHT) {
      // Finger scroll movement ke sath proportional hide animation
      const progress = currentScrollY / HEADER_HEIGHT;
      setHeaderTranslateY(-currentScrollY);
      setHeaderOpacity(1 - progress);
    } else {
      setHeaderTranslateY(-HEADER_HEIGHT);
      setHeaderOpacity(0);
    }

    lastScrollTopRef.current = currentScrollY;
  };

  // --- Ultra Smooth Finger Tracking Touch Gestures (Swipe Next/Prev & Dismiss) ---
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    touchStartYRef.current = e.touches[0].clientY;
    touchStartXRef.current = e.touches[0].clientX;
    currentDragXRef.current = 0;
    currentDragYRef.current = 0;
    setIsDragging(true);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const deltaX = e.touches[0].clientX - touchStartXRef.current;
    const deltaY = e.touches[0].clientY - touchStartYRef.current;

    currentDragXRef.current = deltaX;
    currentDragYRef.current = deltaY;

    if (playerContainerRef.current) {
      if (isFullScreenOpen) {
        // Drag down to collapse full player
        if (deltaY > 0) {
          playerContainerRef.current.style.transform = `translate3d(0, ${deltaY}px, 0)`;
          playerContainerRef.current.style.opacity = `${Math.max(0.3, 1 - deltaY / 400)}`;
        }
      } else {
        // Horizontal track swipe with finger tracking
        if (Math.abs(deltaX) > Math.abs(deltaY)) {
          playerContainerRef.current.style.transform = `translate3d(${deltaX}px, 0, 0)`;
        }
      }
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    const deltaX = currentDragXRef.current;
    const deltaY = currentDragYRef.current;

    if (playerContainerRef.current) {
      playerContainerRef.current.style.transition = 'transform 0.25s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.25s ease';
      
      if (isFullScreenOpen && deltaY > 120) {
        setIsFullScreenOpen(false);
      } else if (!isFullScreenOpen && Math.abs(deltaX) > 80) {
        if (deltaX < 0) {
          handleNext();
        } else {
          handlePrev();
        }
      }

      // Reset transforms
      playerContainerRef.current.style.transform = 'translate3d(0, 0, 0)';
      playerContainerRef.current.style.opacity = '1';

      setTimeout(() => {
        if (playerContainerRef.current) {
          playerContainerRef.current.style.transition = '';
        }
      }, 260);
    }
  };

  const handlePlay = () => {
    if (displayMode === 'video' && videoRef.current && currentTrack?.videoUrl) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    } else if (audioRef.current && currentTrack && (currentTrack.audioUrl || currentTrack.videoUrl)) {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    }
  };

  const handlePause = () => {
    if (audioRef.current) audioRef.current.pause();
    if (videoRef.current) videoRef.current.pause();
    setIsPlaying(false);
  };

  const handleTogglePlay = () => {
    if (isPlaying) handlePause();
    else handlePlay();
  };

  const playTrack = (track: MediaTrack, newMode?: PlayerDisplayMode) => {
    setCurrentTrack(track);
    setCurrentTime(0);

    const mode = newMode || (track.isVideoOnly ? 'video' : 'audio');
    setDisplayMode(mode);

    const qIdx = queue.findIndex(t => t.id === track.id);
    if (qIdx !== -1) {
      setQueueIndex(qIdx);
    } else {
      setQueue([track, ...queue]);
      setQueueIndex(0);
    }

    setTracks(prev => prev.map(t => t.id === track.id ? { ...t, playCount: t.playCount + 1 } : t));

    setTimeout(() => {
      if (mode === 'video' && videoRef.current && track.videoUrl) {
        videoRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
      } else if (audioRef.current && (track.audioUrl || track.videoUrl)) {
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
      }
    }, 100);
  };

  const handleNext = () => {
    if (queue.length === 0) return;
    let nextIdx = queueIndex + 1;
    if (isShuffle) {
      nextIdx = Math.floor(Math.random() * queue.length);
    } else if (nextIdx >= queue.length) {
      if (repeatMode === 'all') nextIdx = 0;
      else {
        handlePause();
        return;
      }
    }
    setQueueIndex(nextIdx);
    playTrack(queue[nextIdx]);
  };

  const handlePrev = () => {
    if (currentTime > 3) {
      handleSeek(0);
      return;
    }
    let prevIdx = queueIndex - 1;
    if (prevIdx < 0) {
      prevIdx = queue.length - 1;
    }
    setQueueIndex(prevIdx);
    playTrack(queue[prevIdx]);
  };

  const handleSeek = (seconds: number) => {
    if (!Number.isFinite(seconds) || seconds < 0) return;
    const targetSeconds = Math.max(0, seconds);
    setCurrentTime(targetSeconds);

    if (displayMode === 'video' && videoRef.current) {
      videoRef.current.currentTime = targetSeconds;
    } else if (audioRef.current) {
      audioRef.current.currentTime = targetSeconds;
    }
  };

  const handleToggleDisplayMode = () => {
    if (!currentTrack || !currentTrack.hasMV) return;
    const newMode: PlayerDisplayMode = displayMode === 'audio' ? 'video' : 'audio';
    const savedTime = currentTime;
    const wasPlaying = isPlaying;

    setDisplayMode(newMode);

    setTimeout(() => {
      if (newMode === 'video' && videoRef.current) {
        if (audioRef.current) audioRef.current.pause();
        videoRef.current.currentTime = savedTime;
        if (wasPlaying) videoRef.current.play();
      } else if (newMode === 'audio' && audioRef.current) {
        if (videoRef.current) videoRef.current.pause();
        audioRef.current.currentTime = savedTime;
        if (wasPlaying) audioRef.current.play();
      }
    }, 50);
  };

  const handleToggleFavorite = (trackId: string) => {
    setTracks(prev => prev.map(t => t.id === trackId ? { ...t, isFavorite: !t.isFavorite } : t));
    if (currentTrack?.id === trackId) {
      setCurrentTrack(prev => prev ? { ...prev, isFavorite: !prev.isFavorite } : null);
    }
  };

  const handleAddToQueue = (track: MediaTrack) => {
    setQueue(prev => [...prev, track]);
  };

  const handlePlayNext = (track: MediaTrack) => {
    const newQ = [...queue];
    newQ.splice(queueIndex + 1, 0, track);
    setQueue(newQ);
  };

  const handleRemoveFromQueue = (index: number) => {
    setQueue(prev => prev.filter((_, i) => i !== index));
  };

  const handleDeleteTrack = (trackId: string) => {
    if (currentTrack?.id === trackId) {
      handlePause();
      const remaining = tracks.filter(t => t.id !== trackId);
      setCurrentTrack(remaining.length > 0 ? remaining[0] : null);
    }

    setTracks(prev => prev.filter(t => t.id !== trackId));
    setQueue(prev => prev.filter(t => t.id !== trackId));
  };

  const handleDeleteMultipleTracks = (trackIds: string[]) => {
    const idSet = new Set(trackIds);
    if (currentTrack && idSet.has(currentTrack.id)) {
      handlePause();
      const remaining = tracks.filter(t => !idSet.has(t.id));
      setCurrentTrack(remaining.length > 0 ? remaining[0] : null);
    }

    setTracks(prev => prev.filter(t => !idSet.has(t.id)));
    setQueue(prev => prev.filter(t => !idSet.has(t.id)));
  };

  const handleClearDemoTracks = () => {
    const userOnly = tracks.filter(t => !t.id.startsWith('sample-'));
    setTracks(userOnly);
    setQueue(userOnly);
    if (currentTrack && currentTrack.id.startsWith('sample-')) {
      handlePause();
      setCurrentTrack(userOnly.length > 0 ? userOnly[0] : null);
    }
  };

  const handleCreatePlaylist = (title: string, description: string) => {
    const newPl: Playlist = {
      id: `pl-${Date.now()}`,
      title,
      description,
      trackIds: [],
      createdAt: Date.now()
    };
    setPlaylists(prev => [newPl, ...prev]);
  };

  const handleDeletePlaylist = (playlistId: string) => {
    setPlaylists(prev => prev.filter(p => p.id !== playlistId));
  };

  const handlePlayPlaylist = (playlist: Playlist, shuffle = false) => {
    const pTracks = tracks.filter(t => playlist.trackIds.includes(t.id));
    if (pTracks.length === 0) return;
    setQueue(pTracks);
    setIsShuffle(shuffle);
    const startIdx = shuffle ? Math.floor(Math.random() * pTracks.length) : 0;
    setQueueIndex(startIdx);
    playTrack(pTracks[startIdx]);
  };

  const handleAddTrackToPlaylist = (playlistId: string, trackId: string) => {
    setPlaylists(prev => prev.map(p => {
      if (p.id === playlistId && !p.trackIds.includes(trackId)) {
        return { ...p, trackIds: [...p.trackIds, trackId] };
      }
      return p;
    }));
  };

  const handleBandGainChange = (idx: number, gain: number) => {
    const updated = [...eqBands];
    updated[idx] = gain;
    setEqBands(updated);
    AudioEngine.setBandGain(idx, gain);
    setActiveEqPreset('custom');
  };

  const handleSelectEqPreset = (presetName: string) => {
    const gains = EQUALIZER_PRESETS[presetName] || [0, 0, 0, 0, 0];
    setEqBands(gains);
    AudioEngine.setAllBands(gains);
    setActiveEqPreset(presetName);
  };

  const handleBassBoostChange = (level: number) => {
    setSettings(prev => ({ ...prev, bassBoostLevel: level }));
    AudioEngine.setBassBoost(level);
  };

  const handleOpenSettings = () => {
    if (!settings.isAdsRemoved && isOnline && !hasShownSessionInterstitial && !isPlaying) {
      setIsInterstitialOpen(true);
      setHasShownSessionInterstitial(true);
    }
    setIsSettingsOpen(true);
  };

  const isWhatsAppOrCallRecording = (t: MediaTrack): boolean => {
    const str = `${t.title} ${t.folder} ${t.artist} ${t.album}`.toLowerCase();
    const isWA = str.includes('whatsapp') || str.includes('ptt-') || /^aud-\d{8}-wa/i.test(t.title);
    const isCall = str.includes('call_rec') || str.includes('call record') || str.includes('voice recorder');
    return isWA || isCall;
  };

  const filteredTracks = tracks.filter(t => {
    if (settings.filterWhatsAppAndRecordings && isWhatsAppOrCallRecording(t)) {
      return false;
    }
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      t.title.toLowerCase().includes(q) ||
      t.artist.toLowerCase().includes(q) ||
      t.album.toLowerCase().includes(q) ||
      t.folder.toLowerCase().includes(q)
    );
  });

  const songsOnly = filteredTracks.filter(t => !t.isVideoOnly);
  const videosOnly = filteredTracks.filter(t => t.isVideoOnly || t.hasMV);

  const folderSet = new Set(filteredTracks.map(t => t.folder));
  const albumSet = new Set(filteredTracks.map(t => t.album));
  const artistSet = new Set(filteredTracks.map(t => t.artist));

  const currentThemeConfig = getThemeConfig(settings.theme);
  const activeWallpaper = settings.customWallpaper || (settings as any).customWallpaperUrl;

  return (
    <ThemeProvider
      theme={settings.theme}
      onThemeChange={(newTheme) => setSettings(prev => ({ ...prev, theme: newTheme }))}
    >
      <div className={`h-screen max-h-screen flex flex-col overflow-hidden relative selection:bg-cyan-500/30 transition-colors duration-300 ${currentThemeConfig.appBg} ${currentThemeConfig.appText}`}>
      {activeWallpaper && (
        <div 
          className="fixed inset-0 pointer-events-none z-0 bg-cover bg-center bg-no-repeat transition-all duration-500"
          style={{
            backgroundImage: `url(${activeWallpaper})`,
            opacity: settings.wallpaperOpacity ?? 0.35,
            filter: 'contrast(1.05) saturate(1.1)'
          }}
        />
      )}

      <audio
        ref={audioRef}
        src={currentTrack ? (currentTrack.audioUrl || currentTrack.videoUrl || undefined) : undefined}
        preload="metadata"
        onTimeUpdate={() => {
          if (audioRef.current && displayMode === 'audio') {
            setCurrentTime(audioRef.current.currentTime);
          }
        }}
        onLoadedMetadata={() => {
          if (audioRef.current) {
            setDuration(audioRef.current.duration || currentTrack?.duration || 0);
          }
        }}
        onEnded={handleNext}
      />

      {/* Header Container with Proportional Finger-Tracking Smooth Animation */}
      <div 
        className="overflow-hidden z-30 shrink-0 pointer-events-auto transition-transform duration-75 ease-out"
        style={{
          transform: `translate3d(0, ${headerTranslateY}px, 0)`,
          opacity: headerOpacity,
          maxHeight: headerOpacity === 0 ? '0px' : 'none'
        }}
      >
        <Header
          onOpenSettings={handleOpenSettings}
          onOpenEqualizer={() => setIsEqualizerOpen(true)}
          onSearchChange={setSearchQuery}
          searchQuery={searchQuery}
          isSearchOpen={isSearchOpen}
          onToggleSearch={(open) => setIsSearchOpen(open !== undefined ? open : !isSearchOpen)}
          isOnline={isOnline}
          onToggleOnline={() => setIsOnline(!isOnline)}
          onFilesImported={(newTracks) => {
            setTracks(prev => [...newTracks, ...prev]);
            setQueue(prev => [...newTracks, ...prev]);
          }}
          totalTracksCount={tracks.length}
        />
      </div>

      <main 
        onScroll={handleMainScroll}
        className="flex-1 overflow-y-auto overscroll-contain min-h-0 relative z-10 pb-36 transition-all duration-300 ease-out"
      >
        <div className="sticky top-0 z-20 border-b border-black/5 dark:border-white/5 bg-white/80 dark:bg-black/80 backdrop-blur-xl shadow-xs">
          <CategoryChips
            activeTab={activeTab}
            onTabChange={setActiveTab}
            counts={{
              songs: songsOnly.length,
              videos: videosOnly.length,
              playlists: playlists.length,
              folders: folderSet.size,
              albums: albumSet.size,
              artists: artistSet.size
            }}
          />
        </div>

        <AdBanner isOnline={isOnline} isAdsRemoved={settings.isAdsRemoved} />

        <div className="px-2 sm:px-4 py-2">
        {activeTab === 'songs' && (
          <SongsList
            songs={songsOnly}
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            onSelectTrack={(t) => {
              playTrack(t, 'audio');
              setIsFullScreenOpen(true);
            }}
            onToggleFavorite={handleToggleFavorite}
            onAddToQueue={handleAddToQueue}
            onPlayNext={handlePlayNext}
            onAddToPlaylistClick={(t) => setTrackForPlaylistModal(t)}
            onDeleteTrack={handleDeleteTrack}
            onDeleteMultipleTracks={handleDeleteMultipleTracks}
            isOnline={isOnline}
            isAdsRemoved={settings.isAdsRemoved}
          />
        )}

        {activeTab === 'videos' && (
          <VideosList
            videos={videosOnly}
            onSelectVideo={(v) => {
              playTrack(v, 'video');
              setIsFullScreenOpen(true);
            }}
            onToggleFavorite={handleToggleFavorite}
            onDeleteVideo={handleDeleteTrack}
            onDeleteMultipleVideos={handleDeleteMultipleTracks}
            isOnline={isOnline}
            isAdsRemoved={settings.isAdsRemoved}
          />
        )}

        {activeTab === 'playlists' && (
          <PlaylistsView
            playlists={playlists}
            allTracks={tracks}
            onCreatePlaylist={handleCreatePlaylist}
            onDeletePlaylist={handleDeletePlaylist}
            onPlayPlaylist={handlePlayPlaylist}
            onSelectTrack={(t) => {
              playTrack(t);
              setIsFullScreenOpen(true);
            }}
          />
        )}

        {(activeTab === 'folders' || activeTab === 'albums' || activeTab === 'artists') && (
          <FoldersAlbumsArtistsView
            type={activeTab}
            tracks={tracks}
            onSelectTrack={(t) => {
              playTrack(t);
              setIsFullScreenOpen(true);
            }}
          />
        )}
        </div>
      </main>

      <input 
        type="file" 
        ref={hiddenImportInputRef} 
        onChange={handleImportedLocalFiles} 
        multiple 
        accept="audio/*,video/*" 
        className="hidden" 
      />

      {/* Swipe & Animation Wrapper Container */}
      <div 
        ref={playerContainerRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className="touch-none will-change-transform"
      >
        {currentTrack && !isFullScreenOpen && (
          <MiniPlayer
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            onTogglePlay={handleTogglePlay}
            onNext={handleNext}
            onPrev={handlePrev}
            onOpenFullPlayer={() => setIsFullScreenOpen(true)}
            onOpenQueue={() => setIsQueueOpen(true)}
            onSeek={handleSeek}
          />
        )}

        {isFullScreenOpen && currentTrack && (
          <FullScreenPlayer
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            repeatMode={repeatMode}
            isShuffle={isShuffle}
            displayMode={displayMode}
            playbackSpeed={settings.playbackSpeed}
            volumeMultiplier={volumeMultiplier}
            isOnline={isOnline}
            isAdsRemoved={settings.isAdsRemoved}
            onTogglePlay={handleTogglePlay}
            onSeek={handleSeek}
            onNext={handleNext}
            onPrev={handlePrev}
            onToggleShuffle={() => setIsShuffle(!isShuffle)}
            onCycleRepeat={() => {
              const modes: RepeatMode[] = ['off', 'all', 'one'];
              const nextMode = modes[(modes.indexOf(repeatMode) + 1) % modes.length];
              setRepeatMode(nextMode);
            }}
            onToggleFavorite={handleToggleFavorite}
            onClose={() => setIsFullScreenOpen(false)}
            onOpenLyrics={() => setIsLyricsOpen(true)}
            onOpenEqualizer={() => setIsEqualizerOpen(true)}
            onOpenQueue={() => setIsQueueOpen(true)}
            onToggleDisplayMode={handleToggleDisplayMode}
            onChangeSpeed={(spd) => {
              setSettings(prev => ({ ...prev, playbackSpeed: spd }));
              if (audioRef.current) audioRef.current.playbackRate = spd;
              if (videoRef.current) videoRef.current.playbackRate = spd;
            }}
            onChangeVolumeMultiplier={(mult) => {
              setVolumeMultiplier(mult);
              AudioEngine.setVolumeMultiplier(mult);
            }}
            videoRef={videoRef}
          />
        )}
      </div>

      {isLyricsOpen && currentTrack && (
        <LyricsModal
          title={currentTrack.title}
          artist={currentTrack.artist}
          lyrics={currentTrack.lyrics}
          currentTime={currentTime}
          onSeek={handleSeek}
          onClose={() => setIsLyricsOpen(false)}
        />
      )}

      {isEqualizerOpen && (
        <EqualizerModal
          bandGains={eqBands}
          bassBoost={settings.bassBoostLevel}
          virtualizer={settings.virtualizerEnabled}
          activePreset={activeEqPreset}
          onBandChange={handleBandGainChange}
          onBassBoostChange={handleBassBoostChange}
          onVirtualizerToggle={() => setSettings(prev => ({ ...prev, virtualizerEnabled: !prev.virtualizerEnabled }))}
          onSelectPreset={handleSelectEqPreset}
          onReset={() => handleSelectEqPreset('flat')}
          onClose={() => setIsEqualizerOpen(false)}
        />
      )}

      {isQueueOpen && (
        <QueueDrawer
          queue={queue}
          currentIndex={queueIndex}
          onSelectTrack={(idx) => {
            setQueueIndex(idx);
            playTrack(queue[idx]);
          }}
          onRemoveTrack={handleRemoveFromQueue}
          onClearQueue={() => setQueue([])}
          onClose={() => setIsQueueOpen(false)}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={(newVals) => setSettings(prev => ({ ...prev, ...newVals }))}
          onOpenEqualizer={() => {
            setIsSettingsOpen(false);
            setIsEqualizerOpen(true);
          }}
          onClearDemoTracks={handleClearDemoTracks}
          onClose={() => setIsSettingsOpen(false)}
          onScanAndImport={handleScanAndImport}
          currentVersion={APP_VERSION}
          currentBuild={APP_BUILD}
          onCheckForUpdates={() => checkForUpdates(true)}
          onOpenWebsite={() => {
            if (typeof window !== 'undefined') {
              window.open('https://lerzaplayer.vercel.app', '_blank');
            }
          }}
        />
      )}

      <UpdateModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
        updateInfo={updateInfo}
        currentVersion={APP_VERSION}
      />

      <AddToPlaylistModal
        track={trackForPlaylistModal}
        playlists={playlists}
        onAddTrackToPlaylist={handleAddTrackToPlaylist}
        onClose={() => setTrackForPlaylistModal(null)}
      />

      <AdInterstitialModal
        isOpen={isInterstitialOpen}
        onClose={() => setIsInterstitialOpen(false)}
      />

      <PermissionModal
        isOpen={isPermissionModalOpen}
        onGrantPermission={() => setIsPermissionModalOpen(false)}
        onDismiss={() => setIsPermissionModalOpen(false)}
      />

      {exitToastVisible && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-neutral-900/95 text-white text-xs font-bold px-4 py-2 rounded-full shadow-2xl border border-white/20 backdrop-blur-md animate-fadeIn pointer-events-none">
          Press back again to exit
        </div>
      )}
    </div>
    </ThemeProvider>
  );
}
