import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Lerza Player Uncaught React Error:', error, errorInfo);
  }

  private handleReload = () => {
    try {
      localStorage.removeItem('lerza_tracks');
      localStorage.removeItem('fz_tracks');
    } catch (_) {}
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="fixed inset-0 bg-[#090A10] text-white flex flex-col items-center justify-center p-6 text-center z-50">
          <div className="w-16 h-16 rounded-2xl bg-rose-500/20 text-rose-500 flex items-center justify-center mb-4 border border-rose-500/30">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold mb-2 text-white">Lerza Player Recovery</h2>
          <p className="text-sm text-neutral-400 max-w-md mb-6 leading-relaxed">
            The player encountered an unexpected issue and recovered safely. You can restart the player without losing your local songs.
          </p>
          <button
            onClick={this.handleReload}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-sm shadow-lg transition active:scale-95 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Restart Lerza Player</span>
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
