import React, { useState, useRef, useEffect } from 'react';
import { 
  MediaTrack, 
  RepeatMode, 
  PlayerDisplayMode 
} from '../types';
import { generateVinylAlbumArt } from '../utils/artworkExtractor';
import { 
  ChevronDown, 
  Heart, 
  Sliders, 
  Shuffle, 
  SkipBack, 
  Play, 
  Pause, 
  SkipForward, 
  Repeat, 
  Repeat1, 
  ListMusic, 
  FileText, 
  Video, 
  Music, 
  RotateCcw, 
  RotateCw, 
  Gauge, 
  Moon, 
  Volume2, 
  Maximize2, 
  Minimize2, 
  ExternalLink, 
  VolumeX, 
  Volume1, 
  Sparkles,
  MoreVertical,
  SlidersHorizontal,
  Timer,
  Info,
  X
} from 'lucide-react';
import { ADMOB_CONFIG } from '../data/sampleMedia';
import { useTheme } from '../context/ThemeContext';

interface FullScreenPlayerProps {
  currentTrack: MediaTrack;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  repeatMode: RepeatMode;
  isShuffle: boolean;
  displayMode: PlayerDisplayMode;
  playbackSpeed: number;
  volumeMultiplier: number;
  isOnline: boolean;
  isAdsRemoved: boolean;
  onTogglePlay: () => void;
  onSeek: (seconds: number) => void;
  onNext: () => void;
  onPrev: () => void;
  onToggleShuffle: () => void;
  onCycleRepeat: () => void;
  onToggleFavorite: (id: string) => void;
  onClose: () => void;
  onOpenLyrics: () => void;
  onOpenEqualizer: () => void;
  onOpenQueue: () => void;
  onToggleDisplayMode: () => void;
  onChangeSpeed: (speed: number) => void;
  onChangeVolumeMultiplier: (mult: number) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
}

export const FullScreenPlayer: React.FC<FullScreenPlayerProps> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  repeatMode,
  isShuffle,
  displayMode,
  playbackSpeed,
  volumeMultiplier,
  isOnline,
  isAdsRemoved,
  onTogglePlay,
  onSeek,
  onNext,
  onPrev,
  onToggleShuffle,
  onCycleRepeat,
  onToggleFavorite,
  onClose,
  onOpenLyrics,
  onOpenEqualizer,
  onOpenQueue,
  onToggleDisplayMode,
  onChangeSpeed,
  onChangeVolumeMultiplier,
  videoRef
}) => {
  const { config: themeConfig } = useTheme();
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekValue, setSeekValue] = useState(currentTime);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showVolumeMenu, setShowVolumeMenu] = useState(false);
  const [showThreeDotMenu, setShowThreeDotMenu] = useState(false);
  const [isVideoFullscreen, setIsVideoFullscreen] = useState(false);

  // --- Audio Thumbnail Ad System ---
  const [showThumbnailAd, setShowThumbnailAd] = useState(false);
  const [currentAdIndex, setCurrentAdIndex] = useState(0);

  const sampleThumbnailAds = [
    {
      title: 'SoundWave Studio AI',
      sponsor: 'Music Production Pro',
      desc: 'Master, stem split & enhance audio effortlessly with AI plugins.',
      cta: 'Install Now',
      color: 'from-amber-500/25 to-violet-600/25',
      badge: 'AdMob Native'
    },
    {
      title: 'HiFi Bass EQ Tuner',
      sponsor: 'Acoustic Labs 2026',
      desc: 'Supercharge your car & headphone audio with real sub-bass DSP.',
      cta: 'Try Free',
      color: 'from-cyan-500/25 to-blue-600/25',
      badge: 'Google Ad'
    },
    {
      title: 'CloudSync Offline Tunes',
      sponsor: 'UltraStream Mobile',
      desc: 'Stream and save lossless FLAC directly to SD card offline.',
      cta: 'Get App',
      color: 'from-emerald-500/25 to-teal-600/25',
      badge: 'AdMob Native'
    }
  ];

  useEffect(() => {
    if (!isOnline || isAdsRemoved || displayMode !== 'audio') {
      setShowThumbnailAd(false);
      return;
    }

    const initialTimer = setTimeout(() => {
      setShowThumbnailAd(true);
    }, 10000);

    const interval = setInterval(() => {
      setShowThumbnailAd(prev => {
        if (!prev) {
          setCurrentAdIndex(i => (i + 1) % sampleThumbnailAds.length);
          return true;
        } else {
          return false;
        }
      });
    }, 20000);

    return () => {
      clearTimeout(initialTimer);
      clearInterval(interval);
    };
  }, [isOnline, isAdsRemoved, displayMode]);

  // --- Advanced Gesture Controls ---
  const touchStartPos = useRef<{ x: number; y: number; time: number } | null>(null);
  const lastTapRef = useRef<{ time: number; x: number } | null>(null);
  const [gestureFeedback, setGestureFeedback] = useState<{ text: string; icon: 'rewind' | 'forward' | 'play' | 'pause' } | null>(null);
  const feedbackTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [dragOffsetY, setDragOffsetY] = useState(0);
  const [swipeTrackDelta, setSwipeTrackDelta] = useState<number | null>(null);

  const showGestureFeedback = (text: string, icon: 'rewind' | 'forward' | 'play' | 'pause') => {
    if (feedbackTimeoutRef.current) clearTimeout(feedbackTimeoutRef.current);
    setGestureFeedback({ text, icon });
    feedbackTimeoutRef.current = setTimeout(() => {
      setGestureFeedback(null);
    }, 850);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    const touch = e.touches[0];
    const windowHeight = window.innerHeight;

    // اگر ٹچ نچلے 35% حصے (کنٹرولز ایریا) میں ہو، یا سSeekbar/Input پر ہو تو گیسچر کو روکیں
    if (
      isSeeking || 
      touch.clientY > windowHeight * 0.60 || 
      target.closest('.seekbar-container') || 
      target.closest('.control-deck-area') ||
      target.tagName === 'INPUT' ||
      target.tagName === 'BUTTON'
    ) {
      touchStartPos.current = null;
      return;
    }

    touchStartPos.current = { x: touch.clientX, y: touch.clientY, time: Date.now() };
    setSwipeTrackDelta(null);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    if (!touchStartPos.current || isSeeking || target.closest('.seekbar-container') || target.tagName === 'INPUT') {
      return;
    }

    const currentX = e.touches[0].clientX;
    const currentY = e.touches[0].clientY;
    const deltaX = currentX - touchStartPos.current.x;
    const deltaY = currentY - touchStartPos.current.y;

    if (deltaY > 0 && Math.abs(deltaY) > Math.abs(deltaX) * 1.3) {
      setDragOffsetY(deltaY);
      setSwipeTrackDelta(null);
    } 
    

  const handleTouchEnd = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    if (isSeeking || target.closest('.seekbar-container') || target.tagName === 'INPUT') {
      touchStartPos.current = null;
      return;
    }

    if (dragOffsetY > 110) {
      onClose();
    } else if (swipeTrackDelta !== null) {
      if (swipeTrackDelta < -60) {
        onNext();
        showGestureFeedback('Next Track', 'forward');
      } else if (swipeTrackDelta > 60) {
        onPrev();
        showGestureFeedback('Previous Track', 'rewind');
      }
    }

    setDragOffsetY(0);
    setSwipeTrackDelta(null);
    touchStartPos.current = null;
  };

  const handleStageTap = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    const clientX = 'touches' in e ? (e as any).changedTouches?.[0]?.clientX : (e as React.MouseEvent).clientX;
    const rect = e.currentTarget.getBoundingClientRect();
    if (!rect || clientX === undefined) return;

    const relativeX = clientX - rect.left;
    const width = rect.width;
    const now = Date.now();

    if (lastTapRef.current && (now - lastTapRef.current.time) < 320) {
      if (relativeX < width * 0.35) {
        const newT = Math.max(0, currentTime - 10);
        onSeek(newT);
        showGestureFeedback('-10s Rewind', 'rewind');
      } else if (relativeX > width * 0.65) {
        const newT = Math.min(duration || 100, currentTime + 10);
        onSeek(newT);
        showGestureFeedback('+10s Forward', 'forward');
      } else {
        onTogglePlay();
        showGestureFeedback(isPlaying ? 'Paused' : 'Playing', isPlaying ? 'pause' : 'play');
      }
      lastTapRef.current = null;
    } else {
      lastTapRef.current = { time: now, x: relativeX };
    }
  };

  useEffect(() => {
    if (!isSeeking) {
      setSeekValue(currentTime);
    }
  }, [currentTime, isSeeking]);

  const formatTime = (sec: number) => {
    if (isNaN(sec) || sec < 0) return '0:00';
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setSeekValue(val);
  };

  const handleSeekCommit = () => {
    setIsSeeking(false);
    onSeek(seekValue);
  };

  const handleTimelineTrackClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    if (rect.width <= 0) return;
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    const targetTime = ratio * (duration || 100);
    setSeekValue(targetTime);
    setIsSeeking(false);
    onSeek(targetTime);
  };

  const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
  const volumeOptions = [
    { label: '100%', val: 1.0, badge: 'Normal' },
    { label: '150%', val: 1.5, badge: 'Boost' },
    { label: '200%', val: 2.0, badge: 'Super' },
    { label: '300%', val: 3.0, badge: 'Max' }
  ];

  const toggleVideoFullscreen = () => {
    const videoContainer = document.getElementById('video-stage-container');
    if (!videoContainer) return;

    if (!document.fullscreenElement) {
      videoContainer.requestFullscreen().then(() => setIsVideoFullscreen(true)).catch(() => {
        setIsVideoFullscreen(!isVideoFullscreen);
      });
    } else {
      document.exitFullscreen().then(() => setIsVideoFullscreen(false)).catch(() => {
        setIsVideoFullscreen(false);
      });
    }
  };

  const activeAd = sampleThumbnailAds[currentAdIndex];

  return (
    <div 
      className={`fixed inset-0 z-50 backdrop-blur-3xl ${themeConfig.isDark ? 'bg-[#0f1117]/95 text-neutral-100' : 'bg-[#fcfbf9]/95 text-slate-900'} flex flex-col justify-between overflow-y-auto animate-slideUp select-none transition-all duration-200`}
      style={{
        transform: dragOffsetY > 0 ? `translateY(${dragOffsetY}px)` : undefined,
        opacity: dragOffsetY > 0 ? Math.max(0.3, 1 - dragOffsetY / 300) : 1
      }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div 
        className={`fixed inset-0 pointer-events-none ${themeConfig.isDark ? 'opacity-20' : 'opacity-10'} filter blur-3xl scale-125 transition-all duration-1000`}
        style={{
          backgroundImage: `radial-gradient(circle at 50% 30%, ${currentTrack.hasMV ? '#06b6d4' : '#6366f1'} 0%, transparent 70%)`
        }}
      />

      <div className="relative z-10 flex-1 flex flex-col justify-between max-w-md w-full mx-auto px-6 py-4">
        {/* Top Bar */}
        <div className="flex items-center justify-between">
          <button
            onClick={onClose}
            className={`p-2 rounded-full ${themeConfig.isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'} active:scale-95 transition`}
            title="Minimize Player"
          >
            <ChevronDown className="w-7 h-7" />
          </button>

          {currentTrack.hasMV ? (
            <div className={`flex items-center ${themeConfig.isDark ? 'bg-neutral-900/90 border-white/10' : 'bg-black/5 border-black/10'} border p-1 rounded-full shadow-inner`}>
              <button
                onClick={() => displayMode !== 'audio' && onToggleDisplayMode()}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all ${
                  displayMode === 'audio'
                    ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow'
                    : 'text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <Music className="w-3.5 h-3.5" />
                <span>Audio</span>
              </button>

              <button
                onClick={() => displayMode !== 'video' && onToggleDisplayMode()}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all ${
                  displayMode === 'video'
                    ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow'
                    : 'text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <Video className="w-3.5 h-3.5" />
                <span>Video MV</span>
              </button>
            </div>
          ) : (
            <div className={`text-xs font-bold uppercase tracking-widest ${themeConfig.isDark ? 'bg-neutral-900/80 border-white/5 text-neutral-400' : 'bg-black/5 border-black/10 text-neutral-600'} px-3.5 py-1 rounded-full border`}>
              LERZA PLAYER
            </div>
          )}

          <button
            onClick={onOpenEqualizer}
            className={`p-2 rounded-full ${themeConfig.isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'} active:scale-95 transition`}
            title="Equalizer"
          >
            <SlidersHorizontal className="w-5 h-5 opacity-80" />
          </button>
        </div>

        {/* Center Artwork / Stage Area */}
        <div className="my-auto py-2 flex items-center justify-center relative">
          {gestureFeedback && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30 animate-scaleUp">
              <div className="flex items-center gap-2.5 px-5 py-2.5 rounded-2xl bg-black/85 text-white backdrop-blur-xl border border-white/20 shadow-2xl font-bold text-sm tracking-wide">
                {gestureFeedback.icon === 'rewind' && <RotateCcw className="w-5 h-5 text-cyan-400" />}
                {gestureFeedback.icon === 'forward' && <RotateCw className="w-5 h-5 text-cyan-400" />}
                {gestureFeedback.icon === 'play' && <Play className="w-5 h-5 text-emerald-400 fill-current" />}
                {gestureFeedback.icon === 'pause' && <Pause className="w-5 h-5 text-amber-400 fill-current" />}
                <span>{gestureFeedback.text}</span>
              </div>
            </div>
          )}

          {swipeTrackDelta !== null && Math.abs(swipeTrackDelta) > 20 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
              <div className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-black/90 text-white backdrop-blur-xl border border-cyan-400/50 shadow-2xl font-mono text-sm font-bold animate-fadeIn">
                <span>{swipeTrackDelta < 0 ? '⏩ Swipe: Next Track' : '⏪ Swipe: Previous Track'}</span>
              </div>
            </div>
          )}

          {displayMode === 'video' && currentTrack.videoUrl ? (
            <div 
              id="video-stage-container"
              onClick={handleStageTap}
              className={`w-full aspect-video rounded-3xl overflow-hidden bg-black shadow-2xl relative border border-white/10 transition-all cursor-pointer ${
                isVideoFullscreen ? 'fixed inset-0 z-50 rounded-none w-screen h-screen border-none' : ''
              }`}
            >
              <video
                ref={videoRef as any}
                src={currentTrack.videoUrl || undefined}
                preload="metadata"
                playsInline
                className="w-full h-full object-contain pointer-events-none"
              />

              <div className="absolute inset-0 pointer-events-none flex items-center justify-between px-4">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSeek(Math.max(0, currentTime - 10));
                  }}
                  className="pointer-events-auto p-2.5 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md text-white transition active:scale-90"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSeek(Math.min(duration, currentTime + 10));
                  }}
                  className="pointer-events-auto p-2.5 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md text-white transition active:scale-90"
                >
                  <RotateCw className="w-5 h-5" />
                </button>
              </div>

              <div className="absolute bottom-3 right-3 pointer-events-auto flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleVideoFullscreen();
                  }}
                  className="p-2 rounded-xl bg-black/75 hover:bg-black text-white backdrop-blur-md border border-white/20 active:scale-95 transition"
                >
                  {isVideoFullscreen ? (
                    <Minimize2 className="w-4 h-4 text-cyan-400" />
                  ) : (
                    <Maximize2 className="w-4 h-4 text-cyan-400" />
                  )}
                </button>
              </div>
            </div>
          ) : (
            <div 
              onClick={handleStageTap}
              className="relative w-72 h-72 sm:w-80 sm:h-80 rounded-[32px] overflow-hidden shadow-2xl group border border-black/5 dark:border-white/10 cursor-pointer select-none"
            >
              {showThumbnailAd && isOnline && !isAdsRemoved ? (
                <div className={`w-full h-full bg-gradient-to-br ${activeAd.color} bg-neutral-900 flex flex-col justify-between p-5 text-left animate-fadeIn border border-amber-500/30 relative`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider bg-amber-500 text-neutral-950 px-2 py-0.5 rounded font-mono">
                        AD
                      </span>
                      <span className="text-[11px] text-amber-300 font-bold font-mono">
                        {activeAd.badge}
                      </span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowThumbnailAd(false);
                      }}
                      className="text-xs text-neutral-400 hover:text-white bg-white/10 px-2 py-0.5 rounded-full"
                    >
                      Hide
                    </button>
                  </div>

                  <div className="my-auto space-y-2">
                    <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-black text-white leading-tight">
                      {activeAd.title}
                    </h3>
                    <p className="text-xs text-neutral-300 line-clamp-2">
                      {activeAd.desc}
                    </p>
                    <span className="text-[10px] text-neutral-400 block">
                      Sponsored by {activeAd.sponsor}
                    </span>
                  </div>

                  <div className="pt-2 flex items-center justify-between border-t border-white/10">
                    <span className="text-[10px] text-neutral-400 font-mono">
                      {ADMOB_CONFIG.bannerUnitId}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        window.open('https://play.google.com', '_blank');
                      }}
                      className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 shadow-lg active:scale-95 transition"
                    >
                      <span>{activeAd.cta}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <img
                    src={currentTrack.artworkUrl}
                    alt={currentTrack.title}
                    className={`w-full h-full object-cover transition-transform duration-700 ${
                      isPlaying ? 'scale-105' : 'scale-100'
                    }`}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = generateVinylAlbumArt(currentTrack.title, currentTrack.artist);
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/10" />
                </>
              )}
            </div>
          )}
        </div>

        {/* Track Info Area */}
        <div className="mt-2 mb-3">
          <h2 className="text-2xl sm:text-3xl font-black truncate tracking-tight text-neutral-900 dark:text-white leading-tight">
            {currentTrack.title}
          </h2>

          <div className="flex items-center justify-between gap-3 mt-1.5">
            <p className="text-base font-semibold truncate text-neutral-600 dark:text-neutral-400">
              {currentTrack.artist}
            </p>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => onToggleFavorite(currentTrack.id)}
                className="p-1.5 rounded-full active:scale-90 transition"
                title="Favorite"
              >
                <Heart
                  className={`w-6 h-6 transition-colors ${
                    currentTrack.isFavorite 
                      ? 'text-rose-500 fill-rose-500' 
                      : 'text-neutral-500 hover:text-rose-500'
                  }`}
                />
              </button>

              <button
                onClick={() => setShowThreeDotMenu(true)}
                className="p-1.5 rounded-full text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/10 active:scale-90 transition"
                title="Playback Options & Speed"
              >
                <MoreVertical className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Control Deck with Isolated Gesture Boundaries */}
        <div className="control-deck-area mt-auto backdrop-blur-2xl bg-black/[0.03] dark:bg-white/[0.04] border border-black/5 dark:border-white/10 rounded-3xl p-4 sm:p-5 shadow-xl space-y-4">
          
          {/* ISOLATED SEEKBAR / TIMELINE CONTAINER */}
          <div 
            className="seekbar-container touch-none relative select-none"
            onTouchStart={(e) => {
              e.stopPropagation();
              setIsSeeking(true);
            }}
            onTouchMove={(e) => {
              e.stopPropagation();
            }}
            onTouchEnd={(e) => {
              e.stopPropagation();
              handleSeekCommit();
            }}
            onMouseDown={(e) => {
              e.stopPropagation();
              setIsSeeking(true);
            }}
            onMouseUp={(e) => {
              e.stopPropagation();
              handleSeekCommit();
            }}
          >
            <div 
              className="relative group flex items-center py-3 cursor-pointer"
              onClick={handleTimelineTrackClick}
            >
              <div className={`w-full h-2 rounded-full overflow-hidden ${themeConfig.isDark ? 'bg-neutral-800' : 'bg-neutral-300/80'} relative pointer-events-none`}>
                <div 
                  className="h-full bg-neutral-900 dark:bg-white rounded-full transition-[width] duration-75"
                  style={{ width: `${Math.min(100, Math.max(0, ((seekValue || 0) / (duration || 1)) * 100))}%` }}
                />
              </div>

              <input
                type="range"
                min="0"
                max={duration || 100}
                step="0.1"
                value={seekValue}
                onChange={handleSeekChange}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  setIsSeeking(true);
                }}
                onPointerUp={(e) => {
                  e.stopPropagation();
                  handleSeekCommit();
                }}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer touch-none z-20"
              />
            </div>

            <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 font-mono -mt-1 pointer-events-none">
              <span>{formatTime(seekValue)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-center gap-10">
            <button
              onClick={onPrev}
              className="p-3 rounded-full text-neutral-900 dark:text-white hover:opacity-80 active:scale-90 transition"
              title="Previous Track"
            >
              <SkipBack className="w-8 h-8 fill-current" />
            </button>

            <button
              onClick={onTogglePlay}
              className="w-20 h-20 rounded-full bg-neutral-900 dark:bg-white text-white dark:text-neutral-950 flex items-center justify-center shadow-2xl active:scale-95 transition-transform"
              title={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? (
                <Pause className="w-8 h-8 fill-current" />
              ) : (
                <Play className="w-8 h-8 fill-current ml-1" />
              )}
            </button>

            <button
              onClick={onNext}
              className="p-3 rounded-full text-neutral-900 dark:text-white hover:opacity-80 active:scale-90 transition"
              title="Next Track"
            >
              <SkipForward className="w-8 h-8 fill-current" />
            </button>
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              onClick={onOpenEqualizer}
              className="p-2.5 rounded-full text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/10 active:scale-90 transition"
              title="Equalizer"
            >
              <SlidersHorizontal className="w-6 h-6" />
            </button>

            <div className={`px-5 py-1.5 rounded-full border text-xs font-bold ${
              themeConfig.isDark 
                ? 'bg-neutral-900/90 border-neutral-700 text-neutral-200' 
                : 'bg-[#F2E5CA] border-[#E5D4B2] text-neutral-800'
            }`}>
              {currentTrack.genre ? `${currentTrack.genre}` : 'LERZA PLAYER'}
            </div>

            <button
              onClick={onOpenQueue}
              className="p-2.5 rounded-full text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/10 active:scale-90 transition"
              title="Current Playlist / Queue"
            >
              <ListMusic className="w-6 h-6" />
            </button>
          </div>
        </div>

     

      {/* Complete Three-Dot Bottom Sheet Menu */}
      {showThreeDotMenu && (
        <div 
          className="fixed inset-0 z-60 bg-black/60 backdrop-blur-sm flex items-end justify-center animate-fadeIn"
          onClick={() => setShowThreeDotMenu(false)}
        >
          <div 
            className={`w-full max-w-lg rounded-t-3xl ${themeConfig.isDark ? 'bg-neutral-900 text-white' : 'bg-[#FAF6EC] text-neutral-900'} p-5 border-t border-black/10 dark:border-white/10 shadow-2xl animate-slideUp max-h-[85vh] overflow-y-auto`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-neutral-300 dark:bg-neutral-700 rounded-full mx-auto mb-3" />
            
            <div className="flex items-center justify-between pb-3 border-b border-black/10 dark:border-white/10">
              <div className="flex items-center gap-2">
                <Gauge className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h3 className="text-base font-bold">Playback Options</h3>
              </div>
              <button
                onClick={() => setShowThreeDotMenu(false)}
                className="p-1 rounded-full hover:bg-black/5 dark:hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Playback Speed Section */}
            <div className="py-3.5 border-b border-black/10 dark:border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  Playback Speed
                </span>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-blue-600/15 text-blue-600 dark:text-blue-400">
                  {playbackSpeed}x
                </span>
              </div>
              <div className="grid grid-cols-6 gap-1.5">
                {speeds.map((s) => (
                  <button
                    key={s}
                    onClick={() => onChangeSpeed(s)}
                    className={`py-2 text-xs font-bold rounded-xl transition ${
                      playbackSpeed === s
                        ? 'bg-blue-600 text-white shadow-md'
                        : `${themeConfig.isDark ? 'bg-neutral-800 text-neutral-300' : 'bg-black/5 text-neutral-700'} hover:opacity-80`
                    }`}
                  >
                    {s}x
                  </button>
                ))}
              </div>
            </div>

            {/* Volume Boost Section */}
            <div className="py-3.5 border-b border-black/10 dark:border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-amber-500" />
                  Super Volume Boost
                </span>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-amber-500/15 text-amber-600 dark:text-amber-400">
                  {Math.round(volumeMultiplier * 100)}%
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {volumeOptions.map((opt) => (
                  <button
                    key={opt.label}
                    onClick={() => onChangeVolumeMultiplier(opt.val)}
                    className={`py-2 text-xs font-bold rounded-xl transition ${
                      volumeMultiplier === opt.val
                        ? 'bg-amber-500 text-neutral-950 shadow-md font-extrabold'
                        : `${themeConfig.isDark ? 'bg-neutral-800 text-neutral-300' : 'bg-black/5 text-neutral-700'} hover:opacity-80`
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Equalizer, Lyrics, Shuffle, Repeat Actions */}
            <div className="py-3.5 border-b border-black/10 dark:border-white/10 grid grid-cols-2 gap-2.5">
              <button
                onClick={() => {
                  setShowThreeDotMenu(false);
                  onOpenEqualizer();
                }}
                className={`flex items-center gap-2.5 p-3 rounded-2xl ${
                  themeConfig.isDark ? 'bg-neutral-800 hover:bg-neutral-700' : 'bg-black/5 hover:bg-black/10'
                } transition text-left`}
              >
                <SlidersHorizontal className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <div>
                  <div className="text-xs font-bold">Equalizer & Bass</div>
                  <div className="text-[11px] text-neutral-500">5-Band Audio DSP</div>
                </div>
              </button>

              <button
                onClick={() => {
                  setShowThreeDotMenu(false);
                  onOpenLyrics();
                }}
                className={`flex items-center gap-2.5 p-3 rounded-2xl ${
                  themeConfig.isDark ? 'bg-neutral-800 hover:bg-neutral-700' : 'bg-black/5 hover:bg-black/10'
                } transition text-left`}
              >
                <FileText className="w-5 h-5 text-emerald-500" />
                <div>
                  <div className="text-xs font-bold">Lyrics</div>
                  <div className="text-[11px] text-neutral-500">View Song Words</div>
                </div>
              </button>

              <button
                onClick={onToggleShuffle}
                className={`flex items-center gap-2.5 p-3 rounded-2xl ${
                  isShuffle 
                    ? 'bg-blue-600/20 text-blue-600 dark:text-blue-400 border border-blue-500/30' 
                    : (themeConfig.isDark ? 'bg-neutral-800' : 'bg-black/5')
                } transition text-left`}
              >
                <Shuffle className="w-5 h-5" />
                <div>
                  <div className="text-xs font-bold">Shuffle Mode</div>
                  <div className="text-[11px] text-neutral-500">{isShuffle ? 'On' : 'Off'}</div>
                </div>
              </button>

              <button
                onClick={onCycleRepeat}
                className={`flex items-center gap-2.5 p-3 rounded-2xl ${
                  repeatMode !== 'off'
                    ? 'bg-blue-600/20 text-blue-600 dark:text-blue-400 border border-blue-500/30' 
                    : (themeConfig.isDark ? 'bg-neutral-800' : 'bg-black/5')
                } transition text-left`}
              >
                {repeatMode === 'one' ? <Repeat1 className="w-5 h-5" /> : <Repeat className="w-5 h-5" />}
                <div>
                  <div className="text-xs font-bold">Repeat Mode</div>
                  <div className="text-[11px] text-neutral-500 capitalize">{repeatMode}</div>
                </div>
              </button>
            </div>

            {/* Audio Metadata Footer */}
            <div className="pt-3 text-xs space-y-1 text-neutral-500 dark:text-neutral-400 font-mono">
              <div className="flex justify-between">
                <span>Format:</span>
                <span className="font-bold text-neutral-700 dark:text-neutral-200">{currentTrack.fileFormat || 'MP3'}</span>
              </div>
              <div className="flex justify-between">
                <span>Duration:</span>
                <span className="font-bold text-neutral-700 dark:text-neutral-200">{formatTime(duration)}</span>
              </div>
              <div className="flex justify-between">
                <span>Album:</span>
                <span className="font-bold text-neutral-700 dark:text-neutral-200 truncate max-w-[200px]">{currentTrack.album || 'Unknown'}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
